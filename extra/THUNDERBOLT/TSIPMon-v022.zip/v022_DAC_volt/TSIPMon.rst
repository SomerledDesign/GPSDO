                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Jul 28 2006)
                              4 ; This file generated Thu Jan 01 19:40:10 2009
                              5 ;--------------------------------------------------------
                              6 	.module TSIPMon
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _TimerStart_PARM_2
                             13 	.globl _prompt
                             14 	.globl _LCDInitMsg
                             15 	.globl _VersionMsg
                             16 	.globl _DiscActivity
                             17 	.globl _GPSDecodeStatus
                             18 	.globl _DiscMode
                             19 	.globl _RxMode
                             20 	.globl _Month
                             21 	.globl _Timer_3_Overflow
                             22 	.globl _Comparator
                             23 	.globl _Programmable_Counter_Array
                             24 	.globl _ADC0_End_of_Conversion
                             25 	.globl _ADC0_Window_Comparator
                             26 	.globl _SMB0
                             27 	.globl _SPI0
                             28 	.globl _Timer_1_Overflow
                             29 	.globl _External_Interrupt_1
                             30 	.globl _External_Interrupt_0
                             31 	.globl _SioIntService
                             32 	.globl _Timer2_ISR
                             33 	.globl _main
                             34 	.globl _SPIF
                             35 	.globl _WCOL
                             36 	.globl _MODF
                             37 	.globl _RXOVRN
                             38 	.globl _NSSMD1
                             39 	.globl _NSSMD0
                             40 	.globl _TXBMT
                             41 	.globl _SPIEN
                             42 	.globl _AD0EN
                             43 	.globl _AD0TM
                             44 	.globl _AD0INT
                             45 	.globl _AD0BUSY
                             46 	.globl _AD0WINT
                             47 	.globl _AD0CM2
                             48 	.globl _AD0CM1
                             49 	.globl _AD0CM0
                             50 	.globl _CF
                             51 	.globl _CR
                             52 	.globl _CCF2
                             53 	.globl _CCF1
                             54 	.globl _CCF0
                             55 	.globl _CY
                             56 	.globl _AC
                             57 	.globl _F0
                             58 	.globl _RS1
                             59 	.globl _RS0
                             60 	.globl _OV
                             61 	.globl _F1
                             62 	.globl _PARITY
                             63 	.globl _TF2H
                             64 	.globl _TF2
                             65 	.globl _TF2L
                             66 	.globl _TF2LEN
                             67 	.globl _TF2CEN
                             68 	.globl _T2SPLIT
                             69 	.globl _TR2
                             70 	.globl _T2XCLK
                             71 	.globl _MASTER
                             72 	.globl _TXMODE
                             73 	.globl _STA
                             74 	.globl _STO
                             75 	.globl _ACKRQ
                             76 	.globl _ARBLOST
                             77 	.globl _ACK
                             78 	.globl _SI
                             79 	.globl _PSPI0
                             80 	.globl _PT2
                             81 	.globl _PS0
                             82 	.globl _PS
                             83 	.globl _PT1
                             84 	.globl _PX1
                             85 	.globl _PT0
                             86 	.globl _PX0
                             87 	.globl _EA
                             88 	.globl _ESPI0
                             89 	.globl _ET2
                             90 	.globl _ES0
                             91 	.globl _ES
                             92 	.globl _ET1
                             93 	.globl _EX1
                             94 	.globl _ET0
                             95 	.globl _EX0
                             96 	.globl _P2_7
                             97 	.globl _P2_6
                             98 	.globl _P2_5
                             99 	.globl _P2_4
                            100 	.globl _P2_3
                            101 	.globl _P2_2
                            102 	.globl _P2_1
                            103 	.globl _P2_0
                            104 	.globl _S0MODE
                            105 	.globl _SM0
                            106 	.globl _MCE0
                            107 	.globl _SM2
                            108 	.globl _REN0
                            109 	.globl _REN
                            110 	.globl _TB80
                            111 	.globl _TB8
                            112 	.globl _RB80
                            113 	.globl _RB8
                            114 	.globl _TI0
                            115 	.globl _TI
                            116 	.globl _RI0
                            117 	.globl _RI
                            118 	.globl _P1_7
                            119 	.globl _P1_6
                            120 	.globl _P1_5
                            121 	.globl _P1_4
                            122 	.globl _P1_3
                            123 	.globl _P1_2
                            124 	.globl _P1_1
                            125 	.globl _P1_0
                            126 	.globl _TF1
                            127 	.globl _TR1
                            128 	.globl _TF0
                            129 	.globl _TR0
                            130 	.globl _IE1
                            131 	.globl _IT1
                            132 	.globl _IE0
                            133 	.globl _IT0
                            134 	.globl _P0_7
                            135 	.globl _P0_6
                            136 	.globl _P0_5
                            137 	.globl _P0_4
                            138 	.globl _P0_3
                            139 	.globl _P0_2
                            140 	.globl _P0_1
                            141 	.globl _P0_0
                            142 	.globl _PCA0CP2
                            143 	.globl _PCA0CP1
                            144 	.globl _PCA0CP0
                            145 	.globl _PCA0
                            146 	.globl _ADC0LT
                            147 	.globl _ADC0GT
                            148 	.globl _ADC0
                            149 	.globl _IDA0
                            150 	.globl _TMR3RL
                            151 	.globl _TMR3
                            152 	.globl _TMR2RL
                            153 	.globl _RCAP2
                            154 	.globl _TMR2
                            155 	.globl _TMR1
                            156 	.globl _TMR0
                            157 	.globl _VDM0CN
                            158 	.globl _PCA0CPH0
                            159 	.globl _PCA0CPL0
                            160 	.globl _PCA0H
                            161 	.globl _PCA0L
                            162 	.globl _SPI0CN
                            163 	.globl _EIP1
                            164 	.globl _P1MDIN
                            165 	.globl _P1MODE
                            166 	.globl _P0MDIN
                            167 	.globl _P0MODE
                            168 	.globl _B
                            169 	.globl _RSTSRC
                            170 	.globl _PCA0CPH2
                            171 	.globl _PCA0CPL2
                            172 	.globl _PCA0CPH1
                            173 	.globl _PCA0CPL1
                            174 	.globl _ADC0CN
                            175 	.globl _EIE1
                            176 	.globl _INT01CF
                            177 	.globl _IT01CF
                            178 	.globl _OSCLCN
                            179 	.globl _XBR1
                            180 	.globl _XBR0
                            181 	.globl _ACC
                            182 	.globl _PCA0CPM2
                            183 	.globl _PCA0CPM1
                            184 	.globl _PCA0CPM0
                            185 	.globl _PCA0MD
                            186 	.globl _PCA0CN
                            187 	.globl _P1SKIP
                            188 	.globl _P0SKIP
                            189 	.globl _REF0CN
                            190 	.globl _PSW
                            191 	.globl _TMR2H
                            192 	.globl _TH2
                            193 	.globl _TMR2L
                            194 	.globl _TL2
                            195 	.globl _TMR2RLH
                            196 	.globl _RCAP2H
                            197 	.globl _TMR2RLL
                            198 	.globl _RCAP2L
                            199 	.globl _TMR2CN
                            200 	.globl _T2CON
                            201 	.globl _ADC0LTH
                            202 	.globl _ADC0LTL
                            203 	.globl _ADC0GTH
                            204 	.globl _ADC0GTL
                            205 	.globl _SMB0DAT
                            206 	.globl _SMB0CF
                            207 	.globl _SMB0CN
                            208 	.globl _ADC0H
                            209 	.globl _ADC0L
                            210 	.globl _ADC0CF
                            211 	.globl _AMX0P
                            212 	.globl _AMX0N
                            213 	.globl _IDA0CN
                            214 	.globl _IP
                            215 	.globl _FLKEY
                            216 	.globl _FLSCL
                            217 	.globl _OSCICL
                            218 	.globl _OSCICN
                            219 	.globl _OSCXCN
                            220 	.globl __XPAGE
                            221 	.globl _EMI0CN
                            222 	.globl _CLKSEL
                            223 	.globl _IE
                            224 	.globl _P2MDOUT
                            225 	.globl _P1MDOUT
                            226 	.globl _P0MDOUT
                            227 	.globl _SPI0DAT
                            228 	.globl _SPI0CKR
                            229 	.globl _SPI0CFG
                            230 	.globl _P2
                            231 	.globl _CPT0MX
                            232 	.globl _CPT0MD
                            233 	.globl _CPT0CN
                            234 	.globl _SBUF0
                            235 	.globl _SBUF
                            236 	.globl _SCON0
                            237 	.globl _SCON
                            238 	.globl _IDA0H
                            239 	.globl _IDA0L
                            240 	.globl _TMR3H
                            241 	.globl _TMR3L
                            242 	.globl _TMR3RLH
                            243 	.globl _TMR3RLL
                            244 	.globl _TMR3CN
                            245 	.globl _P1
                            246 	.globl _PSCTL
                            247 	.globl _CKCON
                            248 	.globl _TH1
                            249 	.globl _TH0
                            250 	.globl _TL1
                            251 	.globl _TL0
                            252 	.globl _TMOD
                            253 	.globl _TCON
                            254 	.globl _PCON
                            255 	.globl _DPH
                            256 	.globl _DPL
                            257 	.globl _SP
                            258 	.globl _P0
                            259 	.globl _TxRxBuf
                            260 	.globl _lcdbuf
                            261 	.globl _Alarms
                            262 	.globl _err1
                            263 	.globl _func1
                            264 	.globl _func2
                            265 	.globl _switch1
                            266 	.globl _switch2
                            267 	.globl _Tx_In_Progress
                            268 	.globl _Rx_Pending
                            269 	.globl _ticks
                            270 	.globl _Timer
                            271 	.globl _Port_Init
                            272 	.globl _Timer2_Init
                            273 	.globl _WaitTicks
                            274 	.globl _TimerStart
                            275 	.globl _TimerRunning
                            276 	.globl _TimerReset
                            277 	.globl _TimerReady
                            278 	.globl _UART0_Init
                            279 	.globl _ProcessRxMsg
                            280 	.globl _PrimaryTiming
                            281 	.globl _SupplementalTiming
                            282 ;--------------------------------------------------------
                            283 ; special function registers
                            284 ;--------------------------------------------------------
                            285 	.area RSEG    (DATA)
                    0080    286 G$P0$0$0 == 0x0080
                    0080    287 _P0	=	0x0080
                    0081    288 G$SP$0$0 == 0x0081
                    0081    289 _SP	=	0x0081
                    0082    290 G$DPL$0$0 == 0x0082
                    0082    291 _DPL	=	0x0082
                    0083    292 G$DPH$0$0 == 0x0083
                    0083    293 _DPH	=	0x0083
                    0087    294 G$PCON$0$0 == 0x0087
                    0087    295 _PCON	=	0x0087
                    0088    296 G$TCON$0$0 == 0x0088
                    0088    297 _TCON	=	0x0088
                    0089    298 G$TMOD$0$0 == 0x0089
                    0089    299 _TMOD	=	0x0089
                    008A    300 G$TL0$0$0 == 0x008a
                    008A    301 _TL0	=	0x008a
                    008B    302 G$TL1$0$0 == 0x008b
                    008B    303 _TL1	=	0x008b
                    008C    304 G$TH0$0$0 == 0x008c
                    008C    305 _TH0	=	0x008c
                    008D    306 G$TH1$0$0 == 0x008d
                    008D    307 _TH1	=	0x008d
                    008E    308 G$CKCON$0$0 == 0x008e
                    008E    309 _CKCON	=	0x008e
                    008F    310 G$PSCTL$0$0 == 0x008f
                    008F    311 _PSCTL	=	0x008f
                    0090    312 G$P1$0$0 == 0x0090
                    0090    313 _P1	=	0x0090
                    0091    314 G$TMR3CN$0$0 == 0x0091
                    0091    315 _TMR3CN	=	0x0091
                    0092    316 G$TMR3RLL$0$0 == 0x0092
                    0092    317 _TMR3RLL	=	0x0092
                    0093    318 G$TMR3RLH$0$0 == 0x0093
                    0093    319 _TMR3RLH	=	0x0093
                    0094    320 G$TMR3L$0$0 == 0x0094
                    0094    321 _TMR3L	=	0x0094
                    0095    322 G$TMR3H$0$0 == 0x0095
                    0095    323 _TMR3H	=	0x0095
                    0096    324 G$IDA0L$0$0 == 0x0096
                    0096    325 _IDA0L	=	0x0096
                    0097    326 G$IDA0H$0$0 == 0x0097
                    0097    327 _IDA0H	=	0x0097
                    0098    328 G$SCON$0$0 == 0x0098
                    0098    329 _SCON	=	0x0098
                    0098    330 G$SCON0$0$0 == 0x0098
                    0098    331 _SCON0	=	0x0098
                    0099    332 G$SBUF$0$0 == 0x0099
                    0099    333 _SBUF	=	0x0099
                    0099    334 G$SBUF0$0$0 == 0x0099
                    0099    335 _SBUF0	=	0x0099
                    009B    336 G$CPT0CN$0$0 == 0x009b
                    009B    337 _CPT0CN	=	0x009b
                    009D    338 G$CPT0MD$0$0 == 0x009d
                    009D    339 _CPT0MD	=	0x009d
                    009F    340 G$CPT0MX$0$0 == 0x009f
                    009F    341 _CPT0MX	=	0x009f
                    00A0    342 G$P2$0$0 == 0x00a0
                    00A0    343 _P2	=	0x00a0
                    00A1    344 G$SPI0CFG$0$0 == 0x00a1
                    00A1    345 _SPI0CFG	=	0x00a1
                    00A2    346 G$SPI0CKR$0$0 == 0x00a2
                    00A2    347 _SPI0CKR	=	0x00a2
                    00A3    348 G$SPI0DAT$0$0 == 0x00a3
                    00A3    349 _SPI0DAT	=	0x00a3
                    00A4    350 G$P0MDOUT$0$0 == 0x00a4
                    00A4    351 _P0MDOUT	=	0x00a4
                    00A5    352 G$P1MDOUT$0$0 == 0x00a5
                    00A5    353 _P1MDOUT	=	0x00a5
                    00A6    354 G$P2MDOUT$0$0 == 0x00a6
                    00A6    355 _P2MDOUT	=	0x00a6
                    00A8    356 G$IE$0$0 == 0x00a8
                    00A8    357 _IE	=	0x00a8
                    00A9    358 G$CLKSEL$0$0 == 0x00a9
                    00A9    359 _CLKSEL	=	0x00a9
                    00AA    360 G$EMI0CN$0$0 == 0x00aa
                    00AA    361 _EMI0CN	=	0x00aa
                    00AA    362 G$_XPAGE$0$0 == 0x00aa
                    00AA    363 __XPAGE	=	0x00aa
                    00B1    364 G$OSCXCN$0$0 == 0x00b1
                    00B1    365 _OSCXCN	=	0x00b1
                    00B2    366 G$OSCICN$0$0 == 0x00b2
                    00B2    367 _OSCICN	=	0x00b2
                    00B3    368 G$OSCICL$0$0 == 0x00b3
                    00B3    369 _OSCICL	=	0x00b3
                    00B6    370 G$FLSCL$0$0 == 0x00b6
                    00B6    371 _FLSCL	=	0x00b6
                    00B7    372 G$FLKEY$0$0 == 0x00b7
                    00B7    373 _FLKEY	=	0x00b7
                    00B8    374 G$IP$0$0 == 0x00b8
                    00B8    375 _IP	=	0x00b8
                    00B9    376 G$IDA0CN$0$0 == 0x00b9
                    00B9    377 _IDA0CN	=	0x00b9
                    00BA    378 G$AMX0N$0$0 == 0x00ba
                    00BA    379 _AMX0N	=	0x00ba
                    00BB    380 G$AMX0P$0$0 == 0x00bb
                    00BB    381 _AMX0P	=	0x00bb
                    00BC    382 G$ADC0CF$0$0 == 0x00bc
                    00BC    383 _ADC0CF	=	0x00bc
                    00BD    384 G$ADC0L$0$0 == 0x00bd
                    00BD    385 _ADC0L	=	0x00bd
                    00BE    386 G$ADC0H$0$0 == 0x00be
                    00BE    387 _ADC0H	=	0x00be
                    00C0    388 G$SMB0CN$0$0 == 0x00c0
                    00C0    389 _SMB0CN	=	0x00c0
                    00C1    390 G$SMB0CF$0$0 == 0x00c1
                    00C1    391 _SMB0CF	=	0x00c1
                    00C2    392 G$SMB0DAT$0$0 == 0x00c2
                    00C2    393 _SMB0DAT	=	0x00c2
                    00C3    394 G$ADC0GTL$0$0 == 0x00c3
                    00C3    395 _ADC0GTL	=	0x00c3
                    00C4    396 G$ADC0GTH$0$0 == 0x00c4
                    00C4    397 _ADC0GTH	=	0x00c4
                    00C5    398 G$ADC0LTL$0$0 == 0x00c5
                    00C5    399 _ADC0LTL	=	0x00c5
                    00C6    400 G$ADC0LTH$0$0 == 0x00c6
                    00C6    401 _ADC0LTH	=	0x00c6
                    00C8    402 G$T2CON$0$0 == 0x00c8
                    00C8    403 _T2CON	=	0x00c8
                    00C8    404 G$TMR2CN$0$0 == 0x00c8
                    00C8    405 _TMR2CN	=	0x00c8
                    00CA    406 G$RCAP2L$0$0 == 0x00ca
                    00CA    407 _RCAP2L	=	0x00ca
                    00CA    408 G$TMR2RLL$0$0 == 0x00ca
                    00CA    409 _TMR2RLL	=	0x00ca
                    00CB    410 G$RCAP2H$0$0 == 0x00cb
                    00CB    411 _RCAP2H	=	0x00cb
                    00CB    412 G$TMR2RLH$0$0 == 0x00cb
                    00CB    413 _TMR2RLH	=	0x00cb
                    00CC    414 G$TL2$0$0 == 0x00cc
                    00CC    415 _TL2	=	0x00cc
                    00CC    416 G$TMR2L$0$0 == 0x00cc
                    00CC    417 _TMR2L	=	0x00cc
                    00CD    418 G$TH2$0$0 == 0x00cd
                    00CD    419 _TH2	=	0x00cd
                    00CD    420 G$TMR2H$0$0 == 0x00cd
                    00CD    421 _TMR2H	=	0x00cd
                    00D0    422 G$PSW$0$0 == 0x00d0
                    00D0    423 _PSW	=	0x00d0
                    00D1    424 G$REF0CN$0$0 == 0x00d1
                    00D1    425 _REF0CN	=	0x00d1
                    00D4    426 G$P0SKIP$0$0 == 0x00d4
                    00D4    427 _P0SKIP	=	0x00d4
                    00D5    428 G$P1SKIP$0$0 == 0x00d5
                    00D5    429 _P1SKIP	=	0x00d5
                    00D8    430 G$PCA0CN$0$0 == 0x00d8
                    00D8    431 _PCA0CN	=	0x00d8
                    00D9    432 G$PCA0MD$0$0 == 0x00d9
                    00D9    433 _PCA0MD	=	0x00d9
                    00DA    434 G$PCA0CPM0$0$0 == 0x00da
                    00DA    435 _PCA0CPM0	=	0x00da
                    00DB    436 G$PCA0CPM1$0$0 == 0x00db
                    00DB    437 _PCA0CPM1	=	0x00db
                    00DC    438 G$PCA0CPM2$0$0 == 0x00dc
                    00DC    439 _PCA0CPM2	=	0x00dc
                    00E0    440 G$ACC$0$0 == 0x00e0
                    00E0    441 _ACC	=	0x00e0
                    00E1    442 G$XBR0$0$0 == 0x00e1
                    00E1    443 _XBR0	=	0x00e1
                    00E2    444 G$XBR1$0$0 == 0x00e2
                    00E2    445 _XBR1	=	0x00e2
                    00E3    446 G$OSCLCN$0$0 == 0x00e3
                    00E3    447 _OSCLCN	=	0x00e3
                    00E4    448 G$IT01CF$0$0 == 0x00e4
                    00E4    449 _IT01CF	=	0x00e4
                    00E4    450 G$INT01CF$0$0 == 0x00e4
                    00E4    451 _INT01CF	=	0x00e4
                    00E6    452 G$EIE1$0$0 == 0x00e6
                    00E6    453 _EIE1	=	0x00e6
                    00E8    454 G$ADC0CN$0$0 == 0x00e8
                    00E8    455 _ADC0CN	=	0x00e8
                    00E9    456 G$PCA0CPL1$0$0 == 0x00e9
                    00E9    457 _PCA0CPL1	=	0x00e9
                    00EA    458 G$PCA0CPH1$0$0 == 0x00ea
                    00EA    459 _PCA0CPH1	=	0x00ea
                    00EB    460 G$PCA0CPL2$0$0 == 0x00eb
                    00EB    461 _PCA0CPL2	=	0x00eb
                    00EC    462 G$PCA0CPH2$0$0 == 0x00ec
                    00EC    463 _PCA0CPH2	=	0x00ec
                    00EF    464 G$RSTSRC$0$0 == 0x00ef
                    00EF    465 _RSTSRC	=	0x00ef
                    00F0    466 G$B$0$0 == 0x00f0
                    00F0    467 _B	=	0x00f0
                    00F1    468 G$P0MODE$0$0 == 0x00f1
                    00F1    469 _P0MODE	=	0x00f1
                    00F1    470 G$P0MDIN$0$0 == 0x00f1
                    00F1    471 _P0MDIN	=	0x00f1
                    00F2    472 G$P1MODE$0$0 == 0x00f2
                    00F2    473 _P1MODE	=	0x00f2
                    00F2    474 G$P1MDIN$0$0 == 0x00f2
                    00F2    475 _P1MDIN	=	0x00f2
                    00F6    476 G$EIP1$0$0 == 0x00f6
                    00F6    477 _EIP1	=	0x00f6
                    00F8    478 G$SPI0CN$0$0 == 0x00f8
                    00F8    479 _SPI0CN	=	0x00f8
                    00F9    480 G$PCA0L$0$0 == 0x00f9
                    00F9    481 _PCA0L	=	0x00f9
                    00FA    482 G$PCA0H$0$0 == 0x00fa
                    00FA    483 _PCA0H	=	0x00fa
                    00FB    484 G$PCA0CPL0$0$0 == 0x00fb
                    00FB    485 _PCA0CPL0	=	0x00fb
                    00FC    486 G$PCA0CPH0$0$0 == 0x00fc
                    00FC    487 _PCA0CPH0	=	0x00fc
                    00FF    488 G$VDM0CN$0$0 == 0x00ff
                    00FF    489 _VDM0CN	=	0x00ff
                    8C8A    490 G$TMR0$0$0 == 0x8c8a
                    8C8A    491 _TMR0	=	0x8c8a
                    8D8B    492 G$TMR1$0$0 == 0x8d8b
                    8D8B    493 _TMR1	=	0x8d8b
                    CDCC    494 G$TMR2$0$0 == 0xcdcc
                    CDCC    495 _TMR2	=	0xcdcc
                    CBCA    496 G$RCAP2$0$0 == 0xcbca
                    CBCA    497 _RCAP2	=	0xcbca
                    CBCA    498 G$TMR2RL$0$0 == 0xcbca
                    CBCA    499 _TMR2RL	=	0xcbca
                    9594    500 G$TMR3$0$0 == 0x9594
                    9594    501 _TMR3	=	0x9594
                    9392    502 G$TMR3RL$0$0 == 0x9392
                    9392    503 _TMR3RL	=	0x9392
                    9796    504 G$IDA0$0$0 == 0x9796
                    9796    505 _IDA0	=	0x9796
                    BEBD    506 G$ADC0$0$0 == 0xbebd
                    BEBD    507 _ADC0	=	0xbebd
                    C4C3    508 G$ADC0GT$0$0 == 0xc4c3
                    C4C3    509 _ADC0GT	=	0xc4c3
                    C6C5    510 G$ADC0LT$0$0 == 0xc6c5
                    C6C5    511 _ADC0LT	=	0xc6c5
                    FAF9    512 G$PCA0$0$0 == 0xfaf9
                    FAF9    513 _PCA0	=	0xfaf9
                    FCFB    514 G$PCA0CP0$0$0 == 0xfcfb
                    FCFB    515 _PCA0CP0	=	0xfcfb
                    EAE9    516 G$PCA0CP1$0$0 == 0xeae9
                    EAE9    517 _PCA0CP1	=	0xeae9
                    ECEB    518 G$PCA0CP2$0$0 == 0xeceb
                    ECEB    519 _PCA0CP2	=	0xeceb
                            520 ;--------------------------------------------------------
                            521 ; special function bits
                            522 ;--------------------------------------------------------
                            523 	.area RSEG    (DATA)
                    0080    524 G$P0_0$0$0 == 0x0080
                    0080    525 _P0_0	=	0x0080
                    0081    526 G$P0_1$0$0 == 0x0081
                    0081    527 _P0_1	=	0x0081
                    0082    528 G$P0_2$0$0 == 0x0082
                    0082    529 _P0_2	=	0x0082
                    0083    530 G$P0_3$0$0 == 0x0083
                    0083    531 _P0_3	=	0x0083
                    0084    532 G$P0_4$0$0 == 0x0084
                    0084    533 _P0_4	=	0x0084
                    0085    534 G$P0_5$0$0 == 0x0085
                    0085    535 _P0_5	=	0x0085
                    0086    536 G$P0_6$0$0 == 0x0086
                    0086    537 _P0_6	=	0x0086
                    0087    538 G$P0_7$0$0 == 0x0087
                    0087    539 _P0_7	=	0x0087
                    0088    540 G$IT0$0$0 == 0x0088
                    0088    541 _IT0	=	0x0088
                    0089    542 G$IE0$0$0 == 0x0089
                    0089    543 _IE0	=	0x0089
                    008A    544 G$IT1$0$0 == 0x008a
                    008A    545 _IT1	=	0x008a
                    008B    546 G$IE1$0$0 == 0x008b
                    008B    547 _IE1	=	0x008b
                    008C    548 G$TR0$0$0 == 0x008c
                    008C    549 _TR0	=	0x008c
                    008D    550 G$TF0$0$0 == 0x008d
                    008D    551 _TF0	=	0x008d
                    008E    552 G$TR1$0$0 == 0x008e
                    008E    553 _TR1	=	0x008e
                    008F    554 G$TF1$0$0 == 0x008f
                    008F    555 _TF1	=	0x008f
                    0090    556 G$P1_0$0$0 == 0x0090
                    0090    557 _P1_0	=	0x0090
                    0091    558 G$P1_1$0$0 == 0x0091
                    0091    559 _P1_1	=	0x0091
                    0092    560 G$P1_2$0$0 == 0x0092
                    0092    561 _P1_2	=	0x0092
                    0093    562 G$P1_3$0$0 == 0x0093
                    0093    563 _P1_3	=	0x0093
                    0094    564 G$P1_4$0$0 == 0x0094
                    0094    565 _P1_4	=	0x0094
                    0095    566 G$P1_5$0$0 == 0x0095
                    0095    567 _P1_5	=	0x0095
                    0096    568 G$P1_6$0$0 == 0x0096
                    0096    569 _P1_6	=	0x0096
                    0097    570 G$P1_7$0$0 == 0x0097
                    0097    571 _P1_7	=	0x0097
                    0098    572 G$RI$0$0 == 0x0098
                    0098    573 _RI	=	0x0098
                    0098    574 G$RI0$0$0 == 0x0098
                    0098    575 _RI0	=	0x0098
                    0099    576 G$TI$0$0 == 0x0099
                    0099    577 _TI	=	0x0099
                    0099    578 G$TI0$0$0 == 0x0099
                    0099    579 _TI0	=	0x0099
                    009A    580 G$RB8$0$0 == 0x009a
                    009A    581 _RB8	=	0x009a
                    009A    582 G$RB80$0$0 == 0x009a
                    009A    583 _RB80	=	0x009a
                    009B    584 G$TB8$0$0 == 0x009b
                    009B    585 _TB8	=	0x009b
                    009B    586 G$TB80$0$0 == 0x009b
                    009B    587 _TB80	=	0x009b
                    009C    588 G$REN$0$0 == 0x009c
                    009C    589 _REN	=	0x009c
                    009C    590 G$REN0$0$0 == 0x009c
                    009C    591 _REN0	=	0x009c
                    009D    592 G$SM2$0$0 == 0x009d
                    009D    593 _SM2	=	0x009d
                    009D    594 G$MCE0$0$0 == 0x009d
                    009D    595 _MCE0	=	0x009d
                    009F    596 G$SM0$0$0 == 0x009f
                    009F    597 _SM0	=	0x009f
                    009F    598 G$S0MODE$0$0 == 0x009f
                    009F    599 _S0MODE	=	0x009f
                    00A0    600 G$P2_0$0$0 == 0x00a0
                    00A0    601 _P2_0	=	0x00a0
                    00A1    602 G$P2_1$0$0 == 0x00a1
                    00A1    603 _P2_1	=	0x00a1
                    00A2    604 G$P2_2$0$0 == 0x00a2
                    00A2    605 _P2_2	=	0x00a2
                    00A3    606 G$P2_3$0$0 == 0x00a3
                    00A3    607 _P2_3	=	0x00a3
                    00A4    608 G$P2_4$0$0 == 0x00a4
                    00A4    609 _P2_4	=	0x00a4
                    00A5    610 G$P2_5$0$0 == 0x00a5
                    00A5    611 _P2_5	=	0x00a5
                    00A6    612 G$P2_6$0$0 == 0x00a6
                    00A6    613 _P2_6	=	0x00a6
                    00A7    614 G$P2_7$0$0 == 0x00a7
                    00A7    615 _P2_7	=	0x00a7
                    00A8    616 G$EX0$0$0 == 0x00a8
                    00A8    617 _EX0	=	0x00a8
                    00A9    618 G$ET0$0$0 == 0x00a9
                    00A9    619 _ET0	=	0x00a9
                    00AA    620 G$EX1$0$0 == 0x00aa
                    00AA    621 _EX1	=	0x00aa
                    00AB    622 G$ET1$0$0 == 0x00ab
                    00AB    623 _ET1	=	0x00ab
                    00AC    624 G$ES$0$0 == 0x00ac
                    00AC    625 _ES	=	0x00ac
                    00AC    626 G$ES0$0$0 == 0x00ac
                    00AC    627 _ES0	=	0x00ac
                    00AD    628 G$ET2$0$0 == 0x00ad
                    00AD    629 _ET2	=	0x00ad
                    00AE    630 G$ESPI0$0$0 == 0x00ae
                    00AE    631 _ESPI0	=	0x00ae
                    00AF    632 G$EA$0$0 == 0x00af
                    00AF    633 _EA	=	0x00af
                    00B8    634 G$PX0$0$0 == 0x00b8
                    00B8    635 _PX0	=	0x00b8
                    00B9    636 G$PT0$0$0 == 0x00b9
                    00B9    637 _PT0	=	0x00b9
                    00BA    638 G$PX1$0$0 == 0x00ba
                    00BA    639 _PX1	=	0x00ba
                    00BB    640 G$PT1$0$0 == 0x00bb
                    00BB    641 _PT1	=	0x00bb
                    00BC    642 G$PS$0$0 == 0x00bc
                    00BC    643 _PS	=	0x00bc
                    00BC    644 G$PS0$0$0 == 0x00bc
                    00BC    645 _PS0	=	0x00bc
                    00BD    646 G$PT2$0$0 == 0x00bd
                    00BD    647 _PT2	=	0x00bd
                    00BE    648 G$PSPI0$0$0 == 0x00be
                    00BE    649 _PSPI0	=	0x00be
                    00C0    650 G$SI$0$0 == 0x00c0
                    00C0    651 _SI	=	0x00c0
                    00C1    652 G$ACK$0$0 == 0x00c1
                    00C1    653 _ACK	=	0x00c1
                    00C2    654 G$ARBLOST$0$0 == 0x00c2
                    00C2    655 _ARBLOST	=	0x00c2
                    00C3    656 G$ACKRQ$0$0 == 0x00c3
                    00C3    657 _ACKRQ	=	0x00c3
                    00C4    658 G$STO$0$0 == 0x00c4
                    00C4    659 _STO	=	0x00c4
                    00C5    660 G$STA$0$0 == 0x00c5
                    00C5    661 _STA	=	0x00c5
                    00C6    662 G$TXMODE$0$0 == 0x00c6
                    00C6    663 _TXMODE	=	0x00c6
                    00C7    664 G$MASTER$0$0 == 0x00c7
                    00C7    665 _MASTER	=	0x00c7
                    00C8    666 G$T2XCLK$0$0 == 0x00c8
                    00C8    667 _T2XCLK	=	0x00c8
                    00CA    668 G$TR2$0$0 == 0x00ca
                    00CA    669 _TR2	=	0x00ca
                    00CB    670 G$T2SPLIT$0$0 == 0x00cb
                    00CB    671 _T2SPLIT	=	0x00cb
                    00CD    672 G$TF2CEN$0$0 == 0x00cd
                    00CD    673 _TF2CEN	=	0x00cd
                    00CD    674 G$TF2LEN$0$0 == 0x00cd
                    00CD    675 _TF2LEN	=	0x00cd
                    00CE    676 G$TF2L$0$0 == 0x00ce
                    00CE    677 _TF2L	=	0x00ce
                    00CF    678 G$TF2$0$0 == 0x00cf
                    00CF    679 _TF2	=	0x00cf
                    00CF    680 G$TF2H$0$0 == 0x00cf
                    00CF    681 _TF2H	=	0x00cf
                    00D0    682 G$PARITY$0$0 == 0x00d0
                    00D0    683 _PARITY	=	0x00d0
                    00D1    684 G$F1$0$0 == 0x00d1
                    00D1    685 _F1	=	0x00d1
                    00D2    686 G$OV$0$0 == 0x00d2
                    00D2    687 _OV	=	0x00d2
                    00D3    688 G$RS0$0$0 == 0x00d3
                    00D3    689 _RS0	=	0x00d3
                    00D4    690 G$RS1$0$0 == 0x00d4
                    00D4    691 _RS1	=	0x00d4
                    00D5    692 G$F0$0$0 == 0x00d5
                    00D5    693 _F0	=	0x00d5
                    00D6    694 G$AC$0$0 == 0x00d6
                    00D6    695 _AC	=	0x00d6
                    00D7    696 G$CY$0$0 == 0x00d7
                    00D7    697 _CY	=	0x00d7
                    00D8    698 G$CCF0$0$0 == 0x00d8
                    00D8    699 _CCF0	=	0x00d8
                    00D9    700 G$CCF1$0$0 == 0x00d9
                    00D9    701 _CCF1	=	0x00d9
                    00DA    702 G$CCF2$0$0 == 0x00da
                    00DA    703 _CCF2	=	0x00da
                    00DE    704 G$CR$0$0 == 0x00de
                    00DE    705 _CR	=	0x00de
                    00DF    706 G$CF$0$0 == 0x00df
                    00DF    707 _CF	=	0x00df
                    00E8    708 G$AD0CM0$0$0 == 0x00e8
                    00E8    709 _AD0CM0	=	0x00e8
                    00E9    710 G$AD0CM1$0$0 == 0x00e9
                    00E9    711 _AD0CM1	=	0x00e9
                    00EA    712 G$AD0CM2$0$0 == 0x00ea
                    00EA    713 _AD0CM2	=	0x00ea
                    00EB    714 G$AD0WINT$0$0 == 0x00eb
                    00EB    715 _AD0WINT	=	0x00eb
                    00EC    716 G$AD0BUSY$0$0 == 0x00ec
                    00EC    717 _AD0BUSY	=	0x00ec
                    00ED    718 G$AD0INT$0$0 == 0x00ed
                    00ED    719 _AD0INT	=	0x00ed
                    00EE    720 G$AD0TM$0$0 == 0x00ee
                    00EE    721 _AD0TM	=	0x00ee
                    00EF    722 G$AD0EN$0$0 == 0x00ef
                    00EF    723 _AD0EN	=	0x00ef
                    00F8    724 G$SPIEN$0$0 == 0x00f8
                    00F8    725 _SPIEN	=	0x00f8
                    00F9    726 G$TXBMT$0$0 == 0x00f9
                    00F9    727 _TXBMT	=	0x00f9
                    00FA    728 G$NSSMD0$0$0 == 0x00fa
                    00FA    729 _NSSMD0	=	0x00fa
                    00FB    730 G$NSSMD1$0$0 == 0x00fb
                    00FB    731 _NSSMD1	=	0x00fb
                    00FC    732 G$RXOVRN$0$0 == 0x00fc
                    00FC    733 _RXOVRN	=	0x00fc
                    00FD    734 G$MODF$0$0 == 0x00fd
                    00FD    735 _MODF	=	0x00fd
                    00FE    736 G$WCOL$0$0 == 0x00fe
                    00FE    737 _WCOL	=	0x00fe
                    00FF    738 G$SPIF$0$0 == 0x00ff
                    00FF    739 _SPIF	=	0x00ff
                            740 ;--------------------------------------------------------
                            741 ; overlayable register banks
                            742 ;--------------------------------------------------------
                            743 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     744 	.ds 8
                            745 	.area REG_BANK_2	(REL,OVR,DATA)
   0010                     746 	.ds 8
                            747 ;--------------------------------------------------------
                            748 ; internal ram data
                            749 ;--------------------------------------------------------
                            750 	.area DSEG    (DATA)
                    0000    751 G$Timer$0$0==.
   0022                     752 _Timer::
   0022                     753 	.ds 9
                    0009    754 FTSIPMon$TxRx_State$0$0==.
   002B                     755 _TxRx_State:
   002B                     756 	.ds 1
                    000A    757 FTSIPMon$TxRx_Count$0$0==.
   002C                     758 _TxRx_Count:
   002C                     759 	.ds 1
                    000B    760 G$ticks$0$0==.
   002D                     761 _ticks::
   002D                     762 	.ds 2
                    000D    763 FTSIPMon$p_TxRx_Buf$0$0==.
   002F                     764 _p_TxRx_Buf:
   002F                     765 	.ds 2
                    000F    766 LPrimaryTiming$yr$1$1==.
   0031                     767 _PrimaryTiming_yr_1_1:
   0031                     768 	.ds 2
                    0011    769 LSupplementalTiming$mode$1$1==.
   0033                     770 _SupplementalTiming_mode_1_1:
   0033                     771 	.ds 1
                    0012    772 LSupplementalTiming$RxBuf$1$1==.
   0034                     773 _SupplementalTiming_RxBuf_1_1:
   0034                     774 	.ds 2
                    0014    775 LSupplementalTiming$temp$1$1==.
   0036                     776 _SupplementalTiming_temp_1_1:
   0036                     777 	.ds 4
                    0018    778 LSupplementalTiming$val$1$1==.
   003A                     779 _SupplementalTiming_val_1_1:
   003A                     780 	.ds 1
                    0019    781 LSupplementalTiming$fval$1$1==.
   003B                     782 _SupplementalTiming_fval_1_1:
   003B                     783 	.ds 2
                    001B    784 LSupplementalTiming$sloc1$1$0==.
   003D                     785 _SupplementalTiming_sloc1_1_0:
   003D                     786 	.ds 4
                            787 ;--------------------------------------------------------
                            788 ; overlayable items in internal ram 
                            789 ;--------------------------------------------------------
                            790 	.area	OSEG    (OVR,DATA)
                            791 	.area	OSEG    (OVR,DATA)
                            792 	.area	OSEG    (OVR,DATA)
                    0000    793 LTimerStart$num_ticks$1$1==.
   000E                     794 _TimerStart_PARM_2::
   000E                     795 	.ds 2
                            796 	.area	OSEG    (OVR,DATA)
                            797 	.area	OSEG    (OVR,DATA)
                            798 	.area	OSEG    (OVR,DATA)
                            799 ;--------------------------------------------------------
                            800 ; Stack segment in internal ram 
                            801 ;--------------------------------------------------------
                            802 	.area	SSEG	(DATA)
   0047                     803 __start__stack:
   0047                     804 	.ds	1
                            805 
                            806 ;--------------------------------------------------------
                            807 ; indirectly addressable internal ram data
                            808 ;--------------------------------------------------------
                            809 	.area ISEG    (DATA)
                            810 ;--------------------------------------------------------
                            811 ; bit data
                            812 ;--------------------------------------------------------
                            813 	.area BSEG    (BIT)
                    0000    814 G$Rx_Pending$0$0==.
   0000                     815 _Rx_Pending::
   0000                     816 	.ds 1
                    0001    817 G$Tx_In_Progress$0$0==.
   0001                     818 _Tx_In_Progress::
   0001                     819 	.ds 1
                    0002    820 G$switch2$0$0==.
   0002                     821 _switch2::
   0002                     822 	.ds 1
                    0003    823 G$switch1$0$0==.
   0003                     824 _switch1::
   0003                     825 	.ds 1
                    0004    826 G$func2$0$0==.
   0004                     827 _func2::
   0004                     828 	.ds 1
                    0005    829 G$func1$0$0==.
   0005                     830 _func1::
   0005                     831 	.ds 1
                    0006    832 G$err1$0$0==.
   0006                     833 _err1::
   0006                     834 	.ds 1
                    0007    835 LSioIntService$bEvenDLE$1$1==.
   0007                     836 _SioIntService_bEvenDLE_1_1:
   0007                     837 	.ds 1
                    0008    838 LSupplementalTiming$b$1$1==.
   0008                     839 _SupplementalTiming_b_1_1:
   0008                     840 	.ds 1
                    0009    841 LSupplementalTiming$c$1$1==.
   0009                     842 _SupplementalTiming_c_1_1:
   0009                     843 	.ds 1
                            844 ;--------------------------------------------------------
                            845 ; paged external ram data
                            846 ;--------------------------------------------------------
                            847 	.area PSEG    (PAG,XDATA)
                            848 ;--------------------------------------------------------
                            849 ; external ram data
                            850 ;--------------------------------------------------------
                            851 	.area XSEG    (XDATA)
                    0000    852 G$Alarms$0$0==.
   0000                     853 _Alarms::
   0000                     854 	.ds 2
                    0002    855 G$lcdbuf$0$0==.
   0002                     856 _lcdbuf::
   0002                     857 	.ds 17
                    0013    858 G$TxRxBuf$0$0==.
   0013                     859 _TxRxBuf::
   0013                     860 	.ds 85
                    0068    861 LProcessRxMsg$pBuf$1$1==.
   0068                     862 _ProcessRxMsg_pBuf_1_1:
   0068                     863 	.ds 85
                            864 ;--------------------------------------------------------
                            865 ; external initialized ram data
                            866 ;--------------------------------------------------------
                            867 	.area XISEG   (XDATA)
                            868 	.area HOME    (CODE)
                            869 	.area GSINIT0 (CODE)
                            870 	.area GSINIT1 (CODE)
                            871 	.area GSINIT2 (CODE)
                            872 	.area GSINIT3 (CODE)
                            873 	.area GSINIT4 (CODE)
                            874 	.area GSINIT5 (CODE)
                            875 	.area GSINIT  (CODE)
                            876 	.area GSFINAL (CODE)
                            877 	.area CSEG    (CODE)
                            878 ;--------------------------------------------------------
                            879 ; interrupt vector 
                            880 ;--------------------------------------------------------
                            881 	.area HOME    (CODE)
   0000                     882 __interrupt_vect:
   0000 02 00 76            883 	ljmp	__sdcc_gsinit_startup
   0003 02 09 F8            884 	ljmp	_External_Interrupt_0
   0006                     885 	.ds	5
   000B 32                  886 	reti
   000C                     887 	.ds	7
   0013 02 0A 48            888 	ljmp	_External_Interrupt_1
   0016                     889 	.ds	5
   001B 02 0A 9B            890 	ljmp	_Timer_1_Overflow
   001E                     891 	.ds	5
   0023 02 03 49            892 	ljmp	_SioIntService
   0026                     893 	.ds	5
   002B 02 02 3A            894 	ljmp	_Timer2_ISR
   002E                     895 	.ds	5
   0033 02 0A 9C            896 	ljmp	_SPI0
   0036                     897 	.ds	5
   003B 02 0A 9D            898 	ljmp	_SMB0
   003E                     899 	.ds	5
   0043 32                  900 	reti
   0044                     901 	.ds	7
   004B 02 0A 9E            902 	ljmp	_ADC0_Window_Comparator
   004E                     903 	.ds	5
   0053 02 0A 9F            904 	ljmp	_ADC0_End_of_Conversion
   0056                     905 	.ds	5
   005B 02 0A A0            906 	ljmp	_Programmable_Counter_Array
   005E                     907 	.ds	5
   0063 02 0A A1            908 	ljmp	_Comparator
   0066                     909 	.ds	5
   006B 32                  910 	reti
   006C                     911 	.ds	7
   0073 02 0A A2            912 	ljmp	_Timer_3_Overflow
                            913 ;--------------------------------------------------------
                            914 ; global & static initialisations
                            915 ;--------------------------------------------------------
                            916 	.area HOME    (CODE)
                            917 	.area GSINIT  (CODE)
                            918 	.area GSFINAL (CODE)
                            919 	.area GSINIT  (CODE)
                            920 	.globl __sdcc_gsinit_startup
                            921 	.globl __sdcc_program_startup
                            922 	.globl __start__stack
                            923 	.globl __mcs51_genXINIT
                            924 	.globl __mcs51_genXRAMCLEAR
                            925 	.globl __mcs51_genRAMCLEAR
                            926 ;------------------------------------------------------------
                            927 ;Allocation info for local variables in function 'SupplementalTiming'
                            928 ;------------------------------------------------------------
                            929 ;mode                      Allocated with name '_SupplementalTiming_mode_1_1'
                            930 ;RxBuf                     Allocated with name '_SupplementalTiming_RxBuf_1_1'
                            931 ;temp                      Allocated with name '_SupplementalTiming_temp_1_1'
                            932 ;val                       Allocated with name '_SupplementalTiming_val_1_1'
                            933 ;fval                      Allocated with name '_SupplementalTiming_fval_1_1'
                            934 ;sloc0                     Allocated with name '_SupplementalTiming_sloc0_1_0'
                            935 ;sloc1                     Allocated with name '_SupplementalTiming_sloc1_1_0'
                            936 ;------------------------------------------------------------
                    0000    937 	G$SupplementalTiming$0$0 ==.
                    0000    938 	C$TSIPMon.c$769$2$1 ==.
                            939 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:769: static bit b = FALSE;
                            940 ;	genAssign
   00CF C2 08               941 	clr	_SupplementalTiming_b_1_1
                    0002    942 	C$TSIPMon.c$770$2$1 ==.
                            943 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:770: static bit c = FALSE;
                            944 ;	genAssign
   00D1 C2 09               945 	clr	_SupplementalTiming_c_1_1
                    0004    946 	C$TSIPMon.c$777$2$1 ==.
                            947 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:777: static char mode = -1;
                            948 ;	genAssign
   00D3 75 33 FF            949 	mov	_SupplementalTiming_mode_1_1,#0xFF
                    0007    950 	G$Timer_3_Overflow$0$0 ==.
                    0007    951 	C$TSIPMon.c$207$2$1 ==.
                            952 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:207: uint ticks = 0;
                            953 ;	genAssign
   00D6 E4                  954 	clr	a
   00D7 F5 2D               955 	mov	_ticks,a
   00D9 F5 2E               956 	mov	(_ticks + 1),a
                            957 	.area GSFINAL (CODE)
   00DB 02 00 DE            958 	ljmp	__sdcc_program_startup
                            959 ;--------------------------------------------------------
                            960 ; Home
                            961 ;--------------------------------------------------------
                            962 	.area HOME    (CODE)
                            963 	.area CSEG    (CODE)
   00DE                     964 __sdcc_program_startup:
   00DE 12 00 E3            965 	lcall	_main
                            966 ;	return from main will lock up
   00E1 80 FE               967 	sjmp .
                            968 ;--------------------------------------------------------
                            969 ; code
                            970 ;--------------------------------------------------------
                            971 	.area CSEG    (CODE)
                            972 ;------------------------------------------------------------
                            973 ;Allocation info for local variables in function 'main'
                            974 ;------------------------------------------------------------
                            975 ;------------------------------------------------------------
                    0005    976 	G$main$0$0 ==.
                    0005    977 	C$TSIPMon.c$221$0$0 ==.
                            978 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:221: void main( void ){
                            979 ;	-----------------------------------------
                            980 ;	 function main
                            981 ;	-----------------------------------------
   00E3                     982 _main:
                    0002    983 	ar2 = 0x02
                    0003    984 	ar3 = 0x03
                    0004    985 	ar4 = 0x04
                    0005    986 	ar5 = 0x05
                    0006    987 	ar6 = 0x06
                    0007    988 	ar7 = 0x07
                    0000    989 	ar0 = 0x00
                    0001    990 	ar1 = 0x01
                    0005    991 	C$TSIPMon.c$223$1$1 ==.
                            992 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:223: PCA0MD &= ~0x40;					// Clear watchdog timer enable
                            993 ;	genAnd
   00E3 53 D9 BF            994 	anl	_PCA0MD,#0xBF
                    0008    995 	C$TSIPMon.c$225$1$1 ==.
                            996 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:225: Timer2_Init();						// Initialize the Timer2
                            997 ;	genCall
   00E6 12 02 05            998 	lcall	_Timer2_Init
                    000B    999 	C$TSIPMon.c$226$1$1 ==.
                           1000 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:226: Port_Init();						// Init Ports
                           1001 ;	genCall
   00E9 12 01 EB           1002 	lcall	_Port_Init
                    000E   1003 	C$TSIPMon.c$227$1$1 ==.
                           1004 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:227: UART0_Init();
                           1005 ;	genCall
   00EC 12 03 29           1006 	lcall	_UART0_Init
                    0011   1007 	C$TSIPMon.c$228$1$1 ==.
                           1008 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:228: EA = TRUE;							// Enable global interrupts
                           1009 ;	genAssign
   00EF D2 AF              1010 	setb	_EA
                    0013   1011 	C$TSIPMon.c$229$1$1 ==.
                           1012 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:229: LED = 0;							// turn ON LED
                           1013 ;	genAssign
   00F1 C2 93              1014 	clr	_P1_3
                    0015   1015 	C$TSIPMon.c$230$1$1 ==.
                           1016 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:230: LED2 = 1;							// turn ON LED2
                           1017 ;	genAssign
   00F3 D2 87              1018 	setb	_P0_7
                    0017   1019 	C$TSIPMon.c$231$1$1 ==.
                           1020 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:231: LED1 = 1;							// turn ON LED1
                           1021 ;	genAssign
   00F5 D2 83              1022 	setb	_P0_3
                    0019   1023 	C$TSIPMon.c$232$1$1 ==.
                           1024 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:232: TimerStart( SYS_TIMER, 500 );		// wait for display to wake up
                           1025 ;	genAssign
   00F7 75 0E F4           1026 	mov	_TimerStart_PARM_2,#0xF4
   00FA 75 0F 01           1027 	mov	(_TimerStart_PARM_2 + 1),#0x01
                           1028 ;	genCall
   00FD 75 82 00           1029 	mov	dpl,#0x00
   0100 12 02 BC           1030 	lcall	_TimerStart
                    0025   1031 	C$TSIPMon.c$233$1$1 ==.
                           1032 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:233: while( !TimerReady( SYS_TIMER ))
   0103                    1033 00101$:
                           1034 ;	genCall
   0103 75 82 00           1035 	mov	dpl,#0x00
   0106 12 03 11           1036 	lcall	_TimerReady
                           1037 ;	genIfx
                           1038 ;	genIfxJump
                           1039 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           1040 ;	Peephole 128	jump optimization
   0109 50 F8              1041 	jnc	00101$
                           1042 ;	Peephole 300	removed redundant label 00130$
                    002D   1043 	C$TSIPMon.c$235$1$1 ==.
                           1044 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:235: InitLCD();							// Init LCD Controller
                           1045 ;	genCall
   010B 12 0A A3           1046 	lcall	_InitLCD
                    0030   1047 	C$TSIPMon.c$236$1$1 ==.
                           1048 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:236: ClearLCD( 3 );						// Clear display
                           1049 ;	genCall
   010E 75 82 03           1050 	mov	dpl,#0x03
   0111 12 0A EB           1051 	lcall	_ClearLCD
                    0036   1052 	C$TSIPMon.c$237$1$1 ==.
                           1053 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:237: printCode2LCD( 1, VersionMsg, 0 );
                           1054 ;	genAddrOf
   0114 75 0B 10           1055 	mov	_printCode2LCD_PARM_2,#_VersionMsg
   0117 75 0C 15           1056 	mov	(_printCode2LCD_PARM_2 + 1),#(_VersionMsg >> 8)
                           1057 ;	genAssign
   011A 75 0D 00           1058 	mov	_printCode2LCD_PARM_3,#0x00
                           1059 ;	genCall
   011D 75 82 01           1060 	mov	dpl,#0x01
   0120 12 0B AD           1061 	lcall	_printCode2LCD
                    0045   1062 	C$TSIPMon.c$238$1$1 ==.
                           1063 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:238: printCode2LCD( 2, LCDInitMsg, 0 );
                           1064 ;	genAddrOf
   0123 75 0B 21           1065 	mov	_printCode2LCD_PARM_2,#_LCDInitMsg
   0126 75 0C 15           1066 	mov	(_printCode2LCD_PARM_2 + 1),#(_LCDInitMsg >> 8)
                           1067 ;	genAssign
   0129 75 0D 00           1068 	mov	_printCode2LCD_PARM_3,#0x00
                           1069 ;	genCall
   012C 75 82 02           1070 	mov	dpl,#0x02
   012F 12 0B AD           1071 	lcall	_printCode2LCD
                    0054   1072 	C$TSIPMon.c$240$1$1 ==.
                           1073 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:240: TimerStart( SYS_TIMER, 1500 );
                           1074 ;	genAssign
   0132 75 0E DC           1075 	mov	_TimerStart_PARM_2,#0xDC
   0135 75 0F 05           1076 	mov	(_TimerStart_PARM_2 + 1),#0x05
                           1077 ;	genCall
   0138 75 82 00           1078 	mov	dpl,#0x00
   013B 12 02 BC           1079 	lcall	_TimerStart
                    0060   1080 	C$TSIPMon.c$241$1$1 ==.
                           1081 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:241: while( !TimerReady( SYS_TIMER ))
   013E                    1082 00104$:
                           1083 ;	genCall
   013E 75 82 00           1084 	mov	dpl,#0x00
   0141 12 03 11           1085 	lcall	_TimerReady
                           1086 ;	genIfx
                           1087 ;	genIfxJump
                           1088 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           1089 ;	Peephole 128	jump optimization
   0144 50 F8              1090 	jnc	00104$
                           1091 ;	Peephole 300	removed redundant label 00131$
                    0068   1092 	C$TSIPMon.c$243$1$1 ==.
                           1093 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:243: ClearLCD( 3 );
                           1094 ;	genCall
   0146 75 82 03           1095 	mov	dpl,#0x03
   0149 12 0A EB           1096 	lcall	_ClearLCD
                    006E   1097 	C$TSIPMon.c$244$1$1 ==.
                           1098 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:244: LED2 = 0;							// turn OFF LED2
                           1099 ;	genAssign
   014C C2 87              1100 	clr	_P0_7
                    0070   1101 	C$TSIPMon.c$245$1$1 ==.
                           1102 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:245: LED1 = 0;							// turn OFF LED1
                           1103 ;	genAssign
   014E C2 83              1104 	clr	_P0_3
                    0072   1105 	C$TSIPMon.c$246$1$1 ==.
                           1106 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:246: func2 = FALSE;
                           1107 ;	genAssign
   0150 C2 04              1108 	clr	_func2
                    0074   1109 	C$TSIPMon.c$247$1$1 ==.
                           1110 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:247: func1 = FALSE;
                           1111 ;	genAssign
   0152 C2 05              1112 	clr	_func1
                    0076   1113 	C$TSIPMon.c$248$1$1 ==.
                           1114 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:248: err1 = FALSE;
                           1115 ;	genAssign
   0154 C2 06              1116 	clr	_err1
                    0078   1117 	C$TSIPMon.c$250$1$1 ==.
                           1118 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:250: printCode2LCD( 1, "Waiting for GPS", 0 );
                           1119 ;	genAddrOf
   0156 75 0B 44           1120 	mov	_printCode2LCD_PARM_2,#__str_0
   0159 75 0C 15           1121 	mov	(_printCode2LCD_PARM_2 + 1),#(__str_0 >> 8)
                           1122 ;	genAssign
   015C 75 0D 00           1123 	mov	_printCode2LCD_PARM_3,#0x00
                           1124 ;	genCall
   015F 75 82 01           1125 	mov	dpl,#0x01
   0162 12 0B AD           1126 	lcall	_printCode2LCD
                    0087   1127 	C$TSIPMon.c$251$1$1 ==.
                           1128 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:251: TimerStart( SYS_TIMER, 2500 );
                           1129 ;	genAssign
   0165 75 0E C4           1130 	mov	_TimerStart_PARM_2,#0xC4
   0168 75 0F 09           1131 	mov	(_TimerStart_PARM_2 + 1),#0x09
                           1132 ;	genCall
   016B 75 82 00           1133 	mov	dpl,#0x00
   016E 12 02 BC           1134 	lcall	_TimerStart
                    0093   1135 	C$TSIPMon.c$252$1$1 ==.
                           1136 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:252: LED = 1;							// turn OFF LED
                           1137 ;	genAssign
   0171 D2 93              1138 	setb	_P1_3
                    0095   1139 	C$TSIPMon.c$253$1$1 ==.
                           1140 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:253: TimerStart( SWITCH_TIMER, 50 );		// switch timer
                           1141 ;	genAssign
   0173 75 0E 32           1142 	mov	_TimerStart_PARM_2,#0x32
   0176 E4                 1143 	clr	a
   0177 F5 0F              1144 	mov	(_TimerStart_PARM_2 + 1),a
                           1145 ;	genCall
   0179 75 82 02           1146 	mov	dpl,#0x02
   017C 12 02 BC           1147 	lcall	_TimerStart
                    00A1   1148 	C$TSIPMon.c$255$1$1 ==.
                           1149 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:255: while( 1 ){							// Loop forever
   017F                    1150 00117$:
                    00A1   1151 	C$TSIPMon.c$256$2$2 ==.
                           1152 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:256: if( Rx_Pending ){
                           1153 ;	genIfx
                           1154 ;	genIfxJump
                           1155 ;	Peephole 108.d	removed ljmp by inverse jump logic
   017F 30 00 17           1156 	jnb	_Rx_Pending,00108$
                           1157 ;	Peephole 300	removed redundant label 00132$
                    00A4   1158 	C$TSIPMon.c$257$3$3 ==.
                           1159 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:257: TimerReset( SYS_TIMER );
                           1160 ;	genCall
   0182 75 82 00           1161 	mov	dpl,#0x00
   0185 12 02 F4           1162 	lcall	_TimerReset
                    00AA   1163 	C$TSIPMon.c$258$3$3 ==.
                           1164 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:258: ProcessRxMsg();
                           1165 ;	genCall
   0188 12 04 E0           1166 	lcall	_ProcessRxMsg
                    00AD   1167 	C$TSIPMon.c$259$3$3 ==.
                           1168 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:259: TimerStart( SYS_TIMER, 1200 );
                           1169 ;	genAssign
   018B 75 0E B0           1170 	mov	_TimerStart_PARM_2,#0xB0
   018E 75 0F 04           1171 	mov	(_TimerStart_PARM_2 + 1),#0x04
                           1172 ;	genCall
   0191 75 82 00           1173 	mov	dpl,#0x00
   0194 12 02 BC           1174 	lcall	_TimerStart
                    00B9   1175 	C$TSIPMon.c$260$3$3 ==.
                           1176 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:260: err1 = FALSE;
                           1177 ;	genAssign
   0197 C2 06              1178 	clr	_err1
   0199                    1179 00108$:
                    00BB   1180 	C$TSIPMon.c$262$2$2 ==.
                           1181 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:262: if( TimerReady( SYS_TIMER )){
                           1182 ;	genCall
   0199 75 82 00           1183 	mov	dpl,#0x00
   019C 12 03 11           1184 	lcall	_TimerReady
                           1185 ;	genIfx
                           1186 ;	genIfxJump
                           1187 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           1188 ;	Peephole 128	jump optimization
   019F 50 36              1189 	jnc	00113$
                           1190 ;	Peephole 300	removed redundant label 00133$
                    00C3   1191 	C$TSIPMon.c$263$3$4 ==.
                           1192 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:263: if( !err1 ){
                           1193 ;	genIfx
                           1194 ;	genIfxJump
                           1195 ;	Peephole 108.e	removed ljmp by inverse jump logic
   01A1 20 06 1F           1196 	jb	_err1,00110$
                           1197 ;	Peephole 300	removed redundant label 00134$
                    00C6   1198 	C$TSIPMon.c$264$4$5 ==.
                           1199 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:264: TimerStart( SYS_TIMER, 1200 );
                           1200 ;	genAssign
   01A4 75 0E B0           1201 	mov	_TimerStart_PARM_2,#0xB0
   01A7 75 0F 04           1202 	mov	(_TimerStart_PARM_2 + 1),#0x04
                           1203 ;	genCall
   01AA 75 82 00           1204 	mov	dpl,#0x00
   01AD 12 02 BC           1205 	lcall	_TimerStart
                    00D2   1206 	C$TSIPMon.c$265$4$5 ==.
                           1207 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:265: printCode2LCD( 1, "   No Message   ", 0 );
                           1208 ;	genAddrOf
   01B0 75 0B 54           1209 	mov	_printCode2LCD_PARM_2,#__str_1
   01B3 75 0C 15           1210 	mov	(_printCode2LCD_PARM_2 + 1),#(__str_1 >> 8)
                           1211 ;	genAssign
   01B6 75 0D 00           1212 	mov	_printCode2LCD_PARM_3,#0x00
                           1213 ;	genCall
   01B9 75 82 01           1214 	mov	dpl,#0x01
   01BC 12 0B AD           1215 	lcall	_printCode2LCD
                    00E1   1216 	C$TSIPMon.c$267$4$5 ==.
                           1217 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:267: err1 = TRUE;
                           1218 ;	genAssign
   01BF D2 06              1219 	setb	_err1
                           1220 ;	Peephole 112.b	changed ljmp to sjmp
   01C1 80 14              1221 	sjmp	00113$
   01C3                    1222 00110$:
                    00E5   1223 	C$TSIPMon.c$269$4$6 ==.
                           1224 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:269: TimerStart( SYS_TIMER, 500 );
                           1225 ;	genAssign
   01C3 75 0E F4           1226 	mov	_TimerStart_PARM_2,#0xF4
   01C6 75 0F 01           1227 	mov	(_TimerStart_PARM_2 + 1),#0x01
                           1228 ;	genCall
   01C9 75 82 00           1229 	mov	dpl,#0x00
   01CC 12 02 BC           1230 	lcall	_TimerStart
                    00F1   1231 	C$TSIPMon.c$270$4$6 ==.
                           1232 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:270: ClearLCD( 3 );
                           1233 ;	genCall
   01CF 75 82 03           1234 	mov	dpl,#0x03
   01D2 12 0A EB           1235 	lcall	_ClearLCD
                    00F7   1236 	C$TSIPMon.c$271$4$6 ==.
                           1237 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:271: err1 = FALSE;
                           1238 ;	genAssign
   01D5 C2 06              1239 	clr	_err1
   01D7                    1240 00113$:
                    00F9   1241 	C$TSIPMon.c$275$2$2 ==.
                           1242 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:275: if( TimerReady( SWITCH_TIMER )){
                           1243 ;	genCall
   01D7 75 82 02           1244 	mov	dpl,#0x02
   01DA 12 03 11           1245 	lcall	_TimerReady
                           1246 ;	genIfx
                           1247 ;	genIfxJump
                           1248 ;	Peephole 108.c	removed ljmp by inverse jump logic
                           1249 ;	Peephole 128	jump optimization
   01DD 50 A0              1250 	jnc	00117$
                           1251 ;	Peephole 300	removed redundant label 00135$
                    0101   1252 	C$TSIPMon.c$276$3$7 ==.
                           1253 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:276: switch1 = 1;
                           1254 ;	genAssign
   01DF D2 03              1255 	setb	_switch1
                    0103   1256 	C$TSIPMon.c$277$3$7 ==.
                           1257 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:277: switch2 = 1;
                           1258 ;	genAssign
   01E1 D2 02              1259 	setb	_switch2
                    0105   1260 	C$TSIPMon.c$278$3$7 ==.
                           1261 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:278: TimerReset( SWITCH_TIMER );
                           1262 ;	genCall
   01E3 75 82 02           1263 	mov	dpl,#0x02
   01E6 12 02 F4           1264 	lcall	_TimerReset
                           1265 ;	Peephole 112.b	changed ljmp to sjmp
                    010B   1266 	C$TSIPMon.c$282$1$1 ==.
                    010B   1267 	XG$main$0$0 ==.
   01E9 80 94              1268 	sjmp	00117$
                           1269 ;	Peephole 259.a	removed redundant label 00119$ and ret
                           1270 ;
                           1271 ;------------------------------------------------------------
                           1272 ;Allocation info for local variables in function 'Port_Init'
                           1273 ;------------------------------------------------------------
                           1274 ;------------------------------------------------------------
                    010D   1275 	G$Port_Init$0$0 ==.
                    010D   1276 	C$TSIPMon.c$310$1$1 ==.
                           1277 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:310: void Port_Init( void ){
                           1278 ;	-----------------------------------------
                           1279 ;	 function Port_Init
                           1280 ;	-----------------------------------------
   01EB                    1281 _Port_Init:
                    010D   1282 	C$TSIPMon.c$312$1$1 ==.
                           1283 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:312: P0SKIP    = 0x01;					// P0.0 -> Vref
                           1284 ;	genAssign
   01EB 75 D4 01           1285 	mov	_P0SKIP,#0x01
                    0110   1286 	C$TSIPMon.c$313$1$1 ==.
                           1287 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:313: P0MDOUT = 0x98;						// Tx, LED2, LED1 are push-pull
                           1288 ;	genAssign
   01EE 75 A4 98           1289 	mov	_P0MDOUT,#0x98
                    0113   1290 	C$TSIPMon.c$314$1$1 ==.
                           1291 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:314: XBR0 = 0x01;						// enable UART
                           1292 ;	genAssign
   01F1 75 E1 01           1293 	mov	_XBR0,#0x01
                    0116   1294 	C$TSIPMon.c$315$1$1 ==.
                           1295 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:315: XBR1 = 0x40;                        // Enable crossbar
                           1296 ;	genAssign
   01F4 75 E2 40           1297 	mov	_XBR1,#0x40
                    0119   1298 	C$TSIPMon.c$317$1$1 ==.
                           1299 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:317: P1MDOUT = 0x7F;						// make LCD_PORT push-pull (except busy flag) v021
                           1300 ;	genAssign
   01F7 75 A5 7F           1301 	mov	_P1MDOUT,#0x7F
                    011C   1302 	C$TSIPMon.c$320$1$1 ==.
                           1303 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:320: IE        |= 0x05;		// enable /INT0 and /INT1
                           1304 ;	genOr
   01FA 43 A8 05           1305 	orl	_IE,#0x05
                    011F   1306 	C$TSIPMon.c$321$1$1 ==.
                           1307 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:321: IT01CF    = 0x21;		// /INT0 and /INT1 active low, P0.1 and P0.2 respectively
                           1308 ;	genAssign
   01FD 75 E4 21           1309 	mov	_IT01CF,#0x21
                    0122   1310 	C$TSIPMon.c$328$1$1 ==.
                           1311 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:328: IT0 = 1;	// /INT0 edge triggered
                           1312 ;	genAssign
   0200 D2 88              1313 	setb	_IT0
                    0124   1314 	C$TSIPMon.c$329$1$1 ==.
                           1315 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:329: IT1 = 1;	// /INT1 edge triggered
                           1316 ;	genAssign
   0202 D2 8A              1317 	setb	_IT1
                           1318 ;	Peephole 300	removed redundant label 00101$
                    0126   1319 	C$TSIPMon.c$333$1$1 ==.
                    0126   1320 	XG$Port_Init$0$0 ==.
   0204 22                 1321 	ret
                           1322 ;------------------------------------------------------------
                           1323 ;Allocation info for local variables in function 'Timer2_Init'
                           1324 ;------------------------------------------------------------
                           1325 ;i                         Allocated to registers r2 
                           1326 ;------------------------------------------------------------
                    0127   1327 	G$Timer2_Init$0$0 ==.
                    0127   1328 	C$TSIPMon.c$348$1$1 ==.
                           1329 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:348: void Timer2_Init( void ){
                           1330 ;	-----------------------------------------
                           1331 ;	 function Timer2_Init
                           1332 ;	-----------------------------------------
   0205                    1333 _Timer2_Init:
                    0127   1334 	C$TSIPMon.c$352$1$1 ==.
                           1335 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:352: CKCON &= ~0x60;                     // Timer2 uses SYSCLK/12
                           1336 ;	genAnd
   0205 53 8E 9F           1337 	anl	_CKCON,#0x9F
                    012A   1338 	C$TSIPMon.c$353$1$1 ==.
                           1339 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:353: TMR2CN &= ~0x01;					// Set bit 0 low, select SYSCLK/12
                           1340 ;	genAnd
   0208 53 C8 FE           1341 	anl	_TMR2CN,#0xFE
                    012D   1342 	C$TSIPMon.c$355$1$1 ==.
                           1343 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:355: TMR2RL = TIMER2_RELOAD;             // Reload value to be used in Timer2
                           1344 ;	genAssign
   020B 75 CA 02           1345 	mov	_TMR2RL,#0x02
   020E 75 CB FE           1346 	mov	(_TMR2RL >> 8),#0xFE
                    0133   1347 	C$TSIPMon.c$356$1$1 ==.
                           1348 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:356: TMR2 = TMR2RL;                      // Init the Timer2 register
                           1349 ;	genAssign
   0211 85 CA CC           1350 	mov	_TMR2,_TMR2RL
   0214 85 CB CD           1351 	mov	(_TMR2 >> 8),(_TMR2RL >> 8)
                    0139   1352 	C$TSIPMon.c$358$1$1 ==.
                           1353 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:358: TMR2CN = 0x04;                      // Enable Timer2 in auto-reload mode
                           1354 ;	genAssign
   0217 75 C8 04           1355 	mov	_TMR2CN,#0x04
                    013C   1356 	C$TSIPMon.c$359$1$1 ==.
                           1357 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:359: ET2 = 1;                            // Timer2 interrupt enabled
                           1358 ;	genAssign
   021A D2 AD              1359 	setb	_ET2
                    013E   1360 	C$TSIPMon.c$361$1$1 ==.
                           1361 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:361: for( i = 0; i < NUM_TIMERS; i++ ){	// Initialize software timers.
                           1362 ;	genAssign
   021C 7A 03              1363 	mov	r2,#0x03
   021E                    1364 00103$:
                    0140   1365 	C$TSIPMon.c$362$2$2 ==.
                           1366 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:362: Timer[i].Status = 0;
                           1367 ;	genMinus
                           1368 ;	genMinusDec
   021E EA                 1369 	mov	a,r2
   021F 14                 1370 	dec	a
                           1371 ;	genMult
                           1372 ;	genMultOneByte
   0220 FB                 1373 	mov	r3,a
                           1374 ;	Peephole 105	removed redundant mov
   0221 75 F0 03           1375 	mov	b,#0x03
   0224 A4                 1376 	mul	ab
                           1377 ;	genPlus
   0225 24 22              1378 	add	a,#_Timer
   0227 F8                 1379 	mov	r0,a
                           1380 ;	genPlus
                           1381 ;     genPlusIncr
   0228 74 02              1382 	mov	a,#0x02
                           1383 ;	Peephole 236.a	used r0 instead of ar0
   022A 28                 1384 	add	a,r0
                           1385 ;	genPointerSet
                           1386 ;	genNearPointerSet
                           1387 ;	Peephole 239	used a instead of acc
   022B F9                 1388 	mov	r1,a
   022C 77 00              1389 	mov	@r1,#0x00
                    0150   1390 	C$TSIPMon.c$363$2$2 ==.
                           1391 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:363: Timer[i].WaitTime = 0;
                           1392 ;	genPointerSet
                           1393 ;	genNearPointerSet
   022E 76 00              1394 	mov	@r0,#0x00
   0230 08                 1395 	inc	r0
   0231 76 00              1396 	mov	@r0,#0x00
   0233 18                 1397 	dec	r0
                           1398 ;	genAssign
   0234 8B 02              1399 	mov	ar2,r3
                    0158   1400 	C$TSIPMon.c$361$2$2 ==.
                           1401 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:361: for( i = 0; i < NUM_TIMERS; i++ ){	// Initialize software timers.
                           1402 ;	genIfx
   0236 EA                 1403 	mov	a,r2
                           1404 ;	genIfxJump
                           1405 ;	Peephole 108.b	removed ljmp by inverse jump logic
   0237 70 E5              1406 	jnz	00103$
                           1407 ;	Peephole 300	removed redundant label 00108$
                           1408 ;	Peephole 300	removed redundant label 00104$
                    015B   1409 	C$TSIPMon.c$366$2$2 ==.
                    015B   1410 	XG$Timer2_Init$0$0 ==.
   0239 22                 1411 	ret
                           1412 ;------------------------------------------------------------
                           1413 ;Allocation info for local variables in function 'Timer2_ISR'
                           1414 ;------------------------------------------------------------
                           1415 ;i                         Allocated to registers r2 
                           1416 ;------------------------------------------------------------
                    015C   1417 	G$Timer2_ISR$0$0 ==.
                    015C   1418 	C$TSIPMon.c$380$2$2 ==.
                           1419 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:380: void Timer2_ISR( void ) interrupt 5{
                           1420 ;	-----------------------------------------
                           1421 ;	 function Timer2_ISR
                           1422 ;	-----------------------------------------
   023A                    1423 _Timer2_ISR:
   023A C0 E0              1424 	push	acc
   023C C0 F0              1425 	push	b
   023E C0 02              1426 	push	ar2
   0240 C0 03              1427 	push	ar3
   0242 C0 04              1428 	push	ar4
   0244 C0 05              1429 	push	ar5
   0246 C0 00              1430 	push	ar0
   0248 C0 D0              1431 	push	psw
   024A 75 D0 00           1432 	mov	psw,#0x00
                    016F   1433 	C$TSIPMon.c$385$1$1 ==.
                           1434 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:385: TF2H = 0;                           	// Reset Interrupt
                           1435 ;	genAssign
   024D C2 CF              1436 	clr	_TF2H
                    0171   1437 	C$TSIPMon.c$386$1$1 ==.
                           1438 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:386: if( ticks > 0 )
                           1439 ;	genIfx
   024F E5 2D              1440 	mov	a,_ticks
   0251 45 2E              1441 	orl	a,(_ticks + 1)
                           1442 ;	genIfxJump
                           1443 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0253 60 09              1444 	jz	00115$
                           1445 ;	Peephole 300	removed redundant label 00117$
                    0177   1446 	C$TSIPMon.c$387$1$1 ==.
                           1447 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:387: ticks--;
                           1448 ;	genMinus
                           1449 ;	genMinusDec
   0255 15 2D              1450 	dec	_ticks
   0257 74 FF              1451 	mov	a,#0xff
   0259 B5 2D 02           1452 	cjne	a,_ticks,00118$
   025C 15 2E              1453 	dec	(_ticks + 1)
   025E                    1454 00118$:
                    0180   1455 	C$TSIPMon.c$388$1$1 ==.
                           1456 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:388: for( i = 0; i < NUM_TIMERS; i++ ){		// Cycle through all timers, to update.
   025E                    1457 00115$:
                           1458 ;	genAssign
   025E 7A 00              1459 	mov	r2,#0x00
   0260                    1460 00106$:
                           1461 ;	genCmpLt
                           1462 ;	genCmp
   0260 BA 03 00           1463 	cjne	r2,#0x03,00119$
   0263                    1464 00119$:
                           1465 ;	genIfxJump
                           1466 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0263 50 33              1467 	jnc	00110$
                           1468 ;	Peephole 300	removed redundant label 00120$
                    0187   1469 	C$TSIPMon.c$389$2$2 ==.
                           1470 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:389: if( Timer[i].WaitTime > 0 ){		// Is it Expired?
                           1471 ;	genMult
                           1472 ;	genMultOneByte
   0265 EA                 1473 	mov	a,r2
   0266 75 F0 03           1474 	mov	b,#0x03
   0269 A4                 1475 	mul	ab
                           1476 ;	genPlus
   026A FB                 1477 	mov	r3,a
                           1478 ;	Peephole 177.b	removed redundant mov
   026B 24 22              1479 	add	a,#_Timer
   026D F8                 1480 	mov	r0,a
                           1481 ;	genPointerGet
                           1482 ;	genNearPointerGet
   026E 86 04              1483 	mov	ar4,@r0
   0270 08                 1484 	inc	r0
   0271 86 05              1485 	mov	ar5,@r0
   0273 18                 1486 	dec	r0
                           1487 ;	genIfx
   0274 EC                 1488 	mov	a,r4
   0275 4D                 1489 	orl	a,r5
                           1490 ;	genIfxJump
                           1491 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0276 60 15              1492 	jz	00104$
                           1493 ;	Peephole 300	removed redundant label 00121$
                    019A   1494 	C$TSIPMon.c$390$3$3 ==.
                           1495 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:390: Timer[i].WaitTime--;			// No: Count it down.
                           1496 ;	genMinus
                           1497 ;	genMinusDec
   0278 1C                 1498 	dec	r4
   0279 BC FF 01           1499 	cjne	r4,#0xff,00122$
   027C 1D                 1500 	dec	r5
   027D                    1501 00122$:
                           1502 ;	genPointerSet
                           1503 ;	genNearPointerSet
   027D A6 04              1504 	mov	@r0,ar4
   027F 08                 1505 	inc	r0
   0280 A6 05              1506 	mov	@r0,ar5
   0282 18                 1507 	dec	r0
                    01A5   1508 	C$TSIPMon.c$391$3$3 ==.
                           1509 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:391: Timer[i].Status = TIMER_STATUS_RUNNING;
                           1510 ;	genPlus
                           1511 ;	Peephole 236.g	used r3 instead of ar3
   0283 EB                 1512 	mov	a,r3
   0284 24 22              1513 	add	a,#_Timer
                           1514 ;	genPlus
                           1515 ;     genPlusIncr
   0286 24 02              1516 	add	a,#0x02
                           1517 ;	genPointerSet
                           1518 ;	genNearPointerSet
                           1519 ;	Peephole 239	used a instead of acc
   0288 F8                 1520 	mov	r0,a
   0289 76 01              1521 	mov	@r0,#0x01
                           1522 ;	Peephole 112.b	changed ljmp to sjmp
   028B 80 08              1523 	sjmp	00108$
   028D                    1524 00104$:
                    01AF   1525 	C$TSIPMon.c$393$3$4 ==.
                           1526 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:393: Timer[i].Status = TIMER_STATUS_READY;
                           1527 ;	genPlus
                           1528 ;	Peephole 236.g	used r3 instead of ar3
   028D EB                 1529 	mov	a,r3
   028E 24 22              1530 	add	a,#_Timer
                           1531 ;	genPlus
                           1532 ;     genPlusIncr
   0290 24 02              1533 	add	a,#0x02
                           1534 ;	genPointerSet
                           1535 ;	genNearPointerSet
                           1536 ;	Peephole 239	used a instead of acc
   0292 F8                 1537 	mov	r0,a
   0293 76 00              1538 	mov	@r0,#0x00
   0295                    1539 00108$:
                    01B7   1540 	C$TSIPMon.c$388$1$1 ==.
                           1541 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:388: for( i = 0; i < NUM_TIMERS; i++ ){		// Cycle through all timers, to update.
                           1542 ;	genPlus
                           1543 ;     genPlusIncr
   0295 0A                 1544 	inc	r2
                           1545 ;	Peephole 112.b	changed ljmp to sjmp
   0296 80 C8              1546 	sjmp	00106$
   0298                    1547 00110$:
   0298 D0 D0              1548 	pop	psw
   029A D0 00              1549 	pop	ar0
   029C D0 05              1550 	pop	ar5
   029E D0 04              1551 	pop	ar4
   02A0 D0 03              1552 	pop	ar3
   02A2 D0 02              1553 	pop	ar2
   02A4 D0 F0              1554 	pop	b
   02A6 D0 E0              1555 	pop	acc
                    01CA   1556 	C$TSIPMon.c$397$1$1 ==.
                    01CA   1557 	XG$Timer2_ISR$0$0 ==.
   02A8 32                 1558 	reti
                           1559 ;	eliminated unneeded push/pop ar1
                           1560 ;	eliminated unneeded push/pop dpl
                           1561 ;	eliminated unneeded push/pop dph
                           1562 ;------------------------------------------------------------
                           1563 ;Allocation info for local variables in function 'WaitTicks'
                           1564 ;------------------------------------------------------------
                           1565 ;delay                     Allocated to registers r2 r3 
                           1566 ;------------------------------------------------------------
                    01CB   1567 	G$WaitTicks$0$0 ==.
                    01CB   1568 	C$TSIPMon.c$404$1$1 ==.
                           1569 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:404: void WaitTicks( uint delay){
                           1570 ;	-----------------------------------------
                           1571 ;	 function WaitTicks
                           1572 ;	-----------------------------------------
   02A9                    1573 _WaitTicks:
                           1574 ;	genReceive
   02A9 AA 82              1575 	mov	r2,dpl
   02AB AB 83              1576 	mov	r3,dph
                    01CF   1577 	C$TSIPMon.c$406$1$1 ==.
                           1578 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:406: EA = FALSE;
                           1579 ;	genAssign
   02AD C2 AF              1580 	clr	_EA
                    01D1   1581 	C$TSIPMon.c$407$1$1 ==.
                           1582 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:407: ticks = delay;
                           1583 ;	genAssign
   02AF 8A 2D              1584 	mov	_ticks,r2
   02B1 8B 2E              1585 	mov	(_ticks + 1),r3
                    01D5   1586 	C$TSIPMon.c$408$1$1 ==.
                           1587 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:408: EA = TRUE;
                           1588 ;	genAssign
   02B3 D2 AF              1589 	setb	_EA
                    01D7   1590 	C$TSIPMon.c$409$1$1 ==.
                           1591 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:409: while( ticks > 0 )
   02B5                    1592 00101$:
                           1593 ;	genIfx
   02B5 E5 2D              1594 	mov	a,_ticks
   02B7 45 2E              1595 	orl	a,(_ticks + 1)
                           1596 ;	genIfxJump
                           1597 ;	Peephole 108.b	removed ljmp by inverse jump logic
   02B9 70 FA              1598 	jnz	00101$
                           1599 ;	Peephole 300	removed redundant label 00107$
                           1600 ;	Peephole 300	removed redundant label 00104$
                    01DD   1601 	C$TSIPMon.c$412$1$1 ==.
                    01DD   1602 	XG$WaitTicks$0$0 ==.
   02BB 22                 1603 	ret
                           1604 ;------------------------------------------------------------
                           1605 ;Allocation info for local variables in function 'TimerStart'
                           1606 ;------------------------------------------------------------
                           1607 ;num_ticks                 Allocated with name '_TimerStart_PARM_2'
                           1608 ;timer_num                 Allocated to registers r2 
                           1609 ;------------------------------------------------------------
                    01DE   1610 	G$TimerStart$0$0 ==.
                    01DE   1611 	C$TSIPMon.c$424$1$1 ==.
                           1612 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:424: void TimerStart( uchar timer_num, uint num_ticks ){
                           1613 ;	-----------------------------------------
                           1614 ;	 function TimerStart
                           1615 ;	-----------------------------------------
   02BC                    1616 _TimerStart:
                           1617 ;	genReceive
   02BC AA 82              1618 	mov	r2,dpl
                    01E0   1619 	C$TSIPMon.c$426$1$1 ==.
                           1620 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:426: INT_DISABLE;
                           1621 ;	genAssign
   02BE C2 A9              1622 	clr	_ET0
                    01E2   1623 	C$TSIPMon.c$428$1$1 ==.
                           1624 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:428: Timer[timer_num].WaitTime	= num_ticks;
                           1625 ;	genMult
                           1626 ;	genMultOneByte
   02C0 EA                 1627 	mov	a,r2
   02C1 75 F0 03           1628 	mov	b,#0x03
   02C4 A4                 1629 	mul	ab
                           1630 ;	genPlus
   02C5 FA                 1631 	mov	r2,a
                           1632 ;	Peephole 177.b	removed redundant mov
   02C6 24 22              1633 	add	a,#_Timer
                           1634 ;	genPointerSet
                           1635 ;	genNearPointerSet
                           1636 ;	Peephole 239	used a instead of acc
   02C8 F8                 1637 	mov	r0,a
   02C9 A6 0E              1638 	mov	@r0,_TimerStart_PARM_2
   02CB 08                 1639 	inc	r0
   02CC A6 0F              1640 	mov	@r0,(_TimerStart_PARM_2 + 1)
                    01F0   1641 	C$TSIPMon.c$429$1$1 ==.
                           1642 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:429: Timer[timer_num].Status	= TIMER_STATUS_RUNNING;
                           1643 ;	genPlus
                           1644 ;	Peephole 236.g	used r2 instead of ar2
   02CE EA                 1645 	mov	a,r2
   02CF 24 22              1646 	add	a,#_Timer
                           1647 ;	genPlus
                           1648 ;     genPlusIncr
   02D1 24 02              1649 	add	a,#0x02
                           1650 ;	genPointerSet
                           1651 ;	genNearPointerSet
                           1652 ;	Peephole 239	used a instead of acc
   02D3 F8                 1653 	mov	r0,a
   02D4 76 01              1654 	mov	@r0,#0x01
                    01F8   1655 	C$TSIPMon.c$431$1$1 ==.
                           1656 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:431: INT_ENABLE;
                           1657 ;	genAssign
   02D6 D2 A9              1658 	setb	_ET0
                           1659 ;	Peephole 300	removed redundant label 00101$
                    01FA   1660 	C$TSIPMon.c$433$1$1 ==.
                    01FA   1661 	XG$TimerStart$0$0 ==.
   02D8 22                 1662 	ret
                           1663 ;------------------------------------------------------------
                           1664 ;Allocation info for local variables in function 'TimerRunning'
                           1665 ;------------------------------------------------------------
                           1666 ;timer_num                 Allocated to registers r2 
                           1667 ;------------------------------------------------------------
                    01FB   1668 	G$TimerRunning$0$0 ==.
                    01FB   1669 	C$TSIPMon.c$439$1$1 ==.
                           1670 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:439: bit TimerRunning( uchar timer_num ){
                           1671 ;	-----------------------------------------
                           1672 ;	 function TimerRunning
                           1673 ;	-----------------------------------------
   02D9                    1674 _TimerRunning:
                           1675 ;	genReceive
                    01FB   1676 	C$TSIPMon.c$441$1$1 ==.
                           1677 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:441: return( (Timer[timer_num].Status == TIMER_STATUS_RUNNING)?TRUE:FALSE );
                           1678 ;	genMult
                           1679 ;	genMultOneByte
                           1680 ;	peephole 177.g	optimized mov sequence
   02D9 E5 82              1681 	mov	a,dpl
   02DB FA                 1682 	mov	r2,a
   02DC 75 F0 03           1683 	mov	b,#0x03
   02DF A4                 1684 	mul	ab
                           1685 ;	genPlus
   02E0 24 22              1686 	add	a,#_Timer
                           1687 ;	genPlus
                           1688 ;     genPlusIncr
   02E2 24 02              1689 	add	a,#0x02
   02E4 F8                 1690 	mov	r0,a
                           1691 ;	genPointerGet
                           1692 ;	genNearPointerGet
   02E5 86 02              1693 	mov	ar2,@r0
                           1694 ;	genCmpEq
                           1695 ;	gencjneshort
                           1696 ;	Peephole 112.b	changed ljmp to sjmp
                           1697 ;	Peephole 198.b	optimized misc jump sequence
   02E7 BA 01 04           1698 	cjne	r2,#0x01,00103$
                           1699 ;	Peephole 200.b	removed redundant sjmp
                           1700 ;	Peephole 300	removed redundant label 00106$
                           1701 ;	Peephole 300	removed redundant label 00107$
                           1702 ;	genAssign
   02EA 7A 01              1703 	mov	r2,#0x01
                           1704 ;	Peephole 112.b	changed ljmp to sjmp
   02EC 80 02              1705 	sjmp	00104$
   02EE                    1706 00103$:
                           1707 ;	genAssign
   02EE 7A 00              1708 	mov	r2,#0x00
   02F0                    1709 00104$:
                           1710 ;	genRet
   02F0 EA                 1711 	mov	a,r2
   02F1 24 FF              1712 	add	a,#0xff
                           1713 ;	Peephole 300	removed redundant label 00101$
                    0215   1714 	C$TSIPMon.c$443$1$1 ==.
                    0215   1715 	XG$TimerRunning$0$0 ==.
   02F3 22                 1716 	ret
                           1717 ;------------------------------------------------------------
                           1718 ;Allocation info for local variables in function 'TimerReset'
                           1719 ;------------------------------------------------------------
                           1720 ;timer_num                 Allocated to registers r2 
                           1721 ;------------------------------------------------------------
                    0216   1722 	G$TimerReset$0$0 ==.
                    0216   1723 	C$TSIPMon.c$449$1$1 ==.
                           1724 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:449: void TimerReset( uchar timer_num ){
                           1725 ;	-----------------------------------------
                           1726 ;	 function TimerReset
                           1727 ;	-----------------------------------------
   02F4                    1728 _TimerReset:
                           1729 ;	genReceive
   02F4 AA 82              1730 	mov	r2,dpl
                    0218   1731 	C$TSIPMon.c$451$1$1 ==.
                           1732 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:451: INT_DISABLE;
                           1733 ;	genAssign
   02F6 C2 A9              1734 	clr	_ET0
                    021A   1735 	C$TSIPMon.c$452$1$1 ==.
                           1736 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:452: Timer[timer_num].WaitTime	= 0;
                           1737 ;	genMult
                           1738 ;	genMultOneByte
   02F8 EA                 1739 	mov	a,r2
   02F9 75 F0 03           1740 	mov	b,#0x03
   02FC A4                 1741 	mul	ab
                           1742 ;	genPlus
   02FD FA                 1743 	mov	r2,a
                           1744 ;	Peephole 177.b	removed redundant mov
   02FE 24 22              1745 	add	a,#_Timer
                           1746 ;	genPointerSet
                           1747 ;	genNearPointerSet
                           1748 ;	Peephole 239	used a instead of acc
   0300 F8                 1749 	mov	r0,a
   0301 76 00              1750 	mov	@r0,#0x00
   0303 08                 1751 	inc	r0
   0304 76 00              1752 	mov	@r0,#0x00
                    0228   1753 	C$TSIPMon.c$453$1$1 ==.
                           1754 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:453: Timer[timer_num].Status	= TIMER_STATUS_STOPPED;
                           1755 ;	genPlus
                           1756 ;	Peephole 236.g	used r2 instead of ar2
   0306 EA                 1757 	mov	a,r2
   0307 24 22              1758 	add	a,#_Timer
                           1759 ;	genPlus
                           1760 ;     genPlusIncr
   0309 24 02              1761 	add	a,#0x02
                           1762 ;	genPointerSet
                           1763 ;	genNearPointerSet
                           1764 ;	Peephole 239	used a instead of acc
   030B F8                 1765 	mov	r0,a
   030C 76 02              1766 	mov	@r0,#0x02
                    0230   1767 	C$TSIPMon.c$454$1$1 ==.
                           1768 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:454: INT_ENABLE;
                           1769 ;	genAssign
   030E D2 A9              1770 	setb	_ET0
                           1771 ;	Peephole 300	removed redundant label 00101$
                    0232   1772 	C$TSIPMon.c$456$1$1 ==.
                    0232   1773 	XG$TimerReset$0$0 ==.
   0310 22                 1774 	ret
                           1775 ;------------------------------------------------------------
                           1776 ;Allocation info for local variables in function 'TimerReady'
                           1777 ;------------------------------------------------------------
                           1778 ;timer_num                 Allocated to registers r2 
                           1779 ;------------------------------------------------------------
                    0233   1780 	G$TimerReady$0$0 ==.
                    0233   1781 	C$TSIPMon.c$461$1$1 ==.
                           1782 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:461: bit TimerReady( uchar timer_num ){
                           1783 ;	-----------------------------------------
                           1784 ;	 function TimerReady
                           1785 ;	-----------------------------------------
   0311                    1786 _TimerReady:
                           1787 ;	genReceive
                    0233   1788 	C$TSIPMon.c$463$1$1 ==.
                           1789 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:463: if( Timer[timer_num].Status == TIMER_STATUS_READY )
                           1790 ;	genMult
                           1791 ;	genMultOneByte
                           1792 ;	peephole 177.g	optimized mov sequence
   0311 E5 82              1793 	mov	a,dpl
   0313 FA                 1794 	mov	r2,a
   0314 75 F0 03           1795 	mov	b,#0x03
   0317 A4                 1796 	mul	ab
                           1797 ;	genPlus
   0318 24 22              1798 	add	a,#_Timer
                           1799 ;	genPlus
                           1800 ;     genPlusIncr
   031A 24 02              1801 	add	a,#0x02
   031C F8                 1802 	mov	r0,a
                           1803 ;	genPointerGet
                           1804 ;	genNearPointerGet
   031D E6                 1805 	mov	a,@r0
                           1806 ;	genIfxJump
                           1807 ;	Peephole 108.b	removed ljmp by inverse jump logic
   031E 70 05              1808 	jnz	00102$
                           1809 ;	Peephole 300	removed redundant label 00107$
                    0242   1810 	C$TSIPMon.c$464$1$1 ==.
                           1811 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:464: return( TRUE );
                           1812 ;	genRet
   0320 74 01              1813 	mov	a,#0x01
   0322 24 FF              1814 	add	a,#0xff
                           1815 ;	Peephole 112.b	changed ljmp to sjmp
                           1816 ;	Peephole 251.b	replaced sjmp to ret with ret
   0324 22                 1817 	ret
   0325                    1818 00102$:
                    0247   1819 	C$TSIPMon.c$466$1$1 ==.
                           1820 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:466: return( FALSE );
                           1821 ;	genRet
                           1822 ;	Peephole 181	changed mov to clr
   0325 E4                 1823 	clr	a
   0326 24 FF              1824 	add	a,#0xff
                           1825 ;	Peephole 300	removed redundant label 00104$
                    024A   1826 	C$TSIPMon.c$468$1$1 ==.
                    024A   1827 	XG$TimerReady$0$0 ==.
   0328 22                 1828 	ret
                           1829 ;------------------------------------------------------------
                           1830 ;Allocation info for local variables in function 'UART0_Init'
                           1831 ;------------------------------------------------------------
                           1832 ;------------------------------------------------------------
                    024B   1833 	G$UART0_Init$0$0 ==.
                    024B   1834 	C$TSIPMon.c$483$1$1 ==.
                           1835 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:483: void UART0_Init( void ){
                           1836 ;	-----------------------------------------
                           1837 ;	 function UART0_Init
                           1838 ;	-----------------------------------------
   0329                    1839 _UART0_Init:
                    024B   1840 	C$TSIPMon.c$485$1$1 ==.
                           1841 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:485: SCON0 = 0x10;                       // SCON0: 8-bit variable bit rate
                           1842 ;	genAssign
   0329 75 98 10           1843 	mov	_SCON0,#0x10
                    024E   1844 	C$TSIPMon.c$495$2$2 ==.
                           1845 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:495: TH1 =  (unsigned char) -(SYSCLK/BAUDRATE/2);
                           1846 ;	genAssign
   032C 75 8D 61           1847 	mov	_TH1,#0x61
                    0251   1848 	C$TSIPMon.c$496$2$2 ==.
                           1849 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:496: CKCON &= ~0x0B;                  // T1M = 1; SCA1:0 = xx
                           1850 ;	genAnd
   032F 53 8E F4           1851 	anl	_CKCON,#0xF4
                    0254   1852 	C$TSIPMon.c$497$2$2 ==.
                           1853 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:497: CKCON |=  0x08; 
                           1854 ;	genOr
   0332 43 8E 08           1855 	orl	_CKCON,#0x08
                    0257   1856 	C$TSIPMon.c$512$1$1 ==.
                           1857 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:512: TL1 = TH1;                          // Init Timer1
                           1858 ;	genAssign
   0335 85 8D 8B           1859 	mov	_TL1,_TH1
                    025A   1860 	C$TSIPMon.c$513$1$1 ==.
                           1861 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:513: TMOD &= ~0xf0;                      // TMOD: timer 1 in 8-bit autoreload
                           1862 ;	genAnd
   0338 53 89 0F           1863 	anl	_TMOD,#0x0F
                    025D   1864 	C$TSIPMon.c$514$1$1 ==.
                           1865 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:514: TMOD |=  0x20;
                           1866 ;	genOr
   033B 43 89 20           1867 	orl	_TMOD,#0x20
                    0260   1868 	C$TSIPMon.c$515$1$1 ==.
                           1869 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:515: TR1 = 1;                            // START Timer1
                           1870 ;	genAssign
   033E D2 8E              1871 	setb	_TR1
                    0262   1872 	C$TSIPMon.c$516$1$1 ==.
                           1873 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:516: TI0 = 1;                            // Indicate TX0 ready
                           1874 ;	genAssign
   0340 D2 99              1875 	setb	_TI0
                    0264   1876 	C$TSIPMon.c$524$1$1 ==.
                           1877 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:524: RI0 = FALSE;		// turn off any pending receive interrupt
                           1878 ;	genAssign
   0342 C2 98              1879 	clr	_RI0
                    0266   1880 	C$TSIPMon.c$525$1$1 ==.
                           1881 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:525: REN0 = TRUE;		// UART0 receive enable
                           1882 ;	genAssign
   0344 D2 9C              1883 	setb	_REN0
                    0268   1884 	C$TSIPMon.c$526$1$1 ==.
                           1885 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:526: ES0 = TRUE;         // UART0 interrupt enable
                           1886 ;	genAssign
   0346 D2 AC              1887 	setb	_ES0
                           1888 ;	Peephole 300	removed redundant label 00110$
                    026A   1889 	C$TSIPMon.c$528$1$1 ==.
                    026A   1890 	XG$UART0_Init$0$0 ==.
   0348 22                 1891 	ret
                           1892 ;------------------------------------------------------------
                           1893 ;Allocation info for local variables in function 'SioIntService'
                           1894 ;------------------------------------------------------------
                           1895 ;tchar                     Allocated to registers r2 
                           1896 ;------------------------------------------------------------
                    026B   1897 	G$SioIntService$0$0 ==.
                    026B   1898 	C$TSIPMon.c$534$1$1 ==.
                           1899 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:534: void SioIntService( void ) interrupt INTERRUPT_UART0 using SIO_REG_BANK {
                           1900 ;	-----------------------------------------
                           1901 ;	 function SioIntService
                           1902 ;	-----------------------------------------
   0349                    1903 _SioIntService:
                    0012   1904 	ar2 = 0x12
                    0013   1905 	ar3 = 0x13
                    0014   1906 	ar4 = 0x14
                    0015   1907 	ar5 = 0x15
                    0016   1908 	ar6 = 0x16
                    0017   1909 	ar7 = 0x17
                    0010   1910 	ar0 = 0x10
                    0011   1911 	ar1 = 0x11
   0349 C0 E0              1912 	push	acc
   034B C0 82              1913 	push	dpl
   034D C0 83              1914 	push	dph
   034F C0 D0              1915 	push	psw
   0351 75 D0 10           1916 	mov	psw,#0x10
                    0276   1917 	C$TSIPMon.c$541$1$1 ==.
                           1918 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:541: if( RI0 ){
                           1919 ;	genIfx
                           1920 ;	genIfxJump
   0354 20 98 03           1921 	jb	_RI0,00181$
   0357 02 04 72           1922 	ljmp	00154$
   035A                    1923 00181$:
                    027C   1924 	C$TSIPMon.c$542$2$2 ==.
                           1925 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:542: tchar = SBUF0;	// & PARITY_MASK;
                           1926 ;	genAssign
   035A AA 99              1927 	mov	r2,_SBUF0
                    027E   1928 	C$TSIPMon.c$543$2$2 ==.
                           1929 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:543: RI0 = FALSE;
                           1930 ;	genAssign
   035C C2 98              1931 	clr	_RI0
                    0280   1932 	C$TSIPMon.c$546$2$2 ==.
                           1933 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:546: if( TxRx_Count > TXRX_BUF_LEN - 1 ) {
                           1934 ;	genCmpGt
                           1935 ;	genCmp
                           1936 ;	genIfxJump
                           1937 ;	Peephole 108.a	removed ljmp by inverse jump logic
                           1938 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   035E E5 2C              1939 	mov	a,_TxRx_Count
   0360 24 AB              1940 	add	a,#0xff - 0x54
   0362 50 09              1941 	jnc	00102$
                           1942 ;	Peephole 300	removed redundant label 00182$
                    0286   1943 	C$TSIPMon.c$547$3$3 ==.
                           1944 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:547: TxRx_State = WAIT_FOR_START;
                           1945 ;	genAssign
   0364 75 2B 00           1946 	mov	_TxRx_State,#0x00
                    0289   1947 	C$TSIPMon.c$548$3$3 ==.
                           1948 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:548: TxRx_Count = 0;
                           1949 ;	genAssign
   0367 75 2C 00           1950 	mov	_TxRx_Count,#0x00
                    028C   1951 	C$TSIPMon.c$549$3$3 ==.
                           1952 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:549: return;
                           1953 ;	genRet
   036A 02 04 D7           1954 	ljmp	00156$
   036D                    1955 00102$:
                    028F   1956 	C$TSIPMon.c$552$2$2 ==.
                           1957 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:552: switch( TxRx_State ){
                           1958 ;	genCmpGt
                           1959 ;	genCmp
                           1960 ;	genIfxJump
                           1961 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   036D E5 2B              1962 	mov	a,_TxRx_State
   036F 24 FA              1963 	add	a,#0xff - 0x05
   0371 50 03              1964 	jnc	00183$
   0373 02 04 6D           1965 	ljmp	00137$
   0376                    1966 00183$:
                           1967 ;	genJumpTab
   0376 E5 2B              1968 	mov	a,_TxRx_State
                           1969 ;	Peephole 254	optimized left shift
   0378 25 2B              1970 	add	a,_TxRx_State
   037A 25 2B              1971 	add	a,_TxRx_State
   037C 90 03 80           1972 	mov	dptr,#00184$
   037F 73                 1973 	jmp	@a+dptr
   0380                    1974 00184$:
   0380 02 03 92           1975 	ljmp	00103$
   0383 02 03 B4           1976 	ljmp	00109$
   0386 02 03 C3           1977 	ljmp	00113$
   0389 02 03 D2           1978 	ljmp	00117$
   038C 02 03 EA           1979 	ljmp	00121$
   038F 02 04 11           1980 	ljmp	00126$
                    02B4   1981 	C$TSIPMon.c$553$3$4 ==.
                           1982 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:553: case WAIT_FOR_START:
   0392                    1983 00103$:
                    02B4   1984 	C$TSIPMon.c$556$3$4 ==.
                           1985 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:556: if( tchar == DLE ){
                           1986 ;	genCmpEq
                           1987 ;	gencjneshort
                           1988 ;	Peephole 112.b	changed ljmp to sjmp
                           1989 ;	Peephole 198.b	optimized misc jump sequence
   0392 BA 10 0D           1990 	cjne	r2,#0x10,00107$
                           1991 ;	Peephole 200.b	removed redundant sjmp
                           1992 ;	Peephole 300	removed redundant label 00185$
                           1993 ;	Peephole 300	removed redundant label 00186$
                    02B7   1994 	C$TSIPMon.c$558$4$5 ==.
                           1995 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:558: TxRxBuf[TxRx_Count++] = tchar;
                           1996 ;	genAssign
   0395 75 2C 01           1997 	mov	_TxRx_Count,#0x01
                           1998 ;	genPointerSet
                           1999 ;     genFarPointerSet
   0398 90 00 13           2000 	mov	dptr,#_TxRxBuf
   039B EA                 2001 	mov	a,r2
   039C F0                 2002 	movx	@dptr,a
                    02BF   2003 	C$TSIPMon.c$559$4$5 ==.
                           2004 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:559: TxRx_State = WAIT_FOR_ID;
                           2005 ;	genAssign
   039D 75 2B 04           2006 	mov	_TxRx_State,#0x04
                           2007 ;	Peephole 112.b	changed ljmp to sjmp
   03A0 80 0D              2008 	sjmp	00108$
   03A2                    2009 00107$:
                    02C4   2010 	C$TSIPMon.c$560$3$4 ==.
                           2011 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:560: }else if( tchar != ETX ){
                           2012 ;	genCmpEq
                           2013 ;	gencjneshort
   03A2 BA 03 02           2014 	cjne	r2,#0x03,00187$
                           2015 ;	Peephole 112.b	changed ljmp to sjmp
   03A5 80 08              2016 	sjmp	00108$
   03A7                    2017 00187$:
                    02C9   2018 	C$TSIPMon.c$561$4$6 ==.
                           2019 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:561: TxRx_State = WAIT_FOR_DLE_ETX;
                           2020 ;	genAssign
   03A7 75 2B 01           2021 	mov	_TxRx_State,#0x01
                    02CC   2022 	C$TSIPMon.c$562$4$6 ==.
                           2023 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:562: Rx_Pending = FALSE;
                           2024 ;	genAssign
   03AA C2 00              2025 	clr	_Rx_Pending
                    02CE   2026 	C$TSIPMon.c$563$4$6 ==.
                           2027 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:563: TxRx_Count = 0;
                           2028 ;	genAssign
   03AC 75 2C 00           2029 	mov	_TxRx_Count,#0x00
   03AF                    2030 00108$:
                    02D1   2031 	C$TSIPMon.c$565$3$4 ==.
                           2032 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:565: bEvenDLE = FALSE;
                           2033 ;	genAssign
   03AF C2 07              2034 	clr	_SioIntService_bEvenDLE_1_1
                    02D3   2035 	C$TSIPMon.c$566$3$4 ==.
                           2036 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:566: break;
   03B1 02 04 D7           2037 	ljmp	00155$
                    02D6   2038 	C$TSIPMon.c$568$3$4 ==.
                           2039 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:568: case WAIT_FOR_DLE_ETX:
   03B4                    2040 00109$:
                    02D6   2041 	C$TSIPMon.c$569$3$4 ==.
                           2042 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:569: if( tchar == DLE )
                           2043 ;	genCmpEq
                           2044 ;	gencjneshort
                           2045 ;	Peephole 112.b	changed ljmp to sjmp
                           2046 ;	Peephole 198.b	optimized misc jump sequence
   03B4 BA 10 06           2047 	cjne	r2,#0x10,00111$
                           2048 ;	Peephole 200.b	removed redundant sjmp
                           2049 ;	Peephole 300	removed redundant label 00188$
                           2050 ;	Peephole 300	removed redundant label 00189$
                    02D9   2051 	C$TSIPMon.c$570$3$4 ==.
                           2052 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:570: TxRx_State = WAIT_FOR_ETX;
                           2053 ;	genAssign
   03B7 75 2B 02           2054 	mov	_TxRx_State,#0x02
   03BA 02 04 D7           2055 	ljmp	00155$
   03BD                    2056 00111$:
                    02DF   2057 	C$TSIPMon.c$572$3$4 ==.
                           2058 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:572: TxRx_State = WAIT_FOR_START;
                           2059 ;	genAssign
   03BD 75 2B 00           2060 	mov	_TxRx_State,#0x00
                    02E2   2061 	C$TSIPMon.c$573$3$4 ==.
                           2062 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:573: break;
   03C0 02 04 D7           2063 	ljmp	00155$
                    02E5   2064 	C$TSIPMon.c$575$3$4 ==.
                           2065 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:575: case WAIT_FOR_ETX:  // rarely happens
   03C3                    2066 00113$:
                    02E5   2067 	C$TSIPMon.c$576$3$4 ==.
                           2068 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:576: if( tchar == ETX )	
                           2069 ;	genCmpEq
                           2070 ;	gencjneshort
                           2071 ;	Peephole 112.b	changed ljmp to sjmp
                           2072 ;	Peephole 198.b	optimized misc jump sequence
   03C3 BA 03 06           2073 	cjne	r2,#0x03,00115$
                           2074 ;	Peephole 200.b	removed redundant sjmp
                           2075 ;	Peephole 300	removed redundant label 00190$
                           2076 ;	Peephole 300	removed redundant label 00191$
                    02E8   2077 	C$TSIPMon.c$578$3$4 ==.
                           2078 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:578: TxRx_State = WAIT_FOR_DLE;
                           2079 ;	genAssign
   03C6 75 2B 03           2080 	mov	_TxRx_State,#0x03
   03C9 02 04 D7           2081 	ljmp	00155$
   03CC                    2082 00115$:
                    02EE   2083 	C$TSIPMon.c$580$3$4 ==.
                           2084 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:580: TxRx_State = WAIT_FOR_START;
                           2085 ;	genAssign
   03CC 75 2B 00           2086 	mov	_TxRx_State,#0x00
                    02F1   2087 	C$TSIPMon.c$581$3$4 ==.
                           2088 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:581: break;
   03CF 02 04 D7           2089 	ljmp	00155$
                    02F4   2090 	C$TSIPMon.c$583$3$4 ==.
                           2091 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:583: case WAIT_FOR_DLE:
   03D2                    2092 00117$:
                    02F4   2093 	C$TSIPMon.c$584$3$4 ==.
                           2094 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:584: if( tchar == DLE ){
                           2095 ;	genCmpEq
                           2096 ;	gencjneshort
                           2097 ;	Peephole 112.b	changed ljmp to sjmp
                           2098 ;	Peephole 198.b	optimized misc jump sequence
   03D2 BA 10 0D           2099 	cjne	r2,#0x10,00119$
                           2100 ;	Peephole 200.b	removed redundant sjmp
                           2101 ;	Peephole 300	removed redundant label 00192$
                           2102 ;	Peephole 300	removed redundant label 00193$
                    02F7   2103 	C$TSIPMon.c$586$4$7 ==.
                           2104 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:586: TxRxBuf[TxRx_Count++] = tchar;
                           2105 ;	genAssign
   03D5 75 2C 01           2106 	mov	_TxRx_Count,#0x01
                           2107 ;	genPointerSet
                           2108 ;     genFarPointerSet
   03D8 90 00 13           2109 	mov	dptr,#_TxRxBuf
   03DB EA                 2110 	mov	a,r2
   03DC F0                 2111 	movx	@dptr,a
                    02FF   2112 	C$TSIPMon.c$587$4$7 ==.
                           2113 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:587: TxRx_State = WAIT_FOR_ID;
                           2114 ;	genAssign
   03DD 75 2B 04           2115 	mov	_TxRx_State,#0x04
                           2116 ;	Peephole 112.b	changed ljmp to sjmp
   03E0 80 03              2117 	sjmp	00120$
   03E2                    2118 00119$:
                    0304   2119 	C$TSIPMon.c$589$3$4 ==.
                           2120 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:589: TxRx_State = WAIT_FOR_START;
                           2121 ;	genAssign
   03E2 75 2B 00           2122 	mov	_TxRx_State,#0x00
   03E5                    2123 00120$:
                    0307   2124 	C$TSIPMon.c$590$3$4 ==.
                           2125 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:590: bEvenDLE = FALSE;
                           2126 ;	genAssign
   03E5 C2 07              2127 	clr	_SioIntService_bEvenDLE_1_1
                    0309   2128 	C$TSIPMon.c$591$3$4 ==.
                           2129 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:591: break;
   03E7 02 04 D7           2130 	ljmp	00155$
                    030C   2131 	C$TSIPMon.c$593$3$4 ==.
                           2132 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:593: case WAIT_FOR_ID: // never happens
   03EA                    2133 00121$:
                    030C   2134 	C$TSIPMon.c$594$3$4 ==.
                           2135 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:594: if( tchar == DLE || tchar == ETX ){
                           2136 ;	genCmpEq
                           2137 ;	gencjneshort
   03EA BA 10 02           2138 	cjne	r2,#0x10,00194$
                           2139 ;	Peephole 112.b	changed ljmp to sjmp
   03ED 80 03              2140 	sjmp	00122$
   03EF                    2141 00194$:
                           2142 ;	genCmpEq
                           2143 ;	gencjneshort
                           2144 ;	Peephole 112.b	changed ljmp to sjmp
                           2145 ;	Peephole 198.b	optimized misc jump sequence
   03EF BA 03 09           2146 	cjne	r2,#0x03,00123$
                           2147 ;	Peephole 200.b	removed redundant sjmp
                           2148 ;	Peephole 300	removed redundant label 00195$
                           2149 ;	Peephole 300	removed redundant label 00196$
   03F2                    2150 00122$:
                    0314   2151 	C$TSIPMon.c$595$4$8 ==.
                           2152 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:595: TxRx_State = WAIT_FOR_START;
                           2153 ;	genAssign
   03F2 75 2B 00           2154 	mov	_TxRx_State,#0x00
                    0317   2155 	C$TSIPMon.c$596$4$8 ==.
                           2156 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:596: TxRx_Count = 0;
                           2157 ;	genAssign
   03F5 75 2C 00           2158 	mov	_TxRx_Count,#0x00
   03F8 02 04 D7           2159 	ljmp	00155$
   03FB                    2160 00123$:
                    031D   2161 	C$TSIPMon.c$598$4$9 ==.
                           2162 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:598: TxRx_State = WAIT_FOR_END_MSG;
                           2163 ;	genAssign
   03FB 75 2B 05           2164 	mov	_TxRx_State,#0x05
                    0320   2165 	C$TSIPMon.c$599$4$9 ==.
                           2166 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:599: TxRxBuf[TxRx_Count++] = tchar;
                           2167 ;	genAssign
   03FE AB 2C              2168 	mov	r3,_TxRx_Count
                           2169 ;	genPlus
                           2170 ;     genPlusIncr
   0400 05 2C              2171 	inc	_TxRx_Count
                           2172 ;	genPlus
                           2173 ;	Peephole 236.g	used r3 instead of ar3
   0402 EB                 2174 	mov	a,r3
   0403 24 13              2175 	add	a,#_TxRxBuf
   0405 F5 82              2176 	mov	dpl,a
                           2177 ;	Peephole 181	changed mov to clr
   0407 E4                 2178 	clr	a
   0408 34 00              2179 	addc	a,#(_TxRxBuf >> 8)
   040A F5 83              2180 	mov	dph,a
                           2181 ;	genPointerSet
                           2182 ;     genFarPointerSet
   040C EA                 2183 	mov	a,r2
   040D F0                 2184 	movx	@dptr,a
                    0330   2185 	C$TSIPMon.c$601$3$4 ==.
                           2186 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:601: break;
   040E 02 04 D7           2187 	ljmp	00155$
                    0333   2188 	C$TSIPMon.c$603$3$4 ==.
                           2189 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:603: case WAIT_FOR_END_MSG:
   0411                    2190 00126$:
                    0333   2191 	C$TSIPMon.c$604$3$4 ==.
                           2192 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:604: if( tchar == DLE && TxRxBuf[TxRx_Count-1] == DLE && !bEvenDLE ){
                           2193 ;	genCmpEq
                           2194 ;	gencjneshort
                           2195 ;	Peephole 112.b	changed ljmp to sjmp
                           2196 ;	Peephole 198.b	optimized misc jump sequence
   0411 BA 10 19           2197 	cjne	r2,#0x10,00133$
                           2198 ;	Peephole 200.b	removed redundant sjmp
                           2199 ;	Peephole 300	removed redundant label 00197$
                           2200 ;	Peephole 300	removed redundant label 00198$
                           2201 ;	genMinus
                           2202 ;	genMinusDec
   0414 E5 2C              2203 	mov	a,_TxRx_Count
   0416 14                 2204 	dec	a
                           2205 ;	genPlus
   0417 24 13              2206 	add	a,#_TxRxBuf
   0419 F5 82              2207 	mov	dpl,a
                           2208 ;	Peephole 240	use clr instead of addc a,#0
   041B E4                 2209 	clr	a
   041C 34 00              2210 	addc	a,#(_TxRxBuf >> 8)
   041E F5 83              2211 	mov	dph,a
                           2212 ;	genPointerGet
                           2213 ;	genFarPointerGet
   0420 E0                 2214 	movx	a,@dptr
   0421 FB                 2215 	mov	r3,a
                           2216 ;	genCmpEq
                           2217 ;	gencjneshort
                           2218 ;	Peephole 112.b	changed ljmp to sjmp
                           2219 ;	Peephole 198.b	optimized misc jump sequence
   0422 BB 10 08           2220 	cjne	r3,#0x10,00133$
                           2221 ;	Peephole 200.b	removed redundant sjmp
                           2222 ;	Peephole 300	removed redundant label 00199$
                           2223 ;	Peephole 300	removed redundant label 00200$
                           2224 ;	genIfx
                           2225 ;	genIfxJump
                           2226 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0425 20 07 05           2227 	jb	_SioIntService_bEvenDLE_1_1,00133$
                           2228 ;	Peephole 300	removed redundant label 00201$
                    034A   2229 	C$TSIPMon.c$606$4$10 ==.
                           2230 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:606: bEvenDLE = TRUE;
                           2231 ;	genAssign
   0428 D2 07              2232 	setb	_SioIntService_bEvenDLE_1_1
   042A 02 04 D7           2233 	ljmp	00155$
   042D                    2234 00133$:
                    034F   2235 	C$TSIPMon.c$607$3$4 ==.
                           2236 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:607: }else if( tchar == ETX && TxRxBuf[TxRx_Count-1] == DLE && !bEvenDLE ){
                           2237 ;	genCmpEq
                           2238 ;	gencjneshort
                           2239 ;	Peephole 112.b	changed ljmp to sjmp
                           2240 ;	Peephole 198.b	optimized misc jump sequence
   042D BA 03 29           2241 	cjne	r2,#0x03,00128$
                           2242 ;	Peephole 200.b	removed redundant sjmp
                           2243 ;	Peephole 300	removed redundant label 00202$
                           2244 ;	Peephole 300	removed redundant label 00203$
                           2245 ;	genMinus
                           2246 ;	genMinusDec
   0430 E5 2C              2247 	mov	a,_TxRx_Count
   0432 14                 2248 	dec	a
                           2249 ;	genPlus
   0433 24 13              2250 	add	a,#_TxRxBuf
   0435 F5 82              2251 	mov	dpl,a
                           2252 ;	Peephole 240	use clr instead of addc a,#0
   0437 E4                 2253 	clr	a
   0438 34 00              2254 	addc	a,#(_TxRxBuf >> 8)
   043A F5 83              2255 	mov	dph,a
                           2256 ;	genPointerGet
                           2257 ;	genFarPointerGet
   043C E0                 2258 	movx	a,@dptr
   043D FB                 2259 	mov	r3,a
                           2260 ;	genCmpEq
                           2261 ;	gencjneshort
                           2262 ;	Peephole 112.b	changed ljmp to sjmp
                           2263 ;	Peephole 198.b	optimized misc jump sequence
   043E BB 10 18           2264 	cjne	r3,#0x10,00128$
                           2265 ;	Peephole 200.b	removed redundant sjmp
                           2266 ;	Peephole 300	removed redundant label 00204$
                           2267 ;	Peephole 300	removed redundant label 00205$
                           2268 ;	genIfx
                           2269 ;	genIfxJump
                           2270 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0441 20 07 15           2271 	jb	_SioIntService_bEvenDLE_1_1,00128$
                           2272 ;	Peephole 300	removed redundant label 00206$
                    0366   2273 	C$TSIPMon.c$610$4$11 ==.
                           2274 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:610: Rx_Pending = TRUE;
                           2275 ;	genAssign
   0444 D2 00              2276 	setb	_Rx_Pending
                    0368   2277 	C$TSIPMon.c$611$4$11 ==.
                           2278 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:611: TxRxBuf[TxRx_Count] = '\0';
                           2279 ;	genPlus
   0446 E5 2C              2280 	mov	a,_TxRx_Count
   0448 24 13              2281 	add	a,#_TxRxBuf
   044A F5 82              2282 	mov	dpl,a
                           2283 ;	Peephole 181	changed mov to clr
   044C E4                 2284 	clr	a
   044D 34 00              2285 	addc	a,#(_TxRxBuf >> 8)
   044F F5 83              2286 	mov	dph,a
                           2287 ;	genPointerSet
                           2288 ;     genFarPointerSet
                           2289 ;	Peephole 181	changed mov to clr
   0451 E4                 2290 	clr	a
   0452 F0                 2291 	movx	@dptr,a
                    0375   2292 	C$TSIPMon.c$612$4$11 ==.
                           2293 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:612: TxRx_State = WAIT_FOR_DLE;
                           2294 ;	genAssign
   0453 75 2B 03           2295 	mov	_TxRx_State,#0x03
   0456 02 04 D7           2296 	ljmp	00155$
   0459                    2297 00128$:
                    037B   2298 	C$TSIPMon.c$616$4$12 ==.
                           2299 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:616: TxRxBuf[TxRx_Count++] = tchar;
                           2300 ;	genAssign
   0459 AB 2C              2301 	mov	r3,_TxRx_Count
                           2302 ;	genPlus
                           2303 ;     genPlusIncr
   045B 05 2C              2304 	inc	_TxRx_Count
                           2305 ;	genPlus
                           2306 ;	Peephole 236.g	used r3 instead of ar3
   045D EB                 2307 	mov	a,r3
   045E 24 13              2308 	add	a,#_TxRxBuf
   0460 F5 82              2309 	mov	dpl,a
                           2310 ;	Peephole 181	changed mov to clr
   0462 E4                 2311 	clr	a
   0463 34 00              2312 	addc	a,#(_TxRxBuf >> 8)
   0465 F5 83              2313 	mov	dph,a
                           2314 ;	genPointerSet
                           2315 ;     genFarPointerSet
   0467 EA                 2316 	mov	a,r2
   0468 F0                 2317 	movx	@dptr,a
                    038B   2318 	C$TSIPMon.c$617$4$12 ==.
                           2319 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:617: bEvenDLE = FALSE;
                           2320 ;	genAssign
   0469 C2 07              2321 	clr	_SioIntService_bEvenDLE_1_1
                    038D   2322 	C$TSIPMon.c$619$3$4 ==.
                           2323 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:619: break;
                    038D   2324 	C$TSIPMon.c$621$3$4 ==.
                           2325 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:621: default:
                           2326 ;	Peephole 112.b	changed ljmp to sjmp
   046B 80 6A              2327 	sjmp	00155$
   046D                    2328 00137$:
                    038F   2329 	C$TSIPMon.c$622$3$4 ==.
                           2330 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:622: TxRx_State = WAIT_FOR_START;
                           2331 ;	genAssign
   046D 75 2B 00           2332 	mov	_TxRx_State,#0x00
                    0392   2333 	C$TSIPMon.c$624$1$1 ==.
                           2334 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:624: }
                           2335 ;	Peephole 112.b	changed ljmp to sjmp
   0470 80 65              2336 	sjmp	00155$
   0472                    2337 00154$:
                    0394   2338 	C$TSIPMon.c$628$2$13 ==.
                           2339 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:628: if( TI0 ){
                           2340 ;	genIfx
                           2341 ;	genIfxJump
                           2342 ;	Peephole 108.d	removed ljmp by inverse jump logic
                    0394   2343 	C$TSIPMon.c$629$3$14 ==.
                           2344 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:629: TI0 = FALSE;
                           2345 ;	genAssign
                           2346 ;	Peephole 250.a	using atomic test and clear
   0472 10 99 02           2347 	jbc	_TI0,00207$
   0475 80 60              2348 	sjmp	00155$
   0477                    2349 00207$:
                    0399   2350 	C$TSIPMon.c$631$3$14 ==.
                           2351 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:631: if( !Tx_In_Progress ){
                           2352 ;	genIfx
                           2353 ;	genIfxJump
                           2354 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0477 20 01 08           2355 	jb	_Tx_In_Progress,00140$
                           2356 ;	Peephole 300	removed redundant label 00208$
                    039C   2357 	C$TSIPMon.c$632$4$15 ==.
                           2358 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:632: RI0 = FALSE;
                           2359 ;	genAssign
   047A C2 98              2360 	clr	_RI0
                    039E   2361 	C$TSIPMon.c$633$4$15 ==.
                           2362 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:633: Tx_In_Progress = FALSE;
                           2363 ;	genAssign
   047C C2 01              2364 	clr	_Tx_In_Progress
                    03A0   2365 	C$TSIPMon.c$634$4$15 ==.
                           2366 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:634: Rx_Pending = FALSE;
                           2367 ;	genAssign
   047E C2 00              2368 	clr	_Rx_Pending
                    03A2   2369 	C$TSIPMon.c$635$4$15 ==.
                           2370 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:635: return;
                           2371 ;	genRet
                           2372 ;	Peephole 112.b	changed ljmp to sjmp
   0480 80 55              2373 	sjmp	00156$
   0482                    2374 00140$:
                    03A4   2375 	C$TSIPMon.c$637$3$14 ==.
                           2376 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:637: switch( TxRx_State ){
                           2377 ;	genCmpEq
                           2378 ;	gencjneshort
   0482 E5 2B              2379 	mov	a,_TxRx_State
   0484 B4 06 02           2380 	cjne	a,#0x06,00209$
                           2381 ;	Peephole 112.b	changed ljmp to sjmp
   0487 80 07              2382 	sjmp	00141$
   0489                    2383 00209$:
                           2384 ;	genCmpEq
                           2385 ;	gencjneshort
   0489 E5 2B              2386 	mov	a,_TxRx_State
                           2387 ;	Peephole 112.b	changed ljmp to sjmp
                    03AD   2388 	C$TSIPMon.c$639$4$16 ==.
                           2389 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:639: case SEND_HDR:
                           2390 ;	Peephole 112.b	changed ljmp to sjmp
                           2391 ;	Peephole 198.b	optimized misc jump sequence
   048B B4 07 49           2392 	cjne	a,#0x07,00155$
   048E 80 17              2393 	sjmp	00142$
                           2394 ;	Peephole 300	removed redundant label 00210$
   0490                    2395 00141$:
                    03B2   2396 	C$TSIPMon.c$640$4$16 ==.
                           2397 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:640: SBUF0 = DLE;
                           2398 ;	genAssign
   0490 75 99 10           2399 	mov	_SBUF0,#0x10
                    03B5   2400 	C$TSIPMon.c$641$4$16 ==.
                           2401 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:641: TxRx_State = SEND_MSG;
                           2402 ;	genAssign
   0493 75 2B 07           2403 	mov	_TxRx_State,#0x07
                    03B8   2404 	C$TSIPMon.c$642$4$16 ==.
                           2405 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:642: TxRx_Count--;
                           2406 ;	genMinus
                           2407 ;	genMinusDec
   0496 15 2C              2408 	dec	_TxRx_Count
                    03BA   2409 	C$TSIPMon.c$643$4$16 ==.
                           2410 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:643: p_TxRx_Buf = TxRxBuf+1;
                           2411 ;	genPlus
                           2412 ;     genPlusIncr
   0498 74 01              2413 	mov	a,#0x01
   049A 24 13              2414 	add	a,#_TxRxBuf
   049C F5 2F              2415 	mov	_p_TxRx_Buf,a
                           2416 ;	Peephole 181	changed mov to clr
   049E E4                 2417 	clr	a
   049F 34 00              2418 	addc	a,#(_TxRxBuf >> 8)
   04A1 F5 30              2419 	mov	(_p_TxRx_Buf + 1),a
                    03C5   2420 	C$TSIPMon.c$644$4$16 ==.
                           2421 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:644: bEvenDLE = FALSE;
                           2422 ;	genAssign
   04A3 C2 07              2423 	clr	_SioIntService_bEvenDLE_1_1
                    03C7   2424 	C$TSIPMon.c$645$4$16 ==.
                           2425 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:645: break;
                    03C7   2426 	C$TSIPMon.c$647$4$16 ==.
                           2427 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:647: case SEND_MSG:
                           2428 ;	Peephole 112.b	changed ljmp to sjmp
   04A5 80 30              2429 	sjmp	00155$
   04A7                    2430 00142$:
                    03C9   2431 	C$TSIPMon.c$648$4$16 ==.
                           2432 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:648: tchar = *p_TxRx_Buf;
                           2433 ;	genAssign
   04A7 85 2F 82           2434 	mov	dpl,_p_TxRx_Buf
   04AA 85 30 83           2435 	mov	dph,(_p_TxRx_Buf + 1)
                           2436 ;	genPointerGet
                           2437 ;	genFarPointerGet
   04AD E0                 2438 	movx	a,@dptr
   04AE FA                 2439 	mov	r2,a
                    03D1   2440 	C$TSIPMon.c$649$4$16 ==.
                           2441 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:649: SBUF0 = tchar;
                           2442 ;	genAssign
   04AF 8A 99              2443 	mov	_SBUF0,r2
                    03D3   2444 	C$TSIPMon.c$650$4$16 ==.
                           2445 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:650: if( tchar == DLE && !bEvenDLE && TxRx_Count > 1 ){
                           2446 ;	genCmpEq
                           2447 ;	gencjneshort
                           2448 ;	Peephole 112.b	changed ljmp to sjmp
                           2449 ;	Peephole 198.b	optimized misc jump sequence
   04B1 BA 10 0D           2450 	cjne	r2,#0x10,00144$
                           2451 ;	Peephole 200.b	removed redundant sjmp
                           2452 ;	Peephole 300	removed redundant label 00211$
                           2453 ;	Peephole 300	removed redundant label 00212$
                           2454 ;	genIfx
                           2455 ;	genIfxJump
                           2456 ;	Peephole 108.e	removed ljmp by inverse jump logic
   04B4 20 07 0A           2457 	jb	_SioIntService_bEvenDLE_1_1,00144$
                           2458 ;	Peephole 300	removed redundant label 00213$
                           2459 ;	genCmpGt
                           2460 ;	genCmp
                           2461 ;	genIfxJump
                           2462 ;	Peephole 108.a	removed ljmp by inverse jump logic
                           2463 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   04B7 E5 2C              2464 	mov	a,_TxRx_Count
   04B9 24 FE              2465 	add	a,#0xff - 0x01
   04BB 50 04              2466 	jnc	00144$
                           2467 ;	Peephole 300	removed redundant label 00214$
                    03DF   2468 	C$TSIPMon.c$652$5$17 ==.
                           2469 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:652: bEvenDLE = TRUE;
                           2470 ;	genAssign
   04BD D2 07              2471 	setb	_SioIntService_bEvenDLE_1_1
                    03E1   2472 	C$TSIPMon.c$653$5$17 ==.
                           2473 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:653: return;
                           2474 ;	genRet
                           2475 ;	Peephole 112.b	changed ljmp to sjmp
   04BF 80 16              2476 	sjmp	00156$
   04C1                    2477 00144$:
                    03E3   2478 	C$TSIPMon.c$655$4$16 ==.
                           2479 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:655: p_TxRx_Buf++;
                           2480 ;	genPlus
                           2481 ;     genPlusIncr
   04C1 05 2F              2482 	inc	_p_TxRx_Buf
   04C3 E4                 2483 	clr	a
   04C4 B5 2F 02           2484 	cjne	a,_p_TxRx_Buf,00215$
   04C7 05 30              2485 	inc	(_p_TxRx_Buf + 1)
   04C9                    2486 00215$:
                    03EB   2487 	C$TSIPMon.c$656$4$16 ==.
                           2488 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:656: bEvenDLE = FALSE;
                           2489 ;	genAssign
   04C9 C2 07              2490 	clr	_SioIntService_bEvenDLE_1_1
                    03ED   2491 	C$TSIPMon.c$657$4$16 ==.
                           2492 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:657: if( TxRx_Count-- == 0 ){
                           2493 ;	genAssign
   04CB AA 2C              2494 	mov	r2,_TxRx_Count
                           2495 ;	genMinus
                           2496 ;	genMinusDec
   04CD 15 2C              2497 	dec	_TxRx_Count
                           2498 ;	genIfx
   04CF EA                 2499 	mov	a,r2
                           2500 ;	genIfxJump
                           2501 ;	Peephole 108.b	removed ljmp by inverse jump logic
   04D0 70 05              2502 	jnz	00155$
                           2503 ;	Peephole 300	removed redundant label 00216$
                    03F4   2504 	C$TSIPMon.c$658$5$18 ==.
                           2505 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:658: Tx_In_Progress = FALSE;
                           2506 ;	genAssign
   04D2 C2 01              2507 	clr	_Tx_In_Progress
                    03F6   2508 	C$TSIPMon.c$659$5$18 ==.
                           2509 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:659: TxRx_Count = 0;
                           2510 ;	genAssign
   04D4 75 2C 00           2511 	mov	_TxRx_Count,#0x00
                    03F9   2512 	C$TSIPMon.c$665$1$1 ==.
                           2513 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:665: }
   04D7                    2514 00155$:
                    03F9   2515 	C$TSIPMon.c$669$1$1 ==.
                           2516 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:669: return;
                           2517 ;	genRet
   04D7                    2518 00156$:
   04D7 D0 D0              2519 	pop	psw
   04D9 D0 83              2520 	pop	dph
   04DB D0 82              2521 	pop	dpl
   04DD D0 E0              2522 	pop	acc
                    0401   2523 	C$TSIPMon.c$672$1$1 ==.
                    0401   2524 	XG$SioIntService$0$0 ==.
   04DF 32                 2525 	reti
                           2526 ;	eliminated unneeded push/pop b
                           2527 ;------------------------------------------------------------
                           2528 ;Allocation info for local variables in function 'ProcessRxMsg'
                           2529 ;------------------------------------------------------------
                           2530 ;i                         Allocated to registers r4 
                           2531 ;id                        Allocated to registers r2 
                           2532 ;id2                       Allocated to registers r3 
                           2533 ;pBuf                      Allocated with name '_ProcessRxMsg_pBuf_1_1'
                           2534 ;------------------------------------------------------------
                    0402   2535 	G$ProcessRxMsg$0$0 ==.
                    0402   2536 	C$TSIPMon.c$677$1$1 ==.
                           2537 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:677: void ProcessRxMsg( void ){
                           2538 ;	-----------------------------------------
                           2539 ;	 function ProcessRxMsg
                           2540 ;	-----------------------------------------
   04E0                    2541 _ProcessRxMsg:
                    0002   2542 	ar2 = 0x02
                    0003   2543 	ar3 = 0x03
                    0004   2544 	ar4 = 0x04
                    0005   2545 	ar5 = 0x05
                    0006   2546 	ar6 = 0x06
                    0007   2547 	ar7 = 0x07
                    0000   2548 	ar0 = 0x00
                    0001   2549 	ar1 = 0x01
                    0402   2550 	C$TSIPMon.c$683$1$1 ==.
                           2551 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:683: id = TxRxBuf[IO_BUF_ID_INDEX];
                           2552 ;	genPointerGet
                           2553 ;	genFarPointerGet
   04E0 90 00 14           2554 	mov	dptr,#(_TxRxBuf + 0x0001)
   04E3 E0                 2555 	movx	a,@dptr
   04E4 FA                 2556 	mov	r2,a
                    0407   2557 	C$TSIPMon.c$684$1$1 ==.
                           2558 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:684: id2 = TxRxBuf[IO_BUF_ID2_INDEX];
                           2559 ;	genPointerGet
                           2560 ;	genFarPointerGet
   04E5 90 00 15           2561 	mov	dptr,#(_TxRxBuf + 0x0002)
   04E8 E0                 2562 	movx	a,@dptr
   04E9 FB                 2563 	mov	r3,a
                    040C   2564 	C$TSIPMon.c$685$1$1 ==.
                           2565 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:685: for( i=2; i<TxRx_Count; i++)
                           2566 ;	genAssign
   04EA 7C 02              2567 	mov	r4,#0x02
   04EC                    2568 00108$:
                           2569 ;	genCmpLt
                           2570 ;	genCmp
   04EC C3                 2571 	clr	c
   04ED EC                 2572 	mov	a,r4
   04EE 95 2C              2573 	subb	a,_TxRx_Count
                           2574 ;	genIfxJump
                           2575 ;	Peephole 108.a	removed ljmp by inverse jump logic
   04F0 50 1E              2576 	jnc	00111$
                           2577 ;	Peephole 300	removed redundant label 00120$
                    0414   2578 	C$TSIPMon.c$686$1$1 ==.
                           2579 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:686: pBuf[i-2] = TxRxBuf[i];
                           2580 ;	genMinus
                           2581 ;	genMinusDec
   04F2 EC                 2582 	mov	a,r4
   04F3 24 FE              2583 	add	a,#0xfe
                           2584 ;	genPlus
   04F5 24 68              2585 	add	a,#_ProcessRxMsg_pBuf_1_1
   04F7 FD                 2586 	mov	r5,a
                           2587 ;	Peephole 240	use clr instead of addc a,#0
   04F8 E4                 2588 	clr	a
   04F9 34 00              2589 	addc	a,#(_ProcessRxMsg_pBuf_1_1 >> 8)
   04FB FE                 2590 	mov	r6,a
                           2591 ;	genPlus
                           2592 ;	Peephole 236.g	used r4 instead of ar4
   04FC EC                 2593 	mov	a,r4
   04FD 24 13              2594 	add	a,#_TxRxBuf
   04FF F5 82              2595 	mov	dpl,a
                           2596 ;	Peephole 181	changed mov to clr
   0501 E4                 2597 	clr	a
   0502 34 00              2598 	addc	a,#(_TxRxBuf >> 8)
   0504 F5 83              2599 	mov	dph,a
                           2600 ;	genPointerGet
                           2601 ;	genFarPointerGet
   0506 E0                 2602 	movx	a,@dptr
                           2603 ;	genPointerSet
                           2604 ;     genFarPointerSet
   0507 FF                 2605 	mov	r7,a
   0508 8D 82              2606 	mov	dpl,r5
   050A 8E 83              2607 	mov	dph,r6
                           2608 ;	Peephole 136	removed redundant move
   050C F0                 2609 	movx	@dptr,a
                    042F   2610 	C$TSIPMon.c$685$1$1 ==.
                           2611 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:685: for( i=2; i<TxRx_Count; i++)
                           2612 ;	genPlus
                           2613 ;     genPlusIncr
   050D 0C                 2614 	inc	r4
                           2615 ;	Peephole 112.b	changed ljmp to sjmp
   050E 80 DC              2616 	sjmp	00108$
   0510                    2617 00111$:
                    0432   2618 	C$TSIPMon.c$687$1$1 ==.
                           2619 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:687: Rx_Pending = FALSE;
                           2620 ;	genAssign
   0510 C2 00              2621 	clr	_Rx_Pending
                    0434   2622 	C$TSIPMon.c$689$1$1 ==.
                           2623 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:689: switch( id ){
                           2624 ;	genCmpEq
                           2625 ;	gencjneshort
                           2626 ;	Peephole 112.b	changed ljmp to sjmp
                           2627 ;	Peephole 198.b	optimized misc jump sequence
   0512 BA 8F 16           2628 	cjne	r2,#0x8F,00112$
                           2629 ;	Peephole 200.b	removed redundant sjmp
                           2630 ;	Peephole 300	removed redundant label 00121$
                           2631 ;	Peephole 300	removed redundant label 00122$
                    0437   2632 	C$TSIPMon.c$691$2$2 ==.
                           2633 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:691: switch( id2 ){
                           2634 ;	genCmpEq
                           2635 ;	gencjneshort
   0515 BB AB 02           2636 	cjne	r3,#0xAB,00123$
                           2637 ;	Peephole 112.b	changed ljmp to sjmp
   0518 80 05              2638 	sjmp	00102$
   051A                    2639 00123$:
                           2640 ;	genCmpEq
                           2641 ;	gencjneshort
                           2642 ;	Peephole 112.b	changed ljmp to sjmp
                    043C   2643 	C$TSIPMon.c$692$3$3 ==.
                           2644 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:692: case PRIMARY_TIMING_PCKT:
                           2645 ;	Peephole 112.b	changed ljmp to sjmp
                           2646 ;	Peephole 198.b	optimized misc jump sequence
   051A BB AC 0E           2647 	cjne	r3,#0xAC,00112$
   051D 80 06              2648 	sjmp	00103$
                           2649 ;	Peephole 300	removed redundant label 00124$
   051F                    2650 00102$:
                    0441   2651 	C$TSIPMon.c$693$3$3 ==.
                           2652 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:693: PrimaryTiming( pBuf );
                           2653 ;	genCall
                           2654 ;	Peephole 182.a	used 16 bit load of DPTR
   051F 90 00 68           2655 	mov	dptr,#_ProcessRxMsg_pBuf_1_1
                    0444   2656 	C$TSIPMon.c$694$3$3 ==.
                           2657 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:694: break;
                    0444   2658 	C$TSIPMon.c$696$3$3 ==.
                           2659 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:696: case SUPPLEMENTAL_TIMING_PCKT:
                           2660 ;	Peephole 112.b	changed ljmp to sjmp
                           2661 ;	Peephole 251.b	replaced sjmp to ret with ret
                           2662 ;	Peephole 253.a	replaced lcall/ret with ljmp
   0522 02 05 2C           2663 	ljmp	_PrimaryTiming
   0525                    2664 00103$:
                    0447   2665 	C$TSIPMon.c$697$3$3 ==.
                           2666 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:697: SupplementalTiming( pBuf );
                           2667 ;	genCall
                           2668 ;	Peephole 182.a	used 16 bit load of DPTR
   0525 90 00 68           2669 	mov	dptr,#_ProcessRxMsg_pBuf_1_1
                    044A   2670 	C$TSIPMon.c$705$1$1 ==.
                           2671 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:705: }
                    044A   2672 	C$TSIPMon.c$707$1$1 ==.
                    044A   2673 	XG$ProcessRxMsg$0$0 ==.
                           2674 ;	Peephole 253.c	replaced lcall with ljmp
   0528 02 06 97           2675 	ljmp	_SupplementalTiming
   052B                    2676 00112$:
   052B 22                 2677 	ret
                           2678 ;------------------------------------------------------------
                           2679 ;Allocation info for local variables in function 'PrimaryTiming'
                           2680 ;------------------------------------------------------------
                           2681 ;RxBuf                     Allocated to registers r2 r3 
                           2682 ;sec                       Allocated to registers r4 
                           2683 ;min                       Allocated to registers r4 
                           2684 ;hr                        Allocated to registers r4 
                           2685 ;dom                       Allocated to registers r4 
                           2686 ;mo                        Allocated to registers r4 
                           2687 ;yr                        Allocated with name '_PrimaryTiming_yr_1_1'
                           2688 ;------------------------------------------------------------
                    044E   2689 	G$PrimaryTiming$0$0 ==.
                    044E   2690 	C$TSIPMon.c$713$1$1 ==.
                           2691 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:713: void PrimaryTiming( uchar TXRX_STORAGE_CLASS *RxBuf ){
                           2692 ;	-----------------------------------------
                           2693 ;	 function PrimaryTiming
                           2694 ;	-----------------------------------------
   052C                    2695 _PrimaryTiming:
                           2696 ;	genReceive
   052C AA 82              2697 	mov	r2,dpl
   052E AB 83              2698 	mov	r3,dph
                    0452   2699 	C$TSIPMon.c$720$1$1 ==.
                           2700 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:720: sec = *(RxBuf+10);
                           2701 ;	genPlus
                           2702 ;     genPlusIncr
   0530 74 0A              2703 	mov	a,#0x0A
                           2704 ;	Peephole 236.a	used r2 instead of ar2
   0532 2A                 2705 	add	a,r2
   0533 F5 82              2706 	mov	dpl,a
                           2707 ;	Peephole 181	changed mov to clr
   0535 E4                 2708 	clr	a
                           2709 ;	Peephole 236.b	used r3 instead of ar3
   0536 3B                 2710 	addc	a,r3
   0537 F5 83              2711 	mov	dph,a
                           2712 ;	genPointerGet
                           2713 ;	genFarPointerGet
   0539 E0                 2714 	movx	a,@dptr
   053A FC                 2715 	mov	r4,a
                    045D   2716 	C$TSIPMon.c$721$1$1 ==.
                           2717 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:721: UnsignedToAscii( (uint)sec, lcdbuf+6, 2 );
                           2718 ;	genCast
   053B 7D 00              2719 	mov	r5,#0x00
                           2720 ;	genPlus
                           2721 ;     genPlusIncr
   053D 74 06              2722 	mov	a,#0x06
   053F 24 02              2723 	add	a,#_lcdbuf
   0541 F5 1B              2724 	mov	_UnsignedToAscii_PARM_2,a
                           2725 ;	Peephole 181	changed mov to clr
   0543 E4                 2726 	clr	a
   0544 34 00              2727 	addc	a,#(_lcdbuf >> 8)
   0546 F5 1C              2728 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           2729 ;	genAssign
   0548 75 1D 02           2730 	mov	_UnsignedToAscii_PARM_3,#0x02
                           2731 ;	genCall
   054B 8C 82              2732 	mov	dpl,r4
   054D 8D 83              2733 	mov	dph,r5
   054F C0 02              2734 	push	ar2
   0551 C0 03              2735 	push	ar3
   0553 12 0D 3E           2736 	lcall	_UnsignedToAscii
   0556 D0 03              2737 	pop	ar3
   0558 D0 02              2738 	pop	ar2
                    047C   2739 	C$TSIPMon.c$722$1$1 ==.
                           2740 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:722: if( lcdbuf[6] == ' ' ) lcdbuf[6] = '0';
                           2741 ;	genPointerGet
                           2742 ;	genFarPointerGet
   055A 90 00 08           2743 	mov	dptr,#(_lcdbuf + 0x0006)
   055D E0                 2744 	movx	a,@dptr
   055E FC                 2745 	mov	r4,a
                           2746 ;	genCmpEq
                           2747 ;	gencjneshort
                           2748 ;	Peephole 112.b	changed ljmp to sjmp
                           2749 ;	Peephole 198.b	optimized misc jump sequence
   055F BC 20 06           2750 	cjne	r4,#0x20,00102$
                           2751 ;	Peephole 200.b	removed redundant sjmp
                           2752 ;	Peephole 300	removed redundant label 00118$
                           2753 ;	Peephole 300	removed redundant label 00119$
                           2754 ;	genPointerSet
                           2755 ;     genFarPointerSet
   0562 90 00 08           2756 	mov	dptr,#(_lcdbuf + 0x0006)
   0565 74 30              2757 	mov	a,#0x30
   0567 F0                 2758 	movx	@dptr,a
   0568                    2759 00102$:
                    048A   2760 	C$TSIPMon.c$723$1$1 ==.
                           2761 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:723: lcdbuf[8] = ' ';
                           2762 ;	genPointerSet
                           2763 ;     genFarPointerSet
   0568 90 00 0A           2764 	mov	dptr,#(_lcdbuf + 0x0008)
   056B 74 20              2765 	mov	a,#0x20
   056D F0                 2766 	movx	@dptr,a
                    0490   2767 	C$TSIPMon.c$724$1$1 ==.
                           2768 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:724: min = *(RxBuf+11);
                           2769 ;	genPlus
                           2770 ;     genPlusIncr
   056E 74 0B              2771 	mov	a,#0x0B
                           2772 ;	Peephole 236.a	used r2 instead of ar2
   0570 2A                 2773 	add	a,r2
   0571 F5 82              2774 	mov	dpl,a
                           2775 ;	Peephole 181	changed mov to clr
   0573 E4                 2776 	clr	a
                           2777 ;	Peephole 236.b	used r3 instead of ar3
   0574 3B                 2778 	addc	a,r3
   0575 F5 83              2779 	mov	dph,a
                           2780 ;	genPointerGet
                           2781 ;	genFarPointerGet
   0577 E0                 2782 	movx	a,@dptr
   0578 FC                 2783 	mov	r4,a
                    049B   2784 	C$TSIPMon.c$725$1$1 ==.
                           2785 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:725: UnsignedToAscii( (uint)min, lcdbuf+3, 2 );
                           2786 ;	genCast
   0579 7D 00              2787 	mov	r5,#0x00
                           2788 ;	genPlus
                           2789 ;     genPlusIncr
   057B 74 03              2790 	mov	a,#0x03
   057D 24 02              2791 	add	a,#_lcdbuf
   057F F5 1B              2792 	mov	_UnsignedToAscii_PARM_2,a
                           2793 ;	Peephole 181	changed mov to clr
   0581 E4                 2794 	clr	a
   0582 34 00              2795 	addc	a,#(_lcdbuf >> 8)
   0584 F5 1C              2796 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           2797 ;	genAssign
   0586 75 1D 02           2798 	mov	_UnsignedToAscii_PARM_3,#0x02
                           2799 ;	genCall
   0589 8C 82              2800 	mov	dpl,r4
   058B 8D 83              2801 	mov	dph,r5
   058D C0 02              2802 	push	ar2
   058F C0 03              2803 	push	ar3
   0591 12 0D 3E           2804 	lcall	_UnsignedToAscii
   0594 D0 03              2805 	pop	ar3
   0596 D0 02              2806 	pop	ar2
                    04BA   2807 	C$TSIPMon.c$726$1$1 ==.
                           2808 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:726: if( lcdbuf[3] == ' ' ) lcdbuf[3] = '0';
                           2809 ;	genPointerGet
                           2810 ;	genFarPointerGet
   0598 90 00 05           2811 	mov	dptr,#(_lcdbuf + 0x0003)
   059B E0                 2812 	movx	a,@dptr
   059C FC                 2813 	mov	r4,a
                           2814 ;	genCmpEq
                           2815 ;	gencjneshort
                           2816 ;	Peephole 112.b	changed ljmp to sjmp
                           2817 ;	Peephole 198.b	optimized misc jump sequence
   059D BC 20 06           2818 	cjne	r4,#0x20,00104$
                           2819 ;	Peephole 200.b	removed redundant sjmp
                           2820 ;	Peephole 300	removed redundant label 00120$
                           2821 ;	Peephole 300	removed redundant label 00121$
                           2822 ;	genPointerSet
                           2823 ;     genFarPointerSet
   05A0 90 00 05           2824 	mov	dptr,#(_lcdbuf + 0x0003)
   05A3 74 30              2825 	mov	a,#0x30
   05A5 F0                 2826 	movx	@dptr,a
   05A6                    2827 00104$:
                    04C8   2828 	C$TSIPMon.c$727$1$1 ==.
                           2829 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:727: lcdbuf[5] = ':';
                           2830 ;	genPointerSet
                           2831 ;     genFarPointerSet
   05A6 90 00 07           2832 	mov	dptr,#(_lcdbuf + 0x0005)
   05A9 74 3A              2833 	mov	a,#0x3A
   05AB F0                 2834 	movx	@dptr,a
                    04CE   2835 	C$TSIPMon.c$728$1$1 ==.
                           2836 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:728: hr = *(RxBuf+12);
                           2837 ;	genPlus
                           2838 ;     genPlusIncr
   05AC 74 0C              2839 	mov	a,#0x0C
                           2840 ;	Peephole 236.a	used r2 instead of ar2
   05AE 2A                 2841 	add	a,r2
   05AF F5 82              2842 	mov	dpl,a
                           2843 ;	Peephole 181	changed mov to clr
   05B1 E4                 2844 	clr	a
                           2845 ;	Peephole 236.b	used r3 instead of ar3
   05B2 3B                 2846 	addc	a,r3
   05B3 F5 83              2847 	mov	dph,a
                           2848 ;	genPointerGet
                           2849 ;	genFarPointerGet
   05B5 E0                 2850 	movx	a,@dptr
   05B6 FC                 2851 	mov	r4,a
                    04D9   2852 	C$TSIPMon.c$729$1$1 ==.
                           2853 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:729: UnsignedToAscii( (uint)hr, lcdbuf, 2 );
                           2854 ;	genCast
   05B7 7D 00              2855 	mov	r5,#0x00
                           2856 ;	genAssign
   05B9 75 1B 02           2857 	mov	_UnsignedToAscii_PARM_2,#_lcdbuf
   05BC 75 1C 00           2858 	mov	(_UnsignedToAscii_PARM_2 + 1),#(_lcdbuf >> 8)
                           2859 ;	genAssign
   05BF 75 1D 02           2860 	mov	_UnsignedToAscii_PARM_3,#0x02
                           2861 ;	genCall
   05C2 8C 82              2862 	mov	dpl,r4
   05C4 8D 83              2863 	mov	dph,r5
   05C6 C0 02              2864 	push	ar2
   05C8 C0 03              2865 	push	ar3
   05CA 12 0D 3E           2866 	lcall	_UnsignedToAscii
   05CD D0 03              2867 	pop	ar3
   05CF D0 02              2868 	pop	ar2
                    04F3   2869 	C$TSIPMon.c$730$1$1 ==.
                           2870 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:730: if( lcdbuf[0] == ' ' ) lcdbuf[0] = '0';
                           2871 ;	genPointerGet
                           2872 ;	genFarPointerGet
   05D1 90 00 02           2873 	mov	dptr,#_lcdbuf
   05D4 E0                 2874 	movx	a,@dptr
   05D5 FC                 2875 	mov	r4,a
                           2876 ;	genCmpEq
                           2877 ;	gencjneshort
                           2878 ;	Peephole 112.b	changed ljmp to sjmp
                           2879 ;	Peephole 198.b	optimized misc jump sequence
   05D6 BC 20 06           2880 	cjne	r4,#0x20,00106$
                           2881 ;	Peephole 200.b	removed redundant sjmp
                           2882 ;	Peephole 300	removed redundant label 00122$
                           2883 ;	Peephole 300	removed redundant label 00123$
                           2884 ;	genPointerSet
                           2885 ;     genFarPointerSet
   05D9 90 00 02           2886 	mov	dptr,#_lcdbuf
   05DC 74 30              2887 	mov	a,#0x30
   05DE F0                 2888 	movx	@dptr,a
   05DF                    2889 00106$:
                    0501   2890 	C$TSIPMon.c$731$1$1 ==.
                           2891 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:731: lcdbuf[2] = ':';
                           2892 ;	genPointerSet
                           2893 ;     genFarPointerSet
   05DF 90 00 04           2894 	mov	dptr,#(_lcdbuf + 0x0002)
   05E2 74 3A              2895 	mov	a,#0x3A
   05E4 F0                 2896 	movx	@dptr,a
                    0507   2897 	C$TSIPMon.c$732$1$1 ==.
                           2898 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:732: dom = *(RxBuf+13);
                           2899 ;	genPlus
                           2900 ;     genPlusIncr
   05E5 74 0D              2901 	mov	a,#0x0D
                           2902 ;	Peephole 236.a	used r2 instead of ar2
   05E7 2A                 2903 	add	a,r2
   05E8 F5 82              2904 	mov	dpl,a
                           2905 ;	Peephole 181	changed mov to clr
   05EA E4                 2906 	clr	a
                           2907 ;	Peephole 236.b	used r3 instead of ar3
   05EB 3B                 2908 	addc	a,r3
   05EC F5 83              2909 	mov	dph,a
                           2910 ;	genPointerGet
                           2911 ;	genFarPointerGet
   05EE E0                 2912 	movx	a,@dptr
   05EF FC                 2913 	mov	r4,a
                    0512   2914 	C$TSIPMon.c$733$1$1 ==.
                           2915 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:733: UnsignedToAscii( (uint)dom, lcdbuf+9, 2 );
                           2916 ;	genCast
   05F0 7D 00              2917 	mov	r5,#0x00
                           2918 ;	genPlus
                           2919 ;     genPlusIncr
   05F2 74 09              2920 	mov	a,#0x09
   05F4 24 02              2921 	add	a,#_lcdbuf
   05F6 F5 1B              2922 	mov	_UnsignedToAscii_PARM_2,a
                           2923 ;	Peephole 181	changed mov to clr
   05F8 E4                 2924 	clr	a
   05F9 34 00              2925 	addc	a,#(_lcdbuf >> 8)
   05FB F5 1C              2926 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           2927 ;	genAssign
   05FD 75 1D 02           2928 	mov	_UnsignedToAscii_PARM_3,#0x02
                           2929 ;	genCall
   0600 8C 82              2930 	mov	dpl,r4
   0602 8D 83              2931 	mov	dph,r5
   0604 C0 02              2932 	push	ar2
   0606 C0 03              2933 	push	ar3
   0608 12 0D 3E           2934 	lcall	_UnsignedToAscii
   060B D0 03              2935 	pop	ar3
   060D D0 02              2936 	pop	ar2
                    0531   2937 	C$TSIPMon.c$736$1$1 ==.
                           2938 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:736: if( lcdbuf[9] == ' ' ) lcdbuf[9] = '0';
                           2939 ;	genPointerGet
                           2940 ;	genFarPointerGet
   060F 90 00 0B           2941 	mov	dptr,#(_lcdbuf + 0x0009)
   0612 E0                 2942 	movx	a,@dptr
   0613 FC                 2943 	mov	r4,a
                           2944 ;	genCmpEq
                           2945 ;	gencjneshort
                           2946 ;	Peephole 112.b	changed ljmp to sjmp
                           2947 ;	Peephole 198.b	optimized misc jump sequence
   0614 BC 20 06           2948 	cjne	r4,#0x20,00108$
                           2949 ;	Peephole 200.b	removed redundant sjmp
                           2950 ;	Peephole 300	removed redundant label 00124$
                           2951 ;	Peephole 300	removed redundant label 00125$
                           2952 ;	genPointerSet
                           2953 ;     genFarPointerSet
   0617 90 00 0B           2954 	mov	dptr,#(_lcdbuf + 0x0009)
   061A 74 30              2955 	mov	a,#0x30
   061C F0                 2956 	movx	@dptr,a
   061D                    2957 00108$:
                    053F   2958 	C$TSIPMon.c$738$1$1 ==.
                           2959 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:738: mo = (*(RxBuf+14)-1)*3;
                           2960 ;	genPlus
                           2961 ;     genPlusIncr
   061D 74 0E              2962 	mov	a,#0x0E
                           2963 ;	Peephole 236.a	used r2 instead of ar2
   061F 2A                 2964 	add	a,r2
   0620 F5 82              2965 	mov	dpl,a
                           2966 ;	Peephole 181	changed mov to clr
   0622 E4                 2967 	clr	a
                           2968 ;	Peephole 236.b	used r3 instead of ar3
   0623 3B                 2969 	addc	a,r3
   0624 F5 83              2970 	mov	dph,a
                           2971 ;	genPointerGet
                           2972 ;	genFarPointerGet
   0626 E0                 2973 	movx	a,@dptr
                           2974 ;	genMinus
                           2975 ;	genMinusDec
   0627 FC                 2976 	mov	r4,a
                           2977 ;	Peephole 105	removed redundant mov
   0628 14                 2978 	dec	a
                           2979 ;	genMult
                           2980 ;	genMultOneByte
   0629 75 F0 03           2981 	mov	b,#0x03
   062C A4                 2982 	mul	ab
                    054F   2983 	C$TSIPMon.c$739$1$1 ==.
                           2984 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:739: lcdbuf[11] = Month[mo];
                           2985 ;	genPlus
   062D FC                 2986 	mov	r4,a
                           2987 ;	Peephole 177.b	removed redundant mov
                           2988 ;	Peephole 181	changed mov to clr
                           2989 ;	genPointerGet
                           2990 ;	genCodePointerGet
                           2991 ;	Peephole 186.d	optimized movc sequence
   062E 90 12 32           2992 	mov	dptr,#_Month
   0631 93                 2993 	movc	a,@a+dptr
                           2994 ;	genPointerSet
                           2995 ;     genFarPointerSet
   0632 FD                 2996 	mov	r5,a
   0633 90 00 0D           2997 	mov	dptr,#(_lcdbuf + 0x000b)
                           2998 ;	Peephole 100	removed redundant mov
   0636 F0                 2999 	movx	@dptr,a
                    0559   3000 	C$TSIPMon.c$740$1$1 ==.
                           3001 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:740: lcdbuf[12] = Month[mo+1];
                           3002 ;	genPlus
                           3003 ;     genPlusIncr
   0637 74 01              3004 	mov	a,#0x01
                           3005 ;	Peephole 236.a	used r4 instead of ar4
   0639 2C                 3006 	add	a,r4
                           3007 ;	genPlus
                           3008 ;	Peephole 240	use clr instead of addc a,#0
                           3009 ;	genPointerGet
                           3010 ;	genCodePointerGet
                           3011 ;	Peephole 186.d	optimized movc sequence
   063A 90 12 32           3012 	mov	dptr,#_Month
   063D 93                 3013 	movc	a,@a+dptr
                           3014 ;	genPointerSet
                           3015 ;     genFarPointerSet
   063E FD                 3016 	mov	r5,a
   063F 90 00 0E           3017 	mov	dptr,#(_lcdbuf + 0x000c)
                           3018 ;	Peephole 100	removed redundant mov
   0642 F0                 3019 	movx	@dptr,a
                    0565   3020 	C$TSIPMon.c$741$1$1 ==.
                           3021 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:741: lcdbuf[13] = Month[mo+2];
                           3022 ;	genPlus
                           3023 ;     genPlusIncr
   0643 74 02              3024 	mov	a,#0x02
                           3025 ;	Peephole 236.a	used r4 instead of ar4
   0645 2C                 3026 	add	a,r4
                           3027 ;	genPlus
                           3028 ;	Peephole 240	use clr instead of addc a,#0
                           3029 ;	genPointerGet
                           3030 ;	genCodePointerGet
                           3031 ;	Peephole 186.d	optimized movc sequence
   0646 90 12 32           3032 	mov	dptr,#_Month
   0649 93                 3033 	movc	a,@a+dptr
                           3034 ;	genPointerSet
                           3035 ;     genFarPointerSet
   064A FD                 3036 	mov	r5,a
   064B 90 00 0F           3037 	mov	dptr,#(_lcdbuf + 0x000d)
                           3038 ;	Peephole 100	removed redundant mov
   064E F0                 3039 	movx	@dptr,a
                    0571   3040 	C$TSIPMon.c$742$1$1 ==.
                           3041 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:742: yr.b.hi = *(RxBuf+15);
                           3042 ;	genPlus
                           3043 ;     genPlusIncr
   064F 74 0F              3044 	mov	a,#0x0F
                           3045 ;	Peephole 236.a	used r2 instead of ar2
   0651 2A                 3046 	add	a,r2
   0652 F5 82              3047 	mov	dpl,a
                           3048 ;	Peephole 181	changed mov to clr
   0654 E4                 3049 	clr	a
                           3050 ;	Peephole 236.b	used r3 instead of ar3
   0655 3B                 3051 	addc	a,r3
   0656 F5 83              3052 	mov	dph,a
                           3053 ;	genPointerGet
                           3054 ;	genFarPointerGet
   0658 E0                 3055 	movx	a,@dptr
   0659 FD                 3056 	mov	r5,a
                           3057 ;	genPointerSet
                           3058 ;	genNearPointerSet
                           3059 ;	genDataPointerSet
   065A 8D 32              3060 	mov	(_PrimaryTiming_yr_1_1 + 0x0001),r5
                    057E   3061 	C$TSIPMon.c$743$1$1 ==.
                           3062 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:743: yr.b.lo = *(RxBuf+16);
                           3063 ;	genPlus
                           3064 ;     genPlusIncr
   065C 74 10              3065 	mov	a,#0x10
                           3066 ;	Peephole 236.a	used r2 instead of ar2
   065E 2A                 3067 	add	a,r2
   065F F5 82              3068 	mov	dpl,a
                           3069 ;	Peephole 181	changed mov to clr
   0661 E4                 3070 	clr	a
                           3071 ;	Peephole 236.b	used r3 instead of ar3
   0662 3B                 3072 	addc	a,r3
   0663 F5 83              3073 	mov	dph,a
                           3074 ;	genPointerGet
                           3075 ;	genFarPointerGet
   0665 E0                 3076 	movx	a,@dptr
                           3077 ;	genPointerSet
                           3078 ;	genNearPointerSet
                           3079 ;	genDataPointerSet
                    0588   3080 	C$TSIPMon.c$745$1$1 ==.
                           3081 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:745: mo = yr.u - 2000;
                           3082 ;	genAssign
                           3083 ;	genCast
                           3084 ;	Peephole 177.a	removed redundant mov
                           3085 ;	genMinus
   0666 FA                 3086 	mov	r2,a
   0667 8A 31              3087 	mov	_PrimaryTiming_yr_1_1,r2
                           3088 ;	Peephole 177.d	removed redundant move
   0669 24 30              3089 	add	a,#0x30
   066B FC                 3090 	mov	r4,a
                    058E   3091 	C$TSIPMon.c$746$1$1 ==.
                           3092 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:746: UnsignedToAscii( (uint)mo, lcdbuf+14, 2 );
                           3093 ;	genCast
   066C 7A 00              3094 	mov	r2,#0x00
                           3095 ;	genPlus
                           3096 ;     genPlusIncr
   066E 74 0E              3097 	mov	a,#0x0E
   0670 24 02              3098 	add	a,#_lcdbuf
   0672 F5 1B              3099 	mov	_UnsignedToAscii_PARM_2,a
                           3100 ;	Peephole 181	changed mov to clr
   0674 E4                 3101 	clr	a
   0675 34 00              3102 	addc	a,#(_lcdbuf >> 8)
   0677 F5 1C              3103 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           3104 ;	genAssign
   0679 75 1D 02           3105 	mov	_UnsignedToAscii_PARM_3,#0x02
                           3106 ;	genCall
   067C 8C 82              3107 	mov	dpl,r4
   067E 8A 83              3108 	mov	dph,r2
   0680 12 0D 3E           3109 	lcall	_UnsignedToAscii
                    05A5   3110 	C$TSIPMon.c$747$1$1 ==.
                           3111 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:747: if( lcdbuf[14] == ' ' ) lcdbuf[14] = '0';
                           3112 ;	genPointerGet
                           3113 ;	genFarPointerGet
   0683 90 00 10           3114 	mov	dptr,#(_lcdbuf + 0x000e)
   0686 E0                 3115 	movx	a,@dptr
   0687 FA                 3116 	mov	r2,a
                           3117 ;	genCmpEq
                           3118 ;	gencjneshort
                           3119 ;	Peephole 112.b	changed ljmp to sjmp
                           3120 ;	Peephole 198.b	optimized misc jump sequence
   0688 BA 20 06           3121 	cjne	r2,#0x20,00110$
                           3122 ;	Peephole 200.b	removed redundant sjmp
                           3123 ;	Peephole 300	removed redundant label 00126$
                           3124 ;	Peephole 300	removed redundant label 00127$
                           3125 ;	genPointerSet
                           3126 ;     genFarPointerSet
   068B 90 00 10           3127 	mov	dptr,#(_lcdbuf + 0x000e)
   068E 74 30              3128 	mov	a,#0x30
   0690 F0                 3129 	movx	@dptr,a
   0691                    3130 00110$:
                    05B3   3131 	C$TSIPMon.c$748$1$1 ==.
                           3132 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:748: lcdbuf[16] = '\0';
                           3133 ;	genPointerSet
                           3134 ;     genFarPointerSet
   0691 90 00 12           3135 	mov	dptr,#(_lcdbuf + 0x0010)
                           3136 ;	Peephole 181	changed mov to clr
   0694 E4                 3137 	clr	a
   0695 F0                 3138 	movx	@dptr,a
                           3139 ;	Peephole 300	removed redundant label 00111$
                    05B8   3140 	C$TSIPMon.c$758$1$1 ==.
                    05B8   3141 	XG$PrimaryTiming$0$0 ==.
   0696 22                 3142 	ret
                           3143 ;------------------------------------------------------------
                           3144 ;Allocation info for local variables in function 'SupplementalTiming'
                           3145 ;------------------------------------------------------------
                           3146 ;mode                      Allocated with name '_SupplementalTiming_mode_1_1'
                           3147 ;RxBuf                     Allocated with name '_SupplementalTiming_RxBuf_1_1'
                           3148 ;temp                      Allocated with name '_SupplementalTiming_temp_1_1'
                           3149 ;val                       Allocated with name '_SupplementalTiming_val_1_1'
                           3150 ;fval                      Allocated with name '_SupplementalTiming_fval_1_1'
                           3151 ;sloc0                     Allocated with name '_SupplementalTiming_sloc0_1_0'
                           3152 ;sloc1                     Allocated with name '_SupplementalTiming_sloc1_1_0'
                           3153 ;------------------------------------------------------------
                    05B9   3154 	G$SupplementalTiming$0$0 ==.
                    05B9   3155 	C$TSIPMon.c$764$1$1 ==.
                           3156 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:764: void SupplementalTiming( uchar TXRX_STORAGE_CLASS *RxBuf ){
                           3157 ;	-----------------------------------------
                           3158 ;	 function SupplementalTiming
                           3159 ;	-----------------------------------------
   0697                    3160 _SupplementalTiming:
                           3161 ;	genReceive
   0697 85 82 34           3162 	mov	_SupplementalTiming_RxBuf_1_1,dpl
   069A 85 83 35           3163 	mov	(_SupplementalTiming_RxBuf_1_1 + 1),dph
                    05BF   3164 	C$TSIPMon.c$786$1$1 ==.
                           3165 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:786: printLCD( 1, lcdbuf, 0 );	// print 1st line
                           3166 ;	genAddrOf
   069D 75 08 02           3167 	mov	_printLCD_PARM_2,#_lcdbuf
   06A0 75 09 00           3168 	mov	(_printLCD_PARM_2 + 1),#(_lcdbuf >> 8)
                           3169 ;	genAssign
   06A3 75 0A 00           3170 	mov	_printLCD_PARM_3,#0x00
                           3171 ;	genCall
   06A6 75 82 01           3172 	mov	dpl,#0x01
   06A9 12 0B 57           3173 	lcall	_printLCD
                    05CE   3174 	C$TSIPMon.c$791$1$1 ==.
                           3175 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:791: Alarms.b.hi = RxBuf[10];
                           3176 ;	genPlus
                           3177 ;     genPlusIncr
   06AC 74 0A              3178 	mov	a,#0x0A
   06AE 25 34              3179 	add	a,_SupplementalTiming_RxBuf_1_1
   06B0 F5 82              3180 	mov	dpl,a
                           3181 ;	Peephole 181	changed mov to clr
   06B2 E4                 3182 	clr	a
   06B3 35 35              3183 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   06B5 F5 83              3184 	mov	dph,a
                           3185 ;	genPointerGet
                           3186 ;	genFarPointerGet
   06B7 E0                 3187 	movx	a,@dptr
                           3188 ;	genPointerSet
                           3189 ;     genFarPointerSet
   06B8 FC                 3190 	mov	r4,a
   06B9 90 00 01           3191 	mov	dptr,#(_Alarms + 0x0001)
                           3192 ;	Peephole 100	removed redundant mov
   06BC F0                 3193 	movx	@dptr,a
                    05DF   3194 	C$TSIPMon.c$792$1$1 ==.
                           3195 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:792: Alarms.b.lo = RxBuf[11];
                           3196 ;	genPlus
                           3197 ;     genPlusIncr
   06BD 74 0B              3198 	mov	a,#0x0B
   06BF 25 34              3199 	add	a,_SupplementalTiming_RxBuf_1_1
   06C1 F5 82              3200 	mov	dpl,a
                           3201 ;	Peephole 181	changed mov to clr
   06C3 E4                 3202 	clr	a
   06C4 35 35              3203 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   06C6 F5 83              3204 	mov	dph,a
                           3205 ;	genPointerGet
                           3206 ;	genFarPointerGet
   06C8 E0                 3207 	movx	a,@dptr
                           3208 ;	genPointerSet
                           3209 ;     genFarPointerSet
   06C9 FC                 3210 	mov	r4,a
   06CA 90 00 00           3211 	mov	dptr,#_Alarms
                           3212 ;	Peephole 100	removed redundant mov
   06CD F0                 3213 	movx	@dptr,a
                    05F0   3214 	C$TSIPMon.c$794$1$1 ==.
                           3215 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:794: Alarms.u = Alarms.u<<5;
                           3216 ;	genPointerGet
                           3217 ;	genFarPointerGet
   06CE 90 00 00           3218 	mov	dptr,#_Alarms
   06D1 E0                 3219 	movx	a,@dptr
   06D2 FC                 3220 	mov	r4,a
   06D3 A3                 3221 	inc	dptr
   06D4 E0                 3222 	movx	a,@dptr
                           3223 ;	genLeftShift
                           3224 ;	genLeftShiftLiteral
                           3225 ;	genlshTwo
   06D5 FD                 3226 	mov	r5,a
                           3227 ;	Peephole 105	removed redundant mov
   06D6 C4                 3228 	swap	a
   06D7 23                 3229 	rl	a
   06D8 54 E0              3230 	anl	a,#0xe0
   06DA CC                 3231 	xch	a,r4
   06DB C4                 3232 	swap	a
   06DC 23                 3233 	rl	a
   06DD CC                 3234 	xch	a,r4
   06DE 6C                 3235 	xrl	a,r4
   06DF CC                 3236 	xch	a,r4
   06E0 54 E0              3237 	anl	a,#0xe0
   06E2 CC                 3238 	xch	a,r4
   06E3 6C                 3239 	xrl	a,r4
   06E4 FD                 3240 	mov	r5,a
                           3241 ;	genPointerSet
                           3242 ;     genFarPointerSet
   06E5 90 00 00           3243 	mov	dptr,#_Alarms
   06E8 EC                 3244 	mov	a,r4
   06E9 F0                 3245 	movx	@dptr,a
   06EA A3                 3246 	inc	dptr
   06EB ED                 3247 	mov	a,r5
   06EC F0                 3248 	movx	@dptr,a
                    060F   3249 	C$TSIPMon.c$796$1$1 ==.
                           3250 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:796: Alarms.b.lo |= RxBuf[9];
                           3251 ;	genPointerGet
                           3252 ;	genFarPointerGet
   06ED 90 00 00           3253 	mov	dptr,#_Alarms
   06F0 E0                 3254 	movx	a,@dptr
   06F1 FC                 3255 	mov	r4,a
                           3256 ;	genPlus
                           3257 ;     genPlusIncr
   06F2 74 09              3258 	mov	a,#0x09
   06F4 25 34              3259 	add	a,_SupplementalTiming_RxBuf_1_1
   06F6 FD                 3260 	mov	r5,a
                           3261 ;	Peephole 181	changed mov to clr
   06F7 E4                 3262 	clr	a
   06F8 35 35              3263 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   06FA FE                 3264 	mov	r6,a
                           3265 ;	genPointerGet
                           3266 ;	genFarPointerGet
   06FB 8D 82              3267 	mov	dpl,r5
   06FD 8E 83              3268 	mov	dph,r6
   06FF E0                 3269 	movx	a,@dptr
                           3270 ;	genOr
   0700 FF                 3271 	mov	r7,a
                           3272 ;	Peephole 105	removed redundant mov
   0701 42 04              3273 	orl	ar4,a
                           3274 ;	genPointerSet
                           3275 ;     genFarPointerSet
   0703 90 00 00           3276 	mov	dptr,#_Alarms
   0706 EC                 3277 	mov	a,r4
   0707 F0                 3278 	movx	@dptr,a
                    062A   3279 	C$TSIPMon.c$799$1$1 ==.
                           3280 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:799: c = !c;  // only change display every 2nd time thru ( about every 2 seconds)
                           3281 ;	genNot
   0708 B2 09              3282 	cpl	_SupplementalTiming_c_1_1
                    062C   3283 	C$TSIPMon.c$800$1$1 ==.
                           3284 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:800: if( c )
                           3285 ;	genIfx
                           3286 ;	genIfxJump
                           3287 ;	Peephole 108.d	removed ljmp by inverse jump logic
   070A 30 09 01           3288 	jnb	_SupplementalTiming_c_1_1,00102$
                           3289 ;	Peephole 300	removed redundant label 00143$
                    062F   3290 	C$TSIPMon.c$801$1$1 ==.
                           3291 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:801: return;
                           3292 ;	genRet
                           3293 ;	Peephole 251.a	replaced ljmp to ret with ret
   070D 22                 3294 	ret
   070E                    3295 00102$:
                    0630   3296 	C$TSIPMon.c$803$1$1 ==.
                           3297 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:803: ClearLCD( 2 );
                           3298 ;	genCall
   070E 75 82 02           3299 	mov	dpl,#0x02
   0711 C0 05              3300 	push	ar5
   0713 C0 06              3301 	push	ar6
   0715 12 0A EB           3302 	lcall	_ClearLCD
   0718 D0 06              3303 	pop	ar6
   071A D0 05              3304 	pop	ar5
                    063E   3305 	C$TSIPMon.c$804$1$1 ==.
                           3306 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:804: if( Alarms.u != 0 && mode == NUM_DISPLAY_MODES - 1 ){
                           3307 ;	genPointerGet
                           3308 ;	genFarPointerGet
   071C 90 00 00           3309 	mov	dptr,#_Alarms
   071F E0                 3310 	movx	a,@dptr
   0720 FC                 3311 	mov	r4,a
   0721 A3                 3312 	inc	dptr
   0722 E0                 3313 	movx	a,@dptr
   0723 FF                 3314 	mov	r7,a
                           3315 ;	genCmpEq
                           3316 ;	gencjneshort
   0724 BC 00 05           3317 	cjne	r4,#0x00,00144$
   0727 BF 00 02           3318 	cjne	r7,#0x00,00144$
                           3319 ;	Peephole 112.b	changed ljmp to sjmp
   072A 80 4D              3320 	sjmp	00108$
   072C                    3321 00144$:
                           3322 ;	genCmpEq
                           3323 ;	gencjneshort
   072C E5 33              3324 	mov	a,_SupplementalTiming_mode_1_1
                           3325 ;	Peephole 112.b	changed ljmp to sjmp
                           3326 ;	Peephole 198.b	optimized misc jump sequence
   072E B4 05 48           3327 	cjne	a,#0x05,00108$
                           3328 ;	Peephole 200.b	removed redundant sjmp
                           3329 ;	Peephole 300	removed redundant label 00145$
                           3330 ;	Peephole 300	removed redundant label 00146$
                    0653   3331 	C$TSIPMon.c$805$2$2 ==.
                           3332 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:805: b = Fault_Msg_Query( Alarms.u, lcdbuf, ALARM_MSG[0] );
                           3333 ;	genPointerGet
                           3334 ;	genFarPointerGet
   0731 90 00 00           3335 	mov	dptr,#_Alarms
   0734 E0                 3336 	movx	a,@dptr
   0735 FC                 3337 	mov	r4,a
   0736 A3                 3338 	inc	dptr
   0737 E0                 3339 	movx	a,@dptr
   0738 FF                 3340 	mov	r7,a
                           3341 ;	genAddrOf
   0739 75 41 02           3342 	mov	_Fault_Msg_Query_PARM_2,#_lcdbuf
   073C 75 42 00           3343 	mov	(_Fault_Msg_Query_PARM_2 + 1),#(_lcdbuf >> 8)
                           3344 ;	genAddrOf
   073F 75 43 65           3345 	mov	_Fault_Msg_Query_PARM_3,#_ALARM_MSG
   0742 75 44 15           3346 	mov	(_Fault_Msg_Query_PARM_3 + 1),#(_ALARM_MSG >> 8)
                           3347 ;	genCall
   0745 8C 82              3348 	mov	dpl,r4
   0747 8F 83              3349 	mov	dph,r7
   0749 C0 05              3350 	push	ar5
   074B C0 06              3351 	push	ar6
   074D 12 0D F7           3352 	lcall	_Fault_Msg_Query
   0750 92 08              3353 	mov	_SupplementalTiming_b_1_1,c
   0752 D0 06              3354 	pop	ar6
   0754 D0 05              3355 	pop	ar5
                    0678   3356 	C$TSIPMon.c$806$2$2 ==.
                           3357 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:806: if( b )
                           3358 ;	genIfx
                           3359 ;	genIfxJump
                           3360 ;	Peephole 108.d	removed ljmp by inverse jump logic
   0756 30 08 17           3361 	jnb	_SupplementalTiming_b_1_1,00104$
                           3362 ;	Peephole 300	removed redundant label 00147$
                    067B   3363 	C$TSIPMon.c$807$2$2 ==.
                           3364 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:807: printLCD( 2, lcdbuf, 0 ); 
                           3365 ;	genAddrOf
   0759 75 08 02           3366 	mov	_printLCD_PARM_2,#_lcdbuf
   075C 75 09 00           3367 	mov	(_printLCD_PARM_2 + 1),#(_lcdbuf >> 8)
                           3368 ;	genAssign
   075F 75 0A 00           3369 	mov	_printLCD_PARM_3,#0x00
                           3370 ;	genCall
   0762 75 82 02           3371 	mov	dpl,#0x02
   0765 C0 05              3372 	push	ar5
   0767 C0 06              3373 	push	ar6
   0769 12 0B 57           3374 	lcall	_printLCD
   076C D0 06              3375 	pop	ar6
   076E D0 05              3376 	pop	ar5
   0770                    3377 00104$:
                    0692   3378 	C$TSIPMon.c$808$2$2 ==.
                           3379 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:808: if( RxBuf[9] != 0 ) // if critical alarm, keep showing it
                           3380 ;	genPointerGet
                           3381 ;	genFarPointerGet
   0770 8D 82              3382 	mov	dpl,r5
   0772 8E 83              3383 	mov	dph,r6
   0774 E0                 3384 	movx	a,@dptr
                           3385 ;	genCmpEq
                           3386 ;	gencjneshort
                           3387 ;	Peephole 112.b	changed ljmp to sjmp
   0775 FD                 3388 	mov	r5,a
                           3389 ;	Peephole 115.b	jump optimization
   0776 60 01              3390 	jz	00108$
                           3391 ;	Peephole 300	removed redundant label 00148$
                    069A   3392 	C$TSIPMon.c$809$2$2 ==.
                           3393 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:809: return;        
                           3394 ;	genRet
                           3395 ;	Peephole 251.a	replaced ljmp to ret with ret
   0778 22                 3396 	ret
   0779                    3397 00108$:
                    069B   3398 	C$TSIPMon.c$812$1$1 ==.
                           3399 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:812: if( !b ){
                           3400 ;	genIfx
                           3401 ;	genIfxJump
   0779 30 08 01           3402 	jnb	_SupplementalTiming_b_1_1,00149$
                           3403 ;	Peephole 251.a	replaced ljmp to ret with ret
   077C 22                 3404 	ret
   077D                    3405 00149$:
                    069F   3406 	C$TSIPMon.c$813$2$3 ==.
                           3407 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:813: if( ++mode >= NUM_DISPLAY_MODES )
                           3408 ;	genPlus
                           3409 ;     genPlusIncr
   077D 05 33              3410 	inc	_SupplementalTiming_mode_1_1
                           3411 ;	genCmpLt
                           3412 ;	genCmp
   077F C3                 3413 	clr	c
   0780 E5 33              3414 	mov	a,_SupplementalTiming_mode_1_1
   0782 64 80              3415 	xrl	a,#0x80
   0784 94 86              3416 	subb	a,#0x86
                           3417 ;	genIfxJump
                           3418 ;	Peephole 112.b	changed ljmp to sjmp
                           3419 ;	Peephole 160.a	removed sjmp by inverse jump logic
   0786 40 03              3420 	jc	00111$
                           3421 ;	Peephole 300	removed redundant label 00150$
                    06AA   3422 	C$TSIPMon.c$814$2$3 ==.
                           3423 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:814: mode = 0;
                           3424 ;	genAssign
   0788 75 33 00           3425 	mov	_SupplementalTiming_mode_1_1,#0x00
   078B                    3426 00111$:
                    06AD   3427 	C$TSIPMon.c$816$2$3 ==.
                           3428 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:816: val = 28;
                           3429 ;	genAssign
   078B 75 3A 1C           3430 	mov	_SupplementalTiming_val_1_1,#0x1C
                    06B0   3431 	C$TSIPMon.c$817$2$3 ==.
                           3432 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:817: fval = 10000;
                           3433 ;	genAssign
   078E 75 3B 10           3434 	mov	_SupplementalTiming_fval_1_1,#0x10
   0791 75 3C 27           3435 	mov	(_SupplementalTiming_fval_1_1 + 1),#0x27
                    06B6   3436 	C$TSIPMon.c$818$2$3 ==.
                           3437 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:818: switch( mode ){
                           3438 ;	genCmpLt
                           3439 ;	genCmp
   0794 E5 33              3440 	mov	a,_SupplementalTiming_mode_1_1
                           3441 ;	genIfxJump
   0796 30 E7 03           3442 	jnb	acc.7,00151$
   0799 02 09 E9           3443 	ljmp	00125$
   079C                    3444 00151$:
                           3445 ;	genCmpGt
                           3446 ;	genCmp
   079C C3                 3447 	clr	c
                           3448 ;	Peephole 159	avoided xrl during execution
   079D 74 85              3449 	mov	a,#(0x05 ^ 0x80)
   079F 85 33 F0           3450 	mov	b,_SupplementalTiming_mode_1_1
   07A2 63 F0 80           3451 	xrl	b,#0x80
   07A5 95 F0              3452 	subb	a,b
                           3453 ;	genIfxJump
   07A7 50 03              3454 	jnc	00152$
   07A9 02 09 E9           3455 	ljmp	00125$
   07AC                    3456 00152$:
                           3457 ;	genJumpTab
   07AC E5 33              3458 	mov	a,_SupplementalTiming_mode_1_1
                           3459 ;	Peephole 254	optimized left shift
   07AE 25 33              3460 	add	a,_SupplementalTiming_mode_1_1
   07B0 25 33              3461 	add	a,_SupplementalTiming_mode_1_1
   07B2 90 07 B6           3462 	mov	dptr,#00153$
   07B5 73                 3463 	jmp	@a+dptr
   07B6                    3464 00153$:
   07B6 02 07 C8           3465 	ljmp	00112$
   07B9 02 07 F0           3466 	ljmp	00113$
   07BC 02 08 1B           3467 	ljmp	00114$
   07BF 02 08 42           3468 	ljmp	00115$
   07C2 02 08 6E           3469 	ljmp	00116$
   07C5 02 08 77           3470 	ljmp	00117$
                    06EA   3471 	C$TSIPMon.c$819$3$4 ==.
                           3472 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:819: case 0:	// disciplining mode
   07C8                    3473 00112$:
                    06EA   3474 	C$TSIPMon.c$820$3$4 ==.
                           3475 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:820: strcpy( lcdbuf , DiscMode[RxBuf[2]]);
                           3476 ;	genPlus
                           3477 ;     genPlusIncr
   07C8 85 34 82           3478 	mov	dpl,_SupplementalTiming_RxBuf_1_1
   07CB 85 35 83           3479 	mov	dph,(_SupplementalTiming_RxBuf_1_1 + 1)
   07CE A3                 3480 	inc	dptr
   07CF A3                 3481 	inc	dptr
                           3482 ;	genPointerGet
                           3483 ;	genFarPointerGet
   07D0 E0                 3484 	movx	a,@dptr
                           3485 ;	genMult
                           3486 ;	genMultOneByte
   07D1 FF                 3487 	mov	r7,a
                           3488 ;	Peephole 105	removed redundant mov
   07D2 75 F0 11           3489 	mov	b,#0x11
   07D5 A4                 3490 	mul	ab
                           3491 ;	genPlus
   07D6 24 DF              3492 	add	a,#_DiscMode
   07D8 FA                 3493 	mov	r2,a
                           3494 ;	Peephole 240	use clr instead of addc a,#0
   07D9 E4                 3495 	clr	a
   07DA 34 12              3496 	addc	a,#(_DiscMode >> 8)
   07DC FB                 3497 	mov	r3,a
                           3498 ;	genCast
   07DD 8A 41              3499 	mov	_strcpy_PARM_2,r2
   07DF 8B 42              3500 	mov	(_strcpy_PARM_2 + 1),r3
   07E1 75 43 80           3501 	mov	(_strcpy_PARM_2 + 2),#0x80
                           3502 ;	genCall
                           3503 ;	Peephole 182.a	used 16 bit load of DPTR
   07E4 90 00 02           3504 	mov	dptr,#_lcdbuf
   07E7 75 F0 00           3505 	mov	b,#0x00
   07EA 12 0E F8           3506 	lcall	_strcpy
                    070F   3507 	C$TSIPMon.c$821$3$4 ==.
                           3508 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:821: break;
   07ED 02 09 E9           3509 	ljmp	00125$
                    0712   3510 	C$TSIPMon.c$823$3$4 ==.
                           3511 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:823: case 1:	// Discipling Activity
   07F0                    3512 00113$:
                    0712   3513 	C$TSIPMon.c$824$3$4 ==.
                           3514 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:824: strcpy( lcdbuf , DiscActivity[RxBuf[13]]);
                           3515 ;	genPlus
                           3516 ;     genPlusIncr
   07F0 74 0D              3517 	mov	a,#0x0D
   07F2 25 34              3518 	add	a,_SupplementalTiming_RxBuf_1_1
   07F4 F5 82              3519 	mov	dpl,a
                           3520 ;	Peephole 181	changed mov to clr
   07F6 E4                 3521 	clr	a
   07F7 35 35              3522 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   07F9 F5 83              3523 	mov	dph,a
                           3524 ;	genPointerGet
                           3525 ;	genFarPointerGet
   07FB E0                 3526 	movx	a,@dptr
                           3527 ;	genMult
                           3528 ;	genMultOneByte
   07FC FF                 3529 	mov	r7,a
                           3530 ;	Peephole 105	removed redundant mov
   07FD 75 F0 11           3531 	mov	b,#0x11
   0800 A4                 3532 	mul	ab
                           3533 ;	genPlus
   0801 24 77              3534 	add	a,#_DiscActivity
   0803 FA                 3535 	mov	r2,a
                           3536 ;	Peephole 240	use clr instead of addc a,#0
   0804 E4                 3537 	clr	a
   0805 34 14              3538 	addc	a,#(_DiscActivity >> 8)
   0807 FB                 3539 	mov	r3,a
                           3540 ;	genCast
   0808 8A 41              3541 	mov	_strcpy_PARM_2,r2
   080A 8B 42              3542 	mov	(_strcpy_PARM_2 + 1),r3
   080C 75 43 80           3543 	mov	(_strcpy_PARM_2 + 2),#0x80
                           3544 ;	genCall
                           3545 ;	Peephole 182.a	used 16 bit load of DPTR
   080F 90 00 02           3546 	mov	dptr,#_lcdbuf
   0812 75 F0 00           3547 	mov	b,#0x00
   0815 12 0E F8           3548 	lcall	_strcpy
                    073A   3549 	C$TSIPMon.c$825$3$4 ==.
                           3550 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:825: break;
   0818 02 09 E9           3551 	ljmp	00125$
                    073D   3552 	C$TSIPMon.c$827$3$4 ==.
                           3553 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:827: case 2:	// Receiver mode
   081B                    3554 00114$:
                    073D   3555 	C$TSIPMon.c$828$3$4 ==.
                           3556 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:828: strcpy( lcdbuf , RxMode[RxBuf[1]]);
                           3557 ;	genPlus
                           3558 ;     genPlusIncr
   081B 85 34 82           3559 	mov	dpl,_SupplementalTiming_RxBuf_1_1
   081E 85 35 83           3560 	mov	dph,(_SupplementalTiming_RxBuf_1_1 + 1)
   0821 A3                 3561 	inc	dptr
                           3562 ;	genPointerGet
                           3563 ;	genFarPointerGet
   0822 E0                 3564 	movx	a,@dptr
                           3565 ;	genMult
                           3566 ;	genMultOneByte
   0823 FF                 3567 	mov	r7,a
                           3568 ;	Peephole 105	removed redundant mov
   0824 75 F0 11           3569 	mov	b,#0x11
   0827 A4                 3570 	mul	ab
                           3571 ;	genPlus
   0828 24 57              3572 	add	a,#_RxMode
   082A FA                 3573 	mov	r2,a
                           3574 ;	Peephole 240	use clr instead of addc a,#0
   082B E4                 3575 	clr	a
   082C 34 12              3576 	addc	a,#(_RxMode >> 8)
   082E FB                 3577 	mov	r3,a
                           3578 ;	genCast
   082F 8A 41              3579 	mov	_strcpy_PARM_2,r2
   0831 8B 42              3580 	mov	(_strcpy_PARM_2 + 1),r3
   0833 75 43 80           3581 	mov	(_strcpy_PARM_2 + 2),#0x80
                           3582 ;	genCall
                           3583 ;	Peephole 182.a	used 16 bit load of DPTR
   0836 90 00 02           3584 	mov	dptr,#_lcdbuf
   0839 75 F0 00           3585 	mov	b,#0x00
   083C 12 0E F8           3586 	lcall	_strcpy
                    0761   3587 	C$TSIPMon.c$829$3$4 ==.
                           3588 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:829: break;
   083F 02 09 E9           3589 	ljmp	00125$
                    0764   3590 	C$TSIPMon.c$831$3$4 ==.
                           3591 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:831: case 3:	// GPS Decode Status
   0842                    3592 00115$:
                    0764   3593 	C$TSIPMon.c$832$3$4 ==.
                           3594 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:832: strcpy( lcdbuf , GPSDecodeStatus[RxBuf[12]]);
                           3595 ;	genPlus
                           3596 ;     genPlusIncr
   0842 74 0C              3597 	mov	a,#0x0C
   0844 25 34              3598 	add	a,_SupplementalTiming_RxBuf_1_1
   0846 F5 82              3599 	mov	dpl,a
                           3600 ;	Peephole 181	changed mov to clr
   0848 E4                 3601 	clr	a
   0849 35 35              3602 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   084B F5 83              3603 	mov	dph,a
                           3604 ;	genPointerGet
                           3605 ;	genFarPointerGet
   084D E0                 3606 	movx	a,@dptr
                           3607 ;	genMult
                           3608 ;	genMultOneByte
   084E FF                 3609 	mov	r7,a
                           3610 ;	Peephole 105	removed redundant mov
   084F 75 F0 11           3611 	mov	b,#0x11
   0852 A4                 3612 	mul	ab
                           3613 ;	genPlus
   0853 24 56              3614 	add	a,#_GPSDecodeStatus
   0855 FA                 3615 	mov	r2,a
   0856 74 13              3616 	mov	a,#(_GPSDecodeStatus >> 8)
   0858 35 F0              3617 	addc	a,b
   085A FB                 3618 	mov	r3,a
                           3619 ;	genCast
   085B 8A 41              3620 	mov	_strcpy_PARM_2,r2
   085D 8B 42              3621 	mov	(_strcpy_PARM_2 + 1),r3
   085F 75 43 80           3622 	mov	(_strcpy_PARM_2 + 2),#0x80
                           3623 ;	genCall
                           3624 ;	Peephole 182.a	used 16 bit load of DPTR
   0862 90 00 02           3625 	mov	dptr,#_lcdbuf
   0865 75 F0 00           3626 	mov	b,#0x00
   0868 12 0E F8           3627 	lcall	_strcpy
                    078D   3628 	C$TSIPMon.c$833$3$4 ==.
                           3629 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:833: break;
   086B 02 09 E9           3630 	ljmp	00125$
                    0790   3631 	C$TSIPMon.c$835$3$4 ==.
                           3632 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:835: case 4:	// RxBuf[32-35] is temperature (float)
   086E                    3633 00116$:
                    0790   3634 	C$TSIPMon.c$836$3$4 ==.
                           3635 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:836: val = 32;
                           3636 ;	genAssign
   086E 75 3A 20           3637 	mov	_SupplementalTiming_val_1_1,#0x20
                    0793   3638 	C$TSIPMon.c$837$3$4 ==.
                           3639 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:837: fval = 100;
                           3640 ;	genAssign
   0871 75 3B 64           3641 	mov	_SupplementalTiming_fval_1_1,#0x64
   0874 E4                 3642 	clr	a
   0875 F5 3C              3643 	mov	(_SupplementalTiming_fval_1_1 + 1),a
                    0799   3644 	C$TSIPMon.c$840$3$4 ==.
                           3645 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:840: case 5:	// RxBuf[28-31] is DAC Voltage (float)
   0877                    3646 00117$:
                    0799   3647 	C$TSIPMon.c$841$3$4 ==.
                           3648 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:841: temp.b.hhi = RxBuf[val];
                           3649 ;	genPlus
   0877 E5 3A              3650 	mov	a,_SupplementalTiming_val_1_1
   0879 25 34              3651 	add	a,_SupplementalTiming_RxBuf_1_1
   087B F5 82              3652 	mov	dpl,a
                           3653 ;	Peephole 181	changed mov to clr
   087D E4                 3654 	clr	a
   087E 35 35              3655 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   0880 F5 83              3656 	mov	dph,a
                           3657 ;	genPointerGet
                           3658 ;	genFarPointerGet
   0882 E0                 3659 	movx	a,@dptr
   0883 FF                 3660 	mov	r7,a
                           3661 ;	genPointerSet
                           3662 ;	genNearPointerSet
                           3663 ;	genDataPointerSet
   0884 8F 39              3664 	mov	(_SupplementalTiming_temp_1_1 + 0x0003),r7
                    07A8   3665 	C$TSIPMon.c$842$3$4 ==.
                           3666 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:842: temp.b.hi = RxBuf[val+1];
                           3667 ;	genCast
   0886 AF 3A              3668 	mov	r7,_SupplementalTiming_val_1_1
   0888 7D 00              3669 	mov	r5,#0x00
                           3670 ;	genPlus
                           3671 ;     genPlusIncr
   088A 74 01              3672 	mov	a,#0x01
                           3673 ;	Peephole 236.a	used r7 instead of ar7
   088C 2F                 3674 	add	a,r7
   088D FE                 3675 	mov	r6,a
                           3676 ;	Peephole 181	changed mov to clr
   088E E4                 3677 	clr	a
                           3678 ;	Peephole 236.b	used r5 instead of ar5
   088F 3D                 3679 	addc	a,r5
   0890 FA                 3680 	mov	r2,a
                           3681 ;	genPlus
                           3682 ;	Peephole 236.g	used r6 instead of ar6
   0891 EE                 3683 	mov	a,r6
   0892 25 34              3684 	add	a,_SupplementalTiming_RxBuf_1_1
   0894 F5 82              3685 	mov	dpl,a
                           3686 ;	Peephole 236.g	used r2 instead of ar2
   0896 EA                 3687 	mov	a,r2
   0897 35 35              3688 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   0899 F5 83              3689 	mov	dph,a
                           3690 ;	genPointerGet
                           3691 ;	genFarPointerGet
   089B E0                 3692 	movx	a,@dptr
   089C FA                 3693 	mov	r2,a
                           3694 ;	genPointerSet
                           3695 ;	genNearPointerSet
                           3696 ;	genDataPointerSet
   089D 8A 38              3697 	mov	(_SupplementalTiming_temp_1_1 + 0x0002),r2
                    07C1   3698 	C$TSIPMon.c$843$3$4 ==.
                           3699 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:843: temp.b.lo = RxBuf[val+2];
                           3700 ;	genPlus
                           3701 ;     genPlusIncr
   089F 74 02              3702 	mov	a,#0x02
                           3703 ;	Peephole 236.a	used r7 instead of ar7
   08A1 2F                 3704 	add	a,r7
   08A2 FA                 3705 	mov	r2,a
                           3706 ;	Peephole 181	changed mov to clr
   08A3 E4                 3707 	clr	a
                           3708 ;	Peephole 236.b	used r5 instead of ar5
   08A4 3D                 3709 	addc	a,r5
   08A5 FB                 3710 	mov	r3,a
                           3711 ;	genPlus
                           3712 ;	Peephole 236.g	used r2 instead of ar2
   08A6 EA                 3713 	mov	a,r2
   08A7 25 34              3714 	add	a,_SupplementalTiming_RxBuf_1_1
   08A9 F5 82              3715 	mov	dpl,a
                           3716 ;	Peephole 236.g	used r3 instead of ar3
   08AB EB                 3717 	mov	a,r3
   08AC 35 35              3718 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   08AE F5 83              3719 	mov	dph,a
                           3720 ;	genPointerGet
                           3721 ;	genFarPointerGet
   08B0 E0                 3722 	movx	a,@dptr
   08B1 FA                 3723 	mov	r2,a
                           3724 ;	genPointerSet
                           3725 ;	genNearPointerSet
                           3726 ;	genDataPointerSet
   08B2 8A 37              3727 	mov	(_SupplementalTiming_temp_1_1 + 0x0001),r2
                    07D6   3728 	C$TSIPMon.c$844$3$4 ==.
                           3729 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:844: temp.b.llo = RxBuf[val+3];
                           3730 ;	genPlus
                           3731 ;     genPlusIncr
   08B4 74 03              3732 	mov	a,#0x03
                           3733 ;	Peephole 236.a	used r7 instead of ar7
   08B6 2F                 3734 	add	a,r7
   08B7 FF                 3735 	mov	r7,a
                           3736 ;	Peephole 181	changed mov to clr
   08B8 E4                 3737 	clr	a
                           3738 ;	Peephole 236.b	used r5 instead of ar5
   08B9 3D                 3739 	addc	a,r5
   08BA FD                 3740 	mov	r5,a
                           3741 ;	genPlus
                           3742 ;	Peephole 236.g	used r7 instead of ar7
   08BB EF                 3743 	mov	a,r7
   08BC 25 34              3744 	add	a,_SupplementalTiming_RxBuf_1_1
   08BE F5 82              3745 	mov	dpl,a
                           3746 ;	Peephole 236.g	used r5 instead of ar5
   08C0 ED                 3747 	mov	a,r5
   08C1 35 35              3748 	addc	a,(_SupplementalTiming_RxBuf_1_1 + 1)
   08C3 F5 83              3749 	mov	dph,a
                           3750 ;	genPointerGet
                           3751 ;	genFarPointerGet
   08C5 E0                 3752 	movx	a,@dptr
   08C6 FA                 3753 	mov	r2,a
                           3754 ;	genPointerSet
                           3755 ;	genNearPointerSet
                           3756 ;	genDataPointerSet
   08C7 8A 36              3757 	mov	_SupplementalTiming_temp_1_1,r2
                    07EB   3758 	C$TSIPMon.c$846$3$4 ==.
                           3759 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:846: val = temp.f;
                           3760 ;	genAssign
                           3761 ;	genCall
   08C9 85 36 82           3762 	mov	dpl,_SupplementalTiming_temp_1_1
   08CC 85 37 83           3763 	mov	dph,(_SupplementalTiming_temp_1_1 + 1)
   08CF 85 38 F0           3764 	mov	b,(_SupplementalTiming_temp_1_1 + 2)
   08D2 E5 39              3765 	mov	a,(_SupplementalTiming_temp_1_1 + 3)
   08D4 12 11 6A           3766 	lcall	___fs2uchar
   08D7 85 82 3A           3767 	mov	_SupplementalTiming_val_1_1,dpl
                    07FC   3768 	C$TSIPMon.c$847$3$4 ==.
                           3769 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:847: fval = ((temp.f - val) * fval);
                           3770 ;	genPointerGet
                           3771 ;	genNearPointerGet
                           3772 ;	genDataPointerGet
   08DA 85 36 3D           3773 	mov	_SupplementalTiming_sloc1_1_0,_SupplementalTiming_temp_1_1
   08DD 85 37 3E           3774 	mov	(_SupplementalTiming_sloc1_1_0 + 1),(_SupplementalTiming_temp_1_1 + 1)
   08E0 85 38 3F           3775 	mov	(_SupplementalTiming_sloc1_1_0 + 2),(_SupplementalTiming_temp_1_1 + 2)
   08E3 85 39 40           3776 	mov	(_SupplementalTiming_sloc1_1_0 + 3),(_SupplementalTiming_temp_1_1 + 3)
                           3777 ;	genCast
   08E6 AF 3A              3778 	mov	r7,_SupplementalTiming_val_1_1
   08E8 7C 00              3779 	mov	r4,#0x00
                           3780 ;	genCall
   08EA 8F 82              3781 	mov	dpl,r7
   08EC 8C 83              3782 	mov	dph,r4
   08EE 12 10 C1           3783 	lcall	___sint2fs
   08F1 AC 82              3784 	mov	r4,dpl
   08F3 AF 83              3785 	mov	r7,dph
   08F5 AA F0              3786 	mov	r2,b
   08F7 FB                 3787 	mov	r3,a
                           3788 ;	genIpush
   08F8 C0 04              3789 	push	ar4
   08FA C0 07              3790 	push	ar7
   08FC C0 02              3791 	push	ar2
   08FE C0 03              3792 	push	ar3
                           3793 ;	genCall
   0900 85 3D 82           3794 	mov	dpl,_SupplementalTiming_sloc1_1_0
   0903 85 3E 83           3795 	mov	dph,(_SupplementalTiming_sloc1_1_0 + 1)
   0906 85 3F F0           3796 	mov	b,(_SupplementalTiming_sloc1_1_0 + 2)
   0909 E5 40              3797 	mov	a,(_SupplementalTiming_sloc1_1_0 + 3)
   090B 12 0E C4           3798 	lcall	___fssub
   090E 85 82 3D           3799 	mov	_SupplementalTiming_sloc1_1_0,dpl
   0911 85 83 3E           3800 	mov	(_SupplementalTiming_sloc1_1_0 + 1),dph
   0914 85 F0 3F           3801 	mov	(_SupplementalTiming_sloc1_1_0 + 2),b
   0917 F5 40              3802 	mov	(_SupplementalTiming_sloc1_1_0 + 3),a
   0919 E5 81              3803 	mov	a,sp
   091B 24 FC              3804 	add	a,#0xfc
   091D F5 81              3805 	mov	sp,a
                           3806 ;	genCall
   091F 85 3B 82           3807 	mov	dpl,_SupplementalTiming_fval_1_1
   0922 85 3C 83           3808 	mov	dph,(_SupplementalTiming_fval_1_1 + 1)
   0925 12 10 CE           3809 	lcall	___uint2fs
   0928 AE 82              3810 	mov	r6,dpl
   092A AF 83              3811 	mov	r7,dph
   092C AA F0              3812 	mov	r2,b
   092E FB                 3813 	mov	r3,a
                           3814 ;	genIpush
   092F C0 06              3815 	push	ar6
   0931 C0 07              3816 	push	ar7
   0933 C0 02              3817 	push	ar2
   0935 C0 03              3818 	push	ar3
                           3819 ;	genCall
   0937 85 3D 82           3820 	mov	dpl,_SupplementalTiming_sloc1_1_0
   093A 85 3E 83           3821 	mov	dph,(_SupplementalTiming_sloc1_1_0 + 1)
   093D 85 3F F0           3822 	mov	b,(_SupplementalTiming_sloc1_1_0 + 2)
   0940 E5 40              3823 	mov	a,(_SupplementalTiming_sloc1_1_0 + 3)
   0942 12 0F 38           3824 	lcall	___fsmul
   0945 AA 82              3825 	mov	r2,dpl
   0947 AB 83              3826 	mov	r3,dph
   0949 AC F0              3827 	mov	r4,b
   094B FD                 3828 	mov	r5,a
   094C E5 81              3829 	mov	a,sp
   094E 24 FC              3830 	add	a,#0xfc
   0950 F5 81              3831 	mov	sp,a
                           3832 ;	genCall
   0952 8A 82              3833 	mov	dpl,r2
   0954 8B 83              3834 	mov	dph,r3
   0956 8C F0              3835 	mov	b,r4
   0958 ED                 3836 	mov	a,r5
   0959 12 10 DA           3837 	lcall	___fs2uint
   095C 85 82 3B           3838 	mov	_SupplementalTiming_fval_1_1,dpl
   095F 85 83 3C           3839 	mov	(_SupplementalTiming_fval_1_1 + 1),dph
                    0884   3840 	C$TSIPMon.c$853$3$4 ==.
                           3841 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:853: strcpy( lcdbuf, prompt[mode-4] );
                           3842 ;	genMinus
                           3843 ;	genMinusDec
   0962 E5 33              3844 	mov	a,_SupplementalTiming_mode_1_1
   0964 24 FC              3845 	add	a,#0xfc
                           3846 ;	genMult
                           3847 ;	genMultOneByte
   0966 75 F0 09           3848 	mov	b,#0x09
   0969 A4                 3849 	mul	ab
                           3850 ;	genPlus
   096A 24 32              3851 	add	a,#_prompt
   096C FA                 3852 	mov	r2,a
                           3853 ;	Peephole 240	use clr instead of addc a,#0
   096D E4                 3854 	clr	a
   096E 34 15              3855 	addc	a,#(_prompt >> 8)
   0970 FB                 3856 	mov	r3,a
                           3857 ;	genCast
   0971 8A 41              3858 	mov	_strcpy_PARM_2,r2
   0973 8B 42              3859 	mov	(_strcpy_PARM_2 + 1),r3
   0975 75 43 80           3860 	mov	(_strcpy_PARM_2 + 2),#0x80
                           3861 ;	genCall
                           3862 ;	Peephole 182.a	used 16 bit load of DPTR
   0978 90 00 02           3863 	mov	dptr,#_lcdbuf
   097B 75 F0 00           3864 	mov	b,#0x00
   097E 12 0E F8           3865 	lcall	_strcpy
                    08A3   3866 	C$TSIPMon.c$854$3$4 ==.
                           3867 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:854: UnsignedToAscii( val, lcdbuf+6, 3 );
                           3868 ;	genCast
   0981 AC 3A              3869 	mov	r4,_SupplementalTiming_val_1_1
   0983 7A 00              3870 	mov	r2,#0x00
                           3871 ;	genPlus
                           3872 ;     genPlusIncr
   0985 74 06              3873 	mov	a,#0x06
   0987 24 02              3874 	add	a,#_lcdbuf
   0989 F5 1B              3875 	mov	_UnsignedToAscii_PARM_2,a
                           3876 ;	Peephole 181	changed mov to clr
   098B E4                 3877 	clr	a
   098C 34 00              3878 	addc	a,#(_lcdbuf >> 8)
   098E F5 1C              3879 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           3880 ;	genAssign
   0990 75 1D 03           3881 	mov	_UnsignedToAscii_PARM_3,#0x03
                           3882 ;	genCall
   0993 8C 82              3883 	mov	dpl,r4
   0995 8A 83              3884 	mov	dph,r2
   0997 12 0D 3E           3885 	lcall	_UnsignedToAscii
                    08BC   3886 	C$TSIPMon.c$855$3$4 ==.
                           3887 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:855: lcdbuf[9] = '.';
                           3888 ;	genPointerSet
                           3889 ;     genFarPointerSet
   099A 90 00 0B           3890 	mov	dptr,#(_lcdbuf + 0x0009)
   099D 74 2E              3891 	mov	a,#0x2E
   099F F0                 3892 	movx	@dptr,a
                    08C2   3893 	C$TSIPMon.c$856$3$4 ==.
                           3894 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:856: UnsignedToAscii( fval, lcdbuf+10, 2 + 2*(mode-4) );
                           3895 ;	genPlus
                           3896 ;     genPlusIncr
   09A0 74 0A              3897 	mov	a,#0x0A
   09A2 24 02              3898 	add	a,#_lcdbuf
   09A4 F5 1B              3899 	mov	_UnsignedToAscii_PARM_2,a
                           3900 ;	Peephole 181	changed mov to clr
   09A6 E4                 3901 	clr	a
   09A7 34 00              3902 	addc	a,#(_lcdbuf >> 8)
   09A9 F5 1C              3903 	mov	(_UnsignedToAscii_PARM_2 + 1),a
                           3904 ;	genMinus
                           3905 ;	genMinusDec
   09AB E5 33              3906 	mov	a,_SupplementalTiming_mode_1_1
   09AD 24 FC              3907 	add	a,#0xfc
                           3908 ;	genLeftShift
                           3909 ;	genLeftShiftLiteral
                           3910 ;	genlshOne
                           3911 ;	Peephole 105	removed redundant mov
                           3912 ;	Peephole 204	removed redundant mov
   09AF 25 E0              3913 	add	a,acc
                           3914 ;	genPlus
                           3915 ;     genPlusIncr
                           3916 ;	Peephole 236.a	used r2 instead of ar2
   09B1 FA                 3917 	mov	r2,a
                           3918 ;	Peephole 214	reduced some extra moves
   09B2 24 02              3919 	add	a,#0x02
   09B4 F5 1D              3920 	mov	_UnsignedToAscii_PARM_3,a
                           3921 ;	genCall
   09B6 85 3B 82           3922 	mov	dpl,_SupplementalTiming_fval_1_1
   09B9 85 3C 83           3923 	mov	dph,(_SupplementalTiming_fval_1_1 + 1)
   09BC 12 0D 3E           3924 	lcall	_UnsignedToAscii
                    08E1   3925 	C$TSIPMon.c$858$2$1 ==.
                           3926 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:858: for( val=0; val<3; val++ ){
                           3927 ;	genAssign
   09BF 7A 00              3928 	mov	r2,#0x00
   09C1                    3929 00121$:
                           3930 ;	genCmpLt
                           3931 ;	genCmp
   09C1 BA 03 00           3932 	cjne	r2,#0x03,00154$
   09C4                    3933 00154$:
                           3934 ;	genIfxJump
                           3935 ;	Peephole 108.a	removed ljmp by inverse jump logic
   09C4 50 23              3936 	jnc	00125$
                           3937 ;	Peephole 300	removed redundant label 00155$
                    08E8   3938 	C$TSIPMon.c$859$4$5 ==.
                           3939 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:859: if( lcdbuf[10+val] == ' ' ) 
                           3940 ;	genPlus
                           3941 ;     genPlusIncr
   09C6 74 0A              3942 	mov	a,#0x0A
                           3943 ;	Peephole 236.a	used r2 instead of ar2
   09C8 2A                 3944 	add	a,r2
                           3945 ;	genPlus
   09C9 24 02              3946 	add	a,#_lcdbuf
   09CB F5 82              3947 	mov	dpl,a
                           3948 ;	Peephole 240	use clr instead of addc a,#0
   09CD E4                 3949 	clr	a
   09CE 34 00              3950 	addc	a,#(_lcdbuf >> 8)
   09D0 F5 83              3951 	mov	dph,a
                           3952 ;	genPointerGet
                           3953 ;	genFarPointerGet
   09D2 E0                 3954 	movx	a,@dptr
   09D3 FB                 3955 	mov	r3,a
                           3956 ;	genCmpEq
                           3957 ;	gencjneshort
                           3958 ;	Peephole 112.b	changed ljmp to sjmp
                           3959 ;	Peephole 198.b	optimized misc jump sequence
   09D4 BB 20 12           3960 	cjne	r3,#0x20,00125$
                           3961 ;	Peephole 200.b	removed redundant sjmp
                           3962 ;	Peephole 300	removed redundant label 00156$
                           3963 ;	Peephole 300	removed redundant label 00157$
                    08F9   3964 	C$TSIPMon.c$860$4$5 ==.
                           3965 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:860: lcdbuf[10+val] = '0';
                           3966 ;	genPlus
                           3967 ;     genPlusIncr
   09D7 74 0A              3968 	mov	a,#0x0A
                           3969 ;	Peephole 236.a	used r2 instead of ar2
   09D9 2A                 3970 	add	a,r2
                           3971 ;	genPlus
   09DA 24 02              3972 	add	a,#_lcdbuf
   09DC F5 82              3973 	mov	dpl,a
                           3974 ;	Peephole 240	use clr instead of addc a,#0
   09DE E4                 3975 	clr	a
   09DF 34 00              3976 	addc	a,#(_lcdbuf >> 8)
   09E1 F5 83              3977 	mov	dph,a
                           3978 ;	genPointerSet
                           3979 ;     genFarPointerSet
   09E3 74 30              3980 	mov	a,#0x30
   09E5 F0                 3981 	movx	@dptr,a
                    0908   3982 	C$TSIPMon.c$858$3$4 ==.
                           3983 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:858: for( val=0; val<3; val++ ){
                           3984 ;	genPlus
                           3985 ;     genPlusIncr
   09E6 0A                 3986 	inc	r2
                    0909   3987 	C$TSIPMon.c$866$2$3 ==.
                           3988 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:866: } // switch( mode )
                           3989 ;	Peephole 112.b	changed ljmp to sjmp
   09E7 80 D8              3990 	sjmp	00121$
   09E9                    3991 00125$:
                    090B   3992 	C$TSIPMon.c$867$2$3 ==.
                           3993 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:867: printLCD( 2, lcdbuf, 0 );
                           3994 ;	genAddrOf
   09E9 75 08 02           3995 	mov	_printLCD_PARM_2,#_lcdbuf
   09EC 75 09 00           3996 	mov	(_printLCD_PARM_2 + 1),#(_lcdbuf >> 8)
                           3997 ;	genAssign
   09EF 75 0A 00           3998 	mov	_printLCD_PARM_3,#0x00
                           3999 ;	genCall
   09F2 75 82 02           4000 	mov	dpl,#0x02
                    0917   4001 	C$TSIPMon.c$870$2$1 ==.
                    0917   4002 	XG$SupplementalTiming$0$0 ==.
                           4003 ;	Peephole 253.b	replaced lcall/ret with ljmp
   09F5 02 0B 57           4004 	ljmp	_printLCD
                           4005 ;
                           4006 ;------------------------------------------------------------
                           4007 ;Allocation info for local variables in function 'External_Interrupt_0'
                           4008 ;------------------------------------------------------------
                           4009 ;------------------------------------------------------------
                    091A   4010 	G$External_Interrupt_0$0$0 ==.
                    091A   4011 	C$TSIPMon.c$876$2$1 ==.
                           4012 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:876: void External_Interrupt_0( void ) interrupt 0{
                           4013 ;	-----------------------------------------
                           4014 ;	 function External_Interrupt_0
                           4015 ;	-----------------------------------------
   09F8                    4016 _External_Interrupt_0:
   09F8 C0 E0              4017 	push	acc
   09FA C0 F0              4018 	push	b
   09FC C0 82              4019 	push	dpl
   09FE C0 83              4020 	push	dph
   0A00 C0 02              4021 	push	(0+2)
   0A02 C0 03              4022 	push	(0+3)
   0A04 C0 04              4023 	push	(0+4)
   0A06 C0 05              4024 	push	(0+5)
   0A08 C0 06              4025 	push	(0+6)
   0A0A C0 07              4026 	push	(0+7)
   0A0C C0 00              4027 	push	(0+0)
   0A0E C0 01              4028 	push	(0+1)
   0A10 C0 D0              4029 	push	psw
   0A12 75 D0 00           4030 	mov	psw,#0x00
                           4031 ;	genIfx
                           4032 ;	genIfxJump
                           4033 ;	Peephole 108.d	removed ljmp by inverse jump logic
                    0937   4034 	C$TSIPMon.c$881$2$2 ==.
                           4035 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:881: switch2 = 0;
                           4036 ;	genAssign
                           4037 ;	Peephole 250.a	using atomic test and clear
   0A15 10 02 02           4038 	jbc	_switch2,00106$
   0A18 80 13              4039 	sjmp	00103$
   0A1A                    4040 00106$:
                    093C   4041 	C$TSIPMon.c$882$2$2 ==.
                           4042 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:882: func2 = !LED2;
                           4043 ;	genNot
   0A1A A2 87              4044 	mov	c,_P0_7
   0A1C B3                 4045 	cpl	c
                    093F   4046 	C$TSIPMon.c$883$2$2 ==.
                           4047 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:883: LED2 = func2;
                           4048 ;	genAssign
   0A1D 92 04              4049 	mov  _func2,c
                           4050 ;	Peephole 177.a	removed redundant mov
   0A1F 92 87              4051 	mov	_P0_7,c
                    0943   4052 	C$TSIPMon.c$884$2$2 ==.
                           4053 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:884: TimerStart( SWITCH_TIMER, 50 );	// to reset switch2 to 1
                           4054 ;	genAssign
   0A21 75 0E 32           4055 	mov	_TimerStart_PARM_2,#0x32
   0A24 E4                 4056 	clr	a
   0A25 F5 0F              4057 	mov	(_TimerStart_PARM_2 + 1),a
                           4058 ;	genCall
   0A27 75 82 02           4059 	mov	dpl,#0x02
   0A2A 12 02 BC           4060 	lcall	_TimerStart
   0A2D                    4061 00103$:
   0A2D D0 D0              4062 	pop	psw
   0A2F D0 01              4063 	pop	(0+1)
   0A31 D0 00              4064 	pop	(0+0)
   0A33 D0 07              4065 	pop	(0+7)
   0A35 D0 06              4066 	pop	(0+6)
   0A37 D0 05              4067 	pop	(0+5)
   0A39 D0 04              4068 	pop	(0+4)
   0A3B D0 03              4069 	pop	(0+3)
   0A3D D0 02              4070 	pop	(0+2)
   0A3F D0 83              4071 	pop	dph
   0A41 D0 82              4072 	pop	dpl
   0A43 D0 F0              4073 	pop	b
   0A45 D0 E0              4074 	pop	acc
                    0969   4075 	C$TSIPMon.c$887$2$1 ==.
                    0969   4076 	XG$External_Interrupt_0$0$0 ==.
   0A47 32                 4077 	reti
                           4078 ;------------------------------------------------------------
                           4079 ;Allocation info for local variables in function 'External_Interrupt_1'
                           4080 ;------------------------------------------------------------
                           4081 ;------------------------------------------------------------
                    096A   4082 	G$External_Interrupt_1$0$0 ==.
                    096A   4083 	C$TSIPMon.c$893$2$1 ==.
                           4084 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:893: void External_Interrupt_1( void ) interrupt 2{
                           4085 ;	-----------------------------------------
                           4086 ;	 function External_Interrupt_1
                           4087 ;	-----------------------------------------
   0A48                    4088 _External_Interrupt_1:
   0A48 C0 E0              4089 	push	acc
   0A4A C0 F0              4090 	push	b
   0A4C C0 82              4091 	push	dpl
   0A4E C0 83              4092 	push	dph
   0A50 C0 02              4093 	push	(0+2)
   0A52 C0 03              4094 	push	(0+3)
   0A54 C0 04              4095 	push	(0+4)
   0A56 C0 05              4096 	push	(0+5)
   0A58 C0 06              4097 	push	(0+6)
   0A5A C0 07              4098 	push	(0+7)
   0A5C C0 00              4099 	push	(0+0)
   0A5E C0 01              4100 	push	(0+1)
   0A60 C0 D0              4101 	push	psw
   0A62 75 D0 00           4102 	mov	psw,#0x00
                           4103 ;	genIfx
                           4104 ;	genIfxJump
                           4105 ;	Peephole 108.d	removed ljmp by inverse jump logic
   0A65 30 03 18           4106 	jnb	_switch1,00104$
                           4107 ;	Peephole 300	removed redundant label 00108$
                    098A   4108 	C$TSIPMon.c$896$1$1 ==.
                           4109 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:896: if( switch1 != 0 && !TimerRunning( SWITCH_TIMER )){
                           4110 ;	genCall
   0A68 75 82 02           4111 	mov	dpl,#0x02
   0A6B 12 02 D9           4112 	lcall	_TimerRunning
                           4113 ;	genIfx
                           4114 ;	genIfxJump
                           4115 ;	Peephole 108.b	removed ljmp by inverse jump logic
                           4116 ;	Peephole 129.a	jump optimization
   0A6E 40 10              4117 	jc	00104$
                           4118 ;	Peephole 300	removed redundant label 00109$
                    0992   4119 	C$TSIPMon.c$898$2$2 ==.
                           4120 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:898: switch1 = 0;
                           4121 ;	genAssign
   0A70 C2 03              4122 	clr	_switch1
                    0994   4123 	C$TSIPMon.c$899$2$2 ==.
                           4124 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:899: func1 = TRUE;
                           4125 ;	genAssign
   0A72 D2 05              4126 	setb	_func1
                    0996   4127 	C$TSIPMon.c$904$2$2 ==.
                           4128 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:904: TimerStart( SWITCH_TIMER, 150 );	// to reset switch1 to 1
                           4129 ;	genAssign
   0A74 75 0E 96           4130 	mov	_TimerStart_PARM_2,#0x96
   0A77 E4                 4131 	clr	a
   0A78 F5 0F              4132 	mov	(_TimerStart_PARM_2 + 1),a
                           4133 ;	genCall
   0A7A 75 82 02           4134 	mov	dpl,#0x02
   0A7D 12 02 BC           4135 	lcall	_TimerStart
   0A80                    4136 00104$:
   0A80 D0 D0              4137 	pop	psw
   0A82 D0 01              4138 	pop	(0+1)
   0A84 D0 00              4139 	pop	(0+0)
   0A86 D0 07              4140 	pop	(0+7)
   0A88 D0 06              4141 	pop	(0+6)
   0A8A D0 05              4142 	pop	(0+5)
   0A8C D0 04              4143 	pop	(0+4)
   0A8E D0 03              4144 	pop	(0+3)
   0A90 D0 02              4145 	pop	(0+2)
   0A92 D0 83              4146 	pop	dph
   0A94 D0 82              4147 	pop	dpl
   0A96 D0 F0              4148 	pop	b
   0A98 D0 E0              4149 	pop	acc
                    09BC   4150 	C$TSIPMon.c$907$2$1 ==.
                    09BC   4151 	XG$External_Interrupt_1$0$0 ==.
   0A9A 32                 4152 	reti
                           4153 ;------------------------------------------------------------
                           4154 ;Allocation info for local variables in function 'Timer_1_Overflow'
                           4155 ;------------------------------------------------------------
                           4156 ;------------------------------------------------------------
                    09BD   4157 	G$Timer_1_Overflow$0$0 ==.
                    09BD   4158 	C$TSIPMon.c$915$2$1 ==.
                           4159 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:915: void Timer_1_Overflow( void ) interrupt 3{}
                           4160 ;	-----------------------------------------
                           4161 ;	 function Timer_1_Overflow
                           4162 ;	-----------------------------------------
   0A9B                    4163 _Timer_1_Overflow:
                           4164 ;	Peephole 300	removed redundant label 00101$
                    09BD   4165 	C$TSIPMon.c$915$2$1 ==.
                    09BD   4166 	XG$Timer_1_Overflow$0$0 ==.
   0A9B 32                 4167 	reti
                           4168 ;	eliminated unneeded push/pop psw
                           4169 ;	eliminated unneeded push/pop dpl
                           4170 ;	eliminated unneeded push/pop dph
                           4171 ;	eliminated unneeded push/pop b
                           4172 ;	eliminated unneeded push/pop acc
                           4173 ;------------------------------------------------------------
                           4174 ;Allocation info for local variables in function 'SPI0'
                           4175 ;------------------------------------------------------------
                           4176 ;------------------------------------------------------------
                    09BE   4177 	G$SPI0$0$0 ==.
                    09BE   4178 	C$TSIPMon.c$918$2$1 ==.
                           4179 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:918: void SPI0( void ) interrupt 6{}
                           4180 ;	-----------------------------------------
                           4181 ;	 function SPI0
                           4182 ;	-----------------------------------------
   0A9C                    4183 _SPI0:
                           4184 ;	Peephole 300	removed redundant label 00101$
                    09BE   4185 	C$TSIPMon.c$918$2$1 ==.
                    09BE   4186 	XG$SPI0$0$0 ==.
   0A9C 32                 4187 	reti
                           4188 ;	eliminated unneeded push/pop psw
                           4189 ;	eliminated unneeded push/pop dpl
                           4190 ;	eliminated unneeded push/pop dph
                           4191 ;	eliminated unneeded push/pop b
                           4192 ;	eliminated unneeded push/pop acc
                           4193 ;------------------------------------------------------------
                           4194 ;Allocation info for local variables in function 'SMB0'
                           4195 ;------------------------------------------------------------
                           4196 ;------------------------------------------------------------
                    09BF   4197 	G$SMB0$0$0 ==.
                    09BF   4198 	C$TSIPMon.c$919$2$1 ==.
                           4199 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:919: void SMB0( void ) interrupt 7{}
                           4200 ;	-----------------------------------------
                           4201 ;	 function SMB0
                           4202 ;	-----------------------------------------
   0A9D                    4203 _SMB0:
                           4204 ;	Peephole 300	removed redundant label 00101$
                    09BF   4205 	C$TSIPMon.c$919$2$1 ==.
                    09BF   4206 	XG$SMB0$0$0 ==.
   0A9D 32                 4207 	reti
                           4208 ;	eliminated unneeded push/pop psw
                           4209 ;	eliminated unneeded push/pop dpl
                           4210 ;	eliminated unneeded push/pop dph
                           4211 ;	eliminated unneeded push/pop b
                           4212 ;	eliminated unneeded push/pop acc
                           4213 ;------------------------------------------------------------
                           4214 ;Allocation info for local variables in function 'ADC0_Window_Comparator'
                           4215 ;------------------------------------------------------------
                           4216 ;------------------------------------------------------------
                    09C0   4217 	G$ADC0_Window_Comparator$0$0 ==.
                    09C0   4218 	C$TSIPMon.c$921$2$1 ==.
                           4219 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:921: void ADC0_Window_Comparator( void ) interrupt 9{}
                           4220 ;	-----------------------------------------
                           4221 ;	 function ADC0_Window_Comparator
                           4222 ;	-----------------------------------------
   0A9E                    4223 _ADC0_Window_Comparator:
                           4224 ;	Peephole 300	removed redundant label 00101$
                    09C0   4225 	C$TSIPMon.c$921$2$1 ==.
                    09C0   4226 	XG$ADC0_Window_Comparator$0$0 ==.
   0A9E 32                 4227 	reti
                           4228 ;	eliminated unneeded push/pop psw
                           4229 ;	eliminated unneeded push/pop dpl
                           4230 ;	eliminated unneeded push/pop dph
                           4231 ;	eliminated unneeded push/pop b
                           4232 ;	eliminated unneeded push/pop acc
                           4233 ;------------------------------------------------------------
                           4234 ;Allocation info for local variables in function 'ADC0_End_of_Conversion'
                           4235 ;------------------------------------------------------------
                           4236 ;------------------------------------------------------------
                    09C1   4237 	G$ADC0_End_of_Conversion$0$0 ==.
                    09C1   4238 	C$TSIPMon.c$922$2$1 ==.
                           4239 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:922: void ADC0_End_of_Conversion( void ) interrupt 10{}
                           4240 ;	-----------------------------------------
                           4241 ;	 function ADC0_End_of_Conversion
                           4242 ;	-----------------------------------------
   0A9F                    4243 _ADC0_End_of_Conversion:
                           4244 ;	Peephole 300	removed redundant label 00101$
                    09C1   4245 	C$TSIPMon.c$922$2$1 ==.
                    09C1   4246 	XG$ADC0_End_of_Conversion$0$0 ==.
   0A9F 32                 4247 	reti
                           4248 ;	eliminated unneeded push/pop psw
                           4249 ;	eliminated unneeded push/pop dpl
                           4250 ;	eliminated unneeded push/pop dph
                           4251 ;	eliminated unneeded push/pop b
                           4252 ;	eliminated unneeded push/pop acc
                           4253 ;------------------------------------------------------------
                           4254 ;Allocation info for local variables in function 'Programmable_Counter_Array'
                           4255 ;------------------------------------------------------------
                           4256 ;------------------------------------------------------------
                    09C2   4257 	G$Programmable_Counter_Array$0$0 ==.
                    09C2   4258 	C$TSIPMon.c$923$2$1 ==.
                           4259 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:923: void Programmable_Counter_Array( void ) interrupt 11{}
                           4260 ;	-----------------------------------------
                           4261 ;	 function Programmable_Counter_Array
                           4262 ;	-----------------------------------------
   0AA0                    4263 _Programmable_Counter_Array:
                           4264 ;	Peephole 300	removed redundant label 00101$
                    09C2   4265 	C$TSIPMon.c$923$2$1 ==.
                    09C2   4266 	XG$Programmable_Counter_Array$0$0 ==.
   0AA0 32                 4267 	reti
                           4268 ;	eliminated unneeded push/pop psw
                           4269 ;	eliminated unneeded push/pop dpl
                           4270 ;	eliminated unneeded push/pop dph
                           4271 ;	eliminated unneeded push/pop b
                           4272 ;	eliminated unneeded push/pop acc
                           4273 ;------------------------------------------------------------
                           4274 ;Allocation info for local variables in function 'Comparator'
                           4275 ;------------------------------------------------------------
                           4276 ;------------------------------------------------------------
                    09C3   4277 	G$Comparator$0$0 ==.
                    09C3   4278 	C$TSIPMon.c$924$2$1 ==.
                           4279 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:924: void Comparator( void ) interrupt 12{}
                           4280 ;	-----------------------------------------
                           4281 ;	 function Comparator
                           4282 ;	-----------------------------------------
   0AA1                    4283 _Comparator:
                           4284 ;	Peephole 300	removed redundant label 00101$
                    09C3   4285 	C$TSIPMon.c$924$2$1 ==.
                    09C3   4286 	XG$Comparator$0$0 ==.
   0AA1 32                 4287 	reti
                           4288 ;	eliminated unneeded push/pop psw
                           4289 ;	eliminated unneeded push/pop dpl
                           4290 ;	eliminated unneeded push/pop dph
                           4291 ;	eliminated unneeded push/pop b
                           4292 ;	eliminated unneeded push/pop acc
                           4293 ;------------------------------------------------------------
                           4294 ;Allocation info for local variables in function 'Timer_3_Overflow'
                           4295 ;------------------------------------------------------------
                           4296 ;------------------------------------------------------------
                    09C4   4297 	G$Timer_3_Overflow$0$0 ==.
                    09C4   4298 	C$TSIPMon.c$926$2$1 ==.
                           4299 ;	C:/SDCC/GPSMon/dev/TSIPMon.c:926: void Timer_3_Overflow( void ) interrupt 14{}
                           4300 ;	-----------------------------------------
                           4301 ;	 function Timer_3_Overflow
                           4302 ;	-----------------------------------------
   0AA2                    4303 _Timer_3_Overflow:
                           4304 ;	Peephole 300	removed redundant label 00101$
                    09C4   4305 	C$TSIPMon.c$926$2$1 ==.
                    09C4   4306 	XG$Timer_3_Overflow$0$0 ==.
   0AA2 32                 4307 	reti
                           4308 ;	eliminated unneeded push/pop psw
                           4309 ;	eliminated unneeded push/pop dpl
                           4310 ;	eliminated unneeded push/pop dph
                           4311 ;	eliminated unneeded push/pop b
                           4312 ;	eliminated unneeded push/pop acc
                           4313 	.area CSEG    (CODE)
                           4314 	.area CONST   (CODE)
                    0000   4315 G$Month$0$0 == .
   1232                    4316 _Month:
   1232 4A 61 6E 46 65 62  4317 	.ascii "JanFebMarAprMayJunJulAugSepOctNovDec"
        4D 61 72 41 70 72
        4D 61 79 4A 75 6E
        4A 75 6C 41 75 67
        53 65 70 4F 63 74
        4E 6F 76 44 65 63
   1256 00                 4318 	.db 0x00
                    0025   4319 G$RxMode$0$0 == .
   1257                    4320 _RxMode:
   1257 52 58 3A 20 41 75  4321 	.ascii "RX: Auto 2D/3D"
        74 6F 20 32 44 2F
        33 44
   1265 00                 4322 	.db 0x00
   1266 00                 4323 	.db 0x00
   1267 00                 4324 	.db 0x00
   1268 52 58 3A 20 53 69  4325 	.ascii "RX: Single Sat"
        6E 67 6C 65 20 53
        61 74
   1276 00                 4326 	.db 0x00
   1277 00                 4327 	.db 0x00
   1278 00                 4328 	.db 0x00
   1279 52 58 3A 20 55 6E  4329 	.ascii "RX: Unknown!!!"
        6B 6E 6F 77 6E 21
        21 21
   1287 00                 4330 	.db 0x00
   1288 00                 4331 	.db 0x00
   1289 00                 4332 	.db 0x00
   128A 52 58 3A 20 48 6F  4333 	.ascii "RX: Horiz. (2D)"
        72 69 7A 2E 20 28
        32 44 29
   1299 00                 4334 	.db 0x00
   129A 00                 4335 	.db 0x00
   129B 52 58 3A 20 46 75  4336 	.ascii "RX: Full Pos(3D)"
        6C 6C 20 50 6F 73
        28 33 44 29
   12AB 00                 4337 	.db 0x00
   12AC 52 58 3A 20 44 47  4338 	.ascii "RX: DGPS Refer"
        50 53 20 52 65 66
        65 72
   12BA 00                 4339 	.db 0x00
   12BB 00                 4340 	.db 0x00
   12BC 00                 4341 	.db 0x00
   12BD 52 58 3A 20 43 6C  4342 	.ascii "RX: Clk Hold(2D)"
        6B 20 48 6F 6C 64
        28 32 44 29
   12CD 00                 4343 	.db 0x00
   12CE 52 58 3A 20 4F 76  4344 	.ascii "RX: Overdet Clk"
        65 72 64 65 74 20
        43 6C 6B
   12DD 00                 4345 	.db 0x00
   12DE 00                 4346 	.db 0x00
                    00AD   4347 G$DiscMode$0$0 == .
   12DF                    4348 _DiscMode:
   12DF 4D 4F 44 45 3A 20  4349 	.ascii "MODE: Normal"
        4E 6F 72 6D 61 6C
   12EB 00                 4350 	.db 0x00
   12EC 00                 4351 	.db 0x00
   12ED 00                 4352 	.db 0x00
   12EE 00                 4353 	.db 0x00
   12EF 0C                 4354 	.db 0x0C
   12F0 4D 4F 44 45 3A 20  4355 	.ascii "MODE: Power-Up"
        50 6F 77 65 72 2D
        55 70
   12FE 00                 4356 	.db 0x00
   12FF 00                 4357 	.db 0x00
   1300 00                 4358 	.db 0x00
   1301 4D 4F 44 45 3A 20  4359 	.ascii "MODE: Auto Hldvr"
        41 75 74 6F 20 48
        6C 64 76 72
   1311 00                 4360 	.db 0x00
   1312 4D 4F 44 45 3A 20  4361 	.ascii "MODE: Man. Hldvr"
        4D 61 6E 2E 20 48
        6C 64 76 72
   1322 00                 4362 	.db 0x00
   1323 4D 4F 44 45 3A 20  4363 	.ascii "MODE: Recovery"
        52 65 63 6F 76 65
        72 79
   1331 00                 4364 	.db 0x00
   1332 00                 4365 	.db 0x00
   1333 00                 4366 	.db 0x00
   1334 4D 4F 44 45 3A 20  4367 	.ascii "MODE: Unknown!!!"
        55 6E 6B 6E 6F 77
        6E 21 21 21
   1344 00                 4368 	.db 0x00
   1345 4D 4F 44 45 3A 20  4369 	.ascii "MODE: Disabled"
        44 69 73 61 62 6C
        65 64
   1353 00                 4370 	.db 0x00
   1354 00                 4371 	.db 0x00
   1355 00                 4372 	.db 0x00
                    0124   4373 G$GPSDecodeStatus$0$0 == .
   1356                    4374 _GPSDecodeStatus:
   1356 47 50 53 3A 20 44  4375 	.ascii "GPS: Doing Fixes"
        6F 69 6E 67 20 46
        69 78 65 73
   1366 00                 4376 	.db 0x00
   1367 47 50 53 3A 20 4E  4377 	.ascii "GPS: No GPS Time"
        6F 20 47 50 53 20
        54 69 6D 65
   1377 00                 4378 	.db 0x00
   1378 47 50 53 3A 20 55  4379 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   1387 00                 4380 	.db 0x00
   1388 00                 4381 	.db 0x00
   1389 47 50 53 3A 20 50  4382 	.ascii "GPS: PDOP to HI"
        44 4F 50 20 74 6F
        20 48 49
   1398 00                 4383 	.db 0x00
   1399 00                 4384 	.db 0x00
   139A 47 50 53 3A 20 55  4385 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   13A9 00                 4386 	.db 0x00
   13AA 00                 4387 	.db 0x00
   13AB 47 50 53 3A 20 55  4388 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   13BA 00                 4389 	.db 0x00
   13BB 00                 4390 	.db 0x00
   13BC 47 50 53 3A 20 55  4391 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   13CB 00                 4392 	.db 0x00
   13CC 00                 4393 	.db 0x00
   13CD 47 50 53 3A 20 55  4394 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   13DC 00                 4395 	.db 0x00
   13DD 00                 4396 	.db 0x00
   13DE 47 50 53 3A 20 4E  4397 	.ascii "GPS: No Use SATS"
        6F 20 55 73 65 20
        53 41 54 53
   13EE 00                 4398 	.db 0x00
   13EF 47 50 53 3A 20 4F  4399 	.ascii "GPS: Only 1 SAT"
        6E 6C 79 20 31 20
        53 41 54
   13FE 00                 4400 	.db 0x00
   13FF 00                 4401 	.db 0x00
   1400 47 50 53 3A 20 4F  4402 	.ascii "GPS: Only 2 SATS"
        6E 6C 79 20 32 20
        53 41 54 53
   1410 00                 4403 	.db 0x00
   1411 47 50 53 3A 20 4F  4404 	.ascii "GPS: Only 3 SATS"
        6E 6C 79 20 33 20
        53 41 54 53
   1421 00                 4405 	.db 0x00
   1422 47 50 53 3A 20 53  4406 	.ascii "GPS: SAT Unusabl"
        41 54 20 55 6E 75
        73 61 62 6C
   1432 00                 4407 	.db 0x00
   1433 47 50 53 3A 20 55  4408 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   1442 00                 4409 	.db 0x00
   1443 00                 4410 	.db 0x00
   1444 47 50 53 3A 20 55  4411 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   1453 00                 4412 	.db 0x00
   1454 00                 4413 	.db 0x00
   1455 47 50 53 3A 20 55  4414 	.ascii "GPS: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   1464 00                 4415 	.db 0x00
   1465 00                 4416 	.db 0x00
   1466 47 50 53 3A 20 54  4417 	.ascii "GPS: TRIAM Rejec"
        52 49 41 4D 20 52
        65 6A 65 63
   1476 00                 4418 	.db 0x00
                    0245   4419 G$DiscActivity$0$0 == .
   1477                    4420 _DiscActivity:
   1477 41 43 54 3A 20 50  4421 	.ascii "ACT: Phase Lock"
        68 61 73 65 20 4C
        6F 63 6B
   1486 00                 4422 	.db 0x00
   1487 00                 4423 	.db 0x00
   1488 41 43 54 3A 20 4F  4424 	.ascii "ACT: Osc Warmup"
        73 63 20 57 61 72
        6D 75 70
   1497 00                 4425 	.db 0x00
   1498 00                 4426 	.db 0x00
   1499 41 43 54 3A 20 46  4427 	.ascii "ACT: Freq Lock"
        72 65 71 20 4C 6F
        63 6B
   14A7 00                 4428 	.db 0x00
   14A8 00                 4429 	.db 0x00
   14A9 00                 4430 	.db 0x00
   14AA 41 43 54 3A 20 50  4431 	.ascii "ACT: Placing PPS"
        6C 61 63 69 6E 67
        20 50 50 53
   14BA 00                 4432 	.db 0x00
   14BB 41 43 54 3A 20 49  4433 	.ascii "ACT: Init. loop"
        6E 69 74 2E 20 6C
        6F 6F 70
   14CA 00                 4434 	.db 0x00
   14CB 00                 4435 	.db 0x00
   14CC 41 43 54 3A 20 43  4436 	.ascii "ACT: Compensate"
        6F 6D 70 65 6E 73
        61 74 65
   14DB 00                 4437 	.db 0x00
   14DC 00                 4438 	.db 0x00
   14DD 41 43 54 3A 20 49  4439 	.ascii "ACT: Inactive"
        6E 61 63 74 69 76
        65
   14EA 00                 4440 	.db 0x00
   14EB 00                 4441 	.db 0x00
   14EC 00                 4442 	.db 0x00
   14ED 0C                 4443 	.db 0x0C
   14EE 41 43 54 3A 20 55  4444 	.ascii "ACT: Unknown!!!"
        6E 6B 6E 6F 77 6E
        21 21 21
   14FD 00                 4445 	.db 0x00
   14FE 00                 4446 	.db 0x00
   14FF 41 43 54 3A 20 52  4447 	.ascii "ACT: Recovery LP"
        65 63 6F 76 65 72
        79 20 4C 50
   150F 00                 4448 	.db 0x00
                    02DE   4449 G$VersionMsg$0$0 == .
   1510                    4450 _VersionMsg:
   1510 20 54 53 49 50 4D  4451 	.ascii " TSIPMon v0.2.2 "
        6F 6E 20 76 30 2E
        32 2E 32 20
   1520 00                 4452 	.db 0x00
                    02EF   4453 G$LCDInitMsg$0$0 == .
   1521                    4454 _LCDInitMsg:
   1521 20 77 77 77 2E 6B  4455 	.ascii " www.ko4bb.com  "
        6F 34 62 62 2E 63
        6F 6D 20 20
   1531 00                 4456 	.db 0x00
                    0300   4457 G$prompt$0$0 == .
   1532                    4458 _prompt:
   1532 54 45 4D 50 3A 20  4459 	.ascii "TEMP:  "
        20
   1539 00                 4460 	.db 0x00
   153A 00                 4461 	.db 0x00
   153B 44 41 43 20 56 3A  4462 	.ascii "DAC V: "
        20
   1542 00                 4463 	.db 0x00
   1543 00                 4464 	.db 0x00
                    0312   4465 FTSIPMon$_str_0$0$0 == .
   1544                    4466 __str_0:
   1544 57 61 69 74 69 6E  4467 	.ascii "Waiting for GPS"
        67 20 66 6F 72 20
        47 50 53
   1553 00                 4468 	.db 0x00
                    0322   4469 FTSIPMon$_str_1$0$0 == .
   1554                    4470 __str_1:
   1554 20 20 20 4E 6F 20  4471 	.ascii "   No Message   "
        4D 65 73 73 61 67
        65 20 20 20
   1564 00                 4472 	.db 0x00
                           4473 	.area XINIT   (CODE)
