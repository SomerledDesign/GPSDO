                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Jul 28 2006)
                              4 ; This file generated Sun Apr 08 20:34:08 2012
                              5 ;--------------------------------------------------------
                              6 	.module iconv
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _CharToAscii_PARM_3
                             13 	.globl _CharToAscii_PARM_2
                             14 	.globl _SPIF
                             15 	.globl _WCOL
                             16 	.globl _MODF
                             17 	.globl _RXOVRN
                             18 	.globl _NSSMD1
                             19 	.globl _NSSMD0
                             20 	.globl _TXBMT
                             21 	.globl _SPIEN
                             22 	.globl _AD0EN
                             23 	.globl _AD0TM
                             24 	.globl _AD0INT
                             25 	.globl _AD0BUSY
                             26 	.globl _AD0WINT
                             27 	.globl _AD0CM2
                             28 	.globl _AD0CM1
                             29 	.globl _AD0CM0
                             30 	.globl _CF
                             31 	.globl _CR
                             32 	.globl _CCF2
                             33 	.globl _CCF1
                             34 	.globl _CCF0
                             35 	.globl _CY
                             36 	.globl _AC
                             37 	.globl _F0
                             38 	.globl _RS1
                             39 	.globl _RS0
                             40 	.globl _OV
                             41 	.globl _F1
                             42 	.globl _PARITY
                             43 	.globl _TF2H
                             44 	.globl _TF2
                             45 	.globl _TF2L
                             46 	.globl _TF2LEN
                             47 	.globl _TF2CEN
                             48 	.globl _T2SPLIT
                             49 	.globl _TR2
                             50 	.globl _T2XCLK
                             51 	.globl _MASTER
                             52 	.globl _TXMODE
                             53 	.globl _STA
                             54 	.globl _STO
                             55 	.globl _ACKRQ
                             56 	.globl _ARBLOST
                             57 	.globl _ACK
                             58 	.globl _SI
                             59 	.globl _PSPI0
                             60 	.globl _PT2
                             61 	.globl _PS0
                             62 	.globl _PS
                             63 	.globl _PT1
                             64 	.globl _PX1
                             65 	.globl _PT0
                             66 	.globl _PX0
                             67 	.globl _EA
                             68 	.globl _ESPI0
                             69 	.globl _ET2
                             70 	.globl _ES0
                             71 	.globl _ES
                             72 	.globl _ET1
                             73 	.globl _EX1
                             74 	.globl _ET0
                             75 	.globl _EX0
                             76 	.globl _P2_7
                             77 	.globl _P2_6
                             78 	.globl _P2_5
                             79 	.globl _P2_4
                             80 	.globl _P2_3
                             81 	.globl _P2_2
                             82 	.globl _P2_1
                             83 	.globl _P2_0
                             84 	.globl _S0MODE
                             85 	.globl _SM0
                             86 	.globl _MCE0
                             87 	.globl _SM2
                             88 	.globl _REN0
                             89 	.globl _REN
                             90 	.globl _TB80
                             91 	.globl _TB8
                             92 	.globl _RB80
                             93 	.globl _RB8
                             94 	.globl _TI0
                             95 	.globl _TI
                             96 	.globl _RI0
                             97 	.globl _RI
                             98 	.globl _P1_7
                             99 	.globl _P1_6
                            100 	.globl _P1_5
                            101 	.globl _P1_4
                            102 	.globl _P1_3
                            103 	.globl _P1_2
                            104 	.globl _P1_1
                            105 	.globl _P1_0
                            106 	.globl _TF1
                            107 	.globl _TR1
                            108 	.globl _TF0
                            109 	.globl _TR0
                            110 	.globl _IE1
                            111 	.globl _IT1
                            112 	.globl _IE0
                            113 	.globl _IT0
                            114 	.globl _P0_7
                            115 	.globl _P0_6
                            116 	.globl _P0_5
                            117 	.globl _P0_4
                            118 	.globl _P0_3
                            119 	.globl _P0_2
                            120 	.globl _P0_1
                            121 	.globl _P0_0
                            122 	.globl _PCA0CP2
                            123 	.globl _PCA0CP1
                            124 	.globl _PCA0CP0
                            125 	.globl _PCA0
                            126 	.globl _ADC0LT
                            127 	.globl _ADC0GT
                            128 	.globl _ADC0
                            129 	.globl _IDA0
                            130 	.globl _TMR3RL
                            131 	.globl _TMR3
                            132 	.globl _TMR2RL
                            133 	.globl _RCAP2
                            134 	.globl _TMR2
                            135 	.globl _TMR1
                            136 	.globl _TMR0
                            137 	.globl _VDM0CN
                            138 	.globl _PCA0CPH0
                            139 	.globl _PCA0CPL0
                            140 	.globl _PCA0H
                            141 	.globl _PCA0L
                            142 	.globl _SPI0CN
                            143 	.globl _EIP1
                            144 	.globl _P1MDIN
                            145 	.globl _P1MODE
                            146 	.globl _P0MDIN
                            147 	.globl _P0MODE
                            148 	.globl _B
                            149 	.globl _RSTSRC
                            150 	.globl _PCA0CPH2
                            151 	.globl _PCA0CPL2
                            152 	.globl _PCA0CPH1
                            153 	.globl _PCA0CPL1
                            154 	.globl _ADC0CN
                            155 	.globl _EIE1
                            156 	.globl _INT01CF
                            157 	.globl _IT01CF
                            158 	.globl _OSCLCN
                            159 	.globl _XBR1
                            160 	.globl _XBR0
                            161 	.globl _ACC
                            162 	.globl _PCA0CPM2
                            163 	.globl _PCA0CPM1
                            164 	.globl _PCA0CPM0
                            165 	.globl _PCA0MD
                            166 	.globl _PCA0CN
                            167 	.globl _P1SKIP
                            168 	.globl _P0SKIP
                            169 	.globl _REF0CN
                            170 	.globl _PSW
                            171 	.globl _TMR2H
                            172 	.globl _TH2
                            173 	.globl _TMR2L
                            174 	.globl _TL2
                            175 	.globl _TMR2RLH
                            176 	.globl _RCAP2H
                            177 	.globl _TMR2RLL
                            178 	.globl _RCAP2L
                            179 	.globl _TMR2CN
                            180 	.globl _T2CON
                            181 	.globl _ADC0LTH
                            182 	.globl _ADC0LTL
                            183 	.globl _ADC0GTH
                            184 	.globl _ADC0GTL
                            185 	.globl _SMB0DAT
                            186 	.globl _SMB0CF
                            187 	.globl _SMB0CN
                            188 	.globl _ADC0H
                            189 	.globl _ADC0L
                            190 	.globl _ADC0CF
                            191 	.globl _AMX0P
                            192 	.globl _AMX0N
                            193 	.globl _IDA0CN
                            194 	.globl _IP
                            195 	.globl _FLKEY
                            196 	.globl _FLSCL
                            197 	.globl _OSCICL
                            198 	.globl _OSCICN
                            199 	.globl _OSCXCN
                            200 	.globl __XPAGE
                            201 	.globl _EMI0CN
                            202 	.globl _CLKSEL
                            203 	.globl _IE
                            204 	.globl _P2MDOUT
                            205 	.globl _P1MDOUT
                            206 	.globl _P0MDOUT
                            207 	.globl _SPI0DAT
                            208 	.globl _SPI0CKR
                            209 	.globl _SPI0CFG
                            210 	.globl _P2
                            211 	.globl _CPT0MX
                            212 	.globl _CPT0MD
                            213 	.globl _CPT0CN
                            214 	.globl _SBUF0
                            215 	.globl _SBUF
                            216 	.globl _SCON0
                            217 	.globl _SCON
                            218 	.globl _IDA0H
                            219 	.globl _IDA0L
                            220 	.globl _TMR3H
                            221 	.globl _TMR3L
                            222 	.globl _TMR3RLH
                            223 	.globl _TMR3RLL
                            224 	.globl _TMR3CN
                            225 	.globl _P1
                            226 	.globl _PSCTL
                            227 	.globl _CKCON
                            228 	.globl _TH1
                            229 	.globl _TH0
                            230 	.globl _TL1
                            231 	.globl _TL0
                            232 	.globl _TMOD
                            233 	.globl _TCON
                            234 	.globl _PCON
                            235 	.globl _DPH
                            236 	.globl _DPL
                            237 	.globl _SP
                            238 	.globl _P0
                            239 	.globl _UnsignedToAscii_PARM_3
                            240 	.globl _UnsignedToAscii_PARM_2
                            241 	.globl _AsciiToUnsigned_PARM_2
                            242 	.globl _AsciiToUnsigned
                            243 	.globl _UnsignedToAscii
                            244 	.globl _CharToAscii
                            245 ;--------------------------------------------------------
                            246 ; special function registers
                            247 ;--------------------------------------------------------
                            248 	.area RSEG    (DATA)
                    0080    249 G$P0$0$0 == 0x0080
                    0080    250 _P0	=	0x0080
                    0081    251 G$SP$0$0 == 0x0081
                    0081    252 _SP	=	0x0081
                    0082    253 G$DPL$0$0 == 0x0082
                    0082    254 _DPL	=	0x0082
                    0083    255 G$DPH$0$0 == 0x0083
                    0083    256 _DPH	=	0x0083
                    0087    257 G$PCON$0$0 == 0x0087
                    0087    258 _PCON	=	0x0087
                    0088    259 G$TCON$0$0 == 0x0088
                    0088    260 _TCON	=	0x0088
                    0089    261 G$TMOD$0$0 == 0x0089
                    0089    262 _TMOD	=	0x0089
                    008A    263 G$TL0$0$0 == 0x008a
                    008A    264 _TL0	=	0x008a
                    008B    265 G$TL1$0$0 == 0x008b
                    008B    266 _TL1	=	0x008b
                    008C    267 G$TH0$0$0 == 0x008c
                    008C    268 _TH0	=	0x008c
                    008D    269 G$TH1$0$0 == 0x008d
                    008D    270 _TH1	=	0x008d
                    008E    271 G$CKCON$0$0 == 0x008e
                    008E    272 _CKCON	=	0x008e
                    008F    273 G$PSCTL$0$0 == 0x008f
                    008F    274 _PSCTL	=	0x008f
                    0090    275 G$P1$0$0 == 0x0090
                    0090    276 _P1	=	0x0090
                    0091    277 G$TMR3CN$0$0 == 0x0091
                    0091    278 _TMR3CN	=	0x0091
                    0092    279 G$TMR3RLL$0$0 == 0x0092
                    0092    280 _TMR3RLL	=	0x0092
                    0093    281 G$TMR3RLH$0$0 == 0x0093
                    0093    282 _TMR3RLH	=	0x0093
                    0094    283 G$TMR3L$0$0 == 0x0094
                    0094    284 _TMR3L	=	0x0094
                    0095    285 G$TMR3H$0$0 == 0x0095
                    0095    286 _TMR3H	=	0x0095
                    0096    287 G$IDA0L$0$0 == 0x0096
                    0096    288 _IDA0L	=	0x0096
                    0097    289 G$IDA0H$0$0 == 0x0097
                    0097    290 _IDA0H	=	0x0097
                    0098    291 G$SCON$0$0 == 0x0098
                    0098    292 _SCON	=	0x0098
                    0098    293 G$SCON0$0$0 == 0x0098
                    0098    294 _SCON0	=	0x0098
                    0099    295 G$SBUF$0$0 == 0x0099
                    0099    296 _SBUF	=	0x0099
                    0099    297 G$SBUF0$0$0 == 0x0099
                    0099    298 _SBUF0	=	0x0099
                    009B    299 G$CPT0CN$0$0 == 0x009b
                    009B    300 _CPT0CN	=	0x009b
                    009D    301 G$CPT0MD$0$0 == 0x009d
                    009D    302 _CPT0MD	=	0x009d
                    009F    303 G$CPT0MX$0$0 == 0x009f
                    009F    304 _CPT0MX	=	0x009f
                    00A0    305 G$P2$0$0 == 0x00a0
                    00A0    306 _P2	=	0x00a0
                    00A1    307 G$SPI0CFG$0$0 == 0x00a1
                    00A1    308 _SPI0CFG	=	0x00a1
                    00A2    309 G$SPI0CKR$0$0 == 0x00a2
                    00A2    310 _SPI0CKR	=	0x00a2
                    00A3    311 G$SPI0DAT$0$0 == 0x00a3
                    00A3    312 _SPI0DAT	=	0x00a3
                    00A4    313 G$P0MDOUT$0$0 == 0x00a4
                    00A4    314 _P0MDOUT	=	0x00a4
                    00A5    315 G$P1MDOUT$0$0 == 0x00a5
                    00A5    316 _P1MDOUT	=	0x00a5
                    00A6    317 G$P2MDOUT$0$0 == 0x00a6
                    00A6    318 _P2MDOUT	=	0x00a6
                    00A8    319 G$IE$0$0 == 0x00a8
                    00A8    320 _IE	=	0x00a8
                    00A9    321 G$CLKSEL$0$0 == 0x00a9
                    00A9    322 _CLKSEL	=	0x00a9
                    00AA    323 G$EMI0CN$0$0 == 0x00aa
                    00AA    324 _EMI0CN	=	0x00aa
                    00AA    325 G$_XPAGE$0$0 == 0x00aa
                    00AA    326 __XPAGE	=	0x00aa
                    00B1    327 G$OSCXCN$0$0 == 0x00b1
                    00B1    328 _OSCXCN	=	0x00b1
                    00B2    329 G$OSCICN$0$0 == 0x00b2
                    00B2    330 _OSCICN	=	0x00b2
                    00B3    331 G$OSCICL$0$0 == 0x00b3
                    00B3    332 _OSCICL	=	0x00b3
                    00B6    333 G$FLSCL$0$0 == 0x00b6
                    00B6    334 _FLSCL	=	0x00b6
                    00B7    335 G$FLKEY$0$0 == 0x00b7
                    00B7    336 _FLKEY	=	0x00b7
                    00B8    337 G$IP$0$0 == 0x00b8
                    00B8    338 _IP	=	0x00b8
                    00B9    339 G$IDA0CN$0$0 == 0x00b9
                    00B9    340 _IDA0CN	=	0x00b9
                    00BA    341 G$AMX0N$0$0 == 0x00ba
                    00BA    342 _AMX0N	=	0x00ba
                    00BB    343 G$AMX0P$0$0 == 0x00bb
                    00BB    344 _AMX0P	=	0x00bb
                    00BC    345 G$ADC0CF$0$0 == 0x00bc
                    00BC    346 _ADC0CF	=	0x00bc
                    00BD    347 G$ADC0L$0$0 == 0x00bd
                    00BD    348 _ADC0L	=	0x00bd
                    00BE    349 G$ADC0H$0$0 == 0x00be
                    00BE    350 _ADC0H	=	0x00be
                    00C0    351 G$SMB0CN$0$0 == 0x00c0
                    00C0    352 _SMB0CN	=	0x00c0
                    00C1    353 G$SMB0CF$0$0 == 0x00c1
                    00C1    354 _SMB0CF	=	0x00c1
                    00C2    355 G$SMB0DAT$0$0 == 0x00c2
                    00C2    356 _SMB0DAT	=	0x00c2
                    00C3    357 G$ADC0GTL$0$0 == 0x00c3
                    00C3    358 _ADC0GTL	=	0x00c3
                    00C4    359 G$ADC0GTH$0$0 == 0x00c4
                    00C4    360 _ADC0GTH	=	0x00c4
                    00C5    361 G$ADC0LTL$0$0 == 0x00c5
                    00C5    362 _ADC0LTL	=	0x00c5
                    00C6    363 G$ADC0LTH$0$0 == 0x00c6
                    00C6    364 _ADC0LTH	=	0x00c6
                    00C8    365 G$T2CON$0$0 == 0x00c8
                    00C8    366 _T2CON	=	0x00c8
                    00C8    367 G$TMR2CN$0$0 == 0x00c8
                    00C8    368 _TMR2CN	=	0x00c8
                    00CA    369 G$RCAP2L$0$0 == 0x00ca
                    00CA    370 _RCAP2L	=	0x00ca
                    00CA    371 G$TMR2RLL$0$0 == 0x00ca
                    00CA    372 _TMR2RLL	=	0x00ca
                    00CB    373 G$RCAP2H$0$0 == 0x00cb
                    00CB    374 _RCAP2H	=	0x00cb
                    00CB    375 G$TMR2RLH$0$0 == 0x00cb
                    00CB    376 _TMR2RLH	=	0x00cb
                    00CC    377 G$TL2$0$0 == 0x00cc
                    00CC    378 _TL2	=	0x00cc
                    00CC    379 G$TMR2L$0$0 == 0x00cc
                    00CC    380 _TMR2L	=	0x00cc
                    00CD    381 G$TH2$0$0 == 0x00cd
                    00CD    382 _TH2	=	0x00cd
                    00CD    383 G$TMR2H$0$0 == 0x00cd
                    00CD    384 _TMR2H	=	0x00cd
                    00D0    385 G$PSW$0$0 == 0x00d0
                    00D0    386 _PSW	=	0x00d0
                    00D1    387 G$REF0CN$0$0 == 0x00d1
                    00D1    388 _REF0CN	=	0x00d1
                    00D4    389 G$P0SKIP$0$0 == 0x00d4
                    00D4    390 _P0SKIP	=	0x00d4
                    00D5    391 G$P1SKIP$0$0 == 0x00d5
                    00D5    392 _P1SKIP	=	0x00d5
                    00D8    393 G$PCA0CN$0$0 == 0x00d8
                    00D8    394 _PCA0CN	=	0x00d8
                    00D9    395 G$PCA0MD$0$0 == 0x00d9
                    00D9    396 _PCA0MD	=	0x00d9
                    00DA    397 G$PCA0CPM0$0$0 == 0x00da
                    00DA    398 _PCA0CPM0	=	0x00da
                    00DB    399 G$PCA0CPM1$0$0 == 0x00db
                    00DB    400 _PCA0CPM1	=	0x00db
                    00DC    401 G$PCA0CPM2$0$0 == 0x00dc
                    00DC    402 _PCA0CPM2	=	0x00dc
                    00E0    403 G$ACC$0$0 == 0x00e0
                    00E0    404 _ACC	=	0x00e0
                    00E1    405 G$XBR0$0$0 == 0x00e1
                    00E1    406 _XBR0	=	0x00e1
                    00E2    407 G$XBR1$0$0 == 0x00e2
                    00E2    408 _XBR1	=	0x00e2
                    00E3    409 G$OSCLCN$0$0 == 0x00e3
                    00E3    410 _OSCLCN	=	0x00e3
                    00E4    411 G$IT01CF$0$0 == 0x00e4
                    00E4    412 _IT01CF	=	0x00e4
                    00E4    413 G$INT01CF$0$0 == 0x00e4
                    00E4    414 _INT01CF	=	0x00e4
                    00E6    415 G$EIE1$0$0 == 0x00e6
                    00E6    416 _EIE1	=	0x00e6
                    00E8    417 G$ADC0CN$0$0 == 0x00e8
                    00E8    418 _ADC0CN	=	0x00e8
                    00E9    419 G$PCA0CPL1$0$0 == 0x00e9
                    00E9    420 _PCA0CPL1	=	0x00e9
                    00EA    421 G$PCA0CPH1$0$0 == 0x00ea
                    00EA    422 _PCA0CPH1	=	0x00ea
                    00EB    423 G$PCA0CPL2$0$0 == 0x00eb
                    00EB    424 _PCA0CPL2	=	0x00eb
                    00EC    425 G$PCA0CPH2$0$0 == 0x00ec
                    00EC    426 _PCA0CPH2	=	0x00ec
                    00EF    427 G$RSTSRC$0$0 == 0x00ef
                    00EF    428 _RSTSRC	=	0x00ef
                    00F0    429 G$B$0$0 == 0x00f0
                    00F0    430 _B	=	0x00f0
                    00F1    431 G$P0MODE$0$0 == 0x00f1
                    00F1    432 _P0MODE	=	0x00f1
                    00F1    433 G$P0MDIN$0$0 == 0x00f1
                    00F1    434 _P0MDIN	=	0x00f1
                    00F2    435 G$P1MODE$0$0 == 0x00f2
                    00F2    436 _P1MODE	=	0x00f2
                    00F2    437 G$P1MDIN$0$0 == 0x00f2
                    00F2    438 _P1MDIN	=	0x00f2
                    00F6    439 G$EIP1$0$0 == 0x00f6
                    00F6    440 _EIP1	=	0x00f6
                    00F8    441 G$SPI0CN$0$0 == 0x00f8
                    00F8    442 _SPI0CN	=	0x00f8
                    00F9    443 G$PCA0L$0$0 == 0x00f9
                    00F9    444 _PCA0L	=	0x00f9
                    00FA    445 G$PCA0H$0$0 == 0x00fa
                    00FA    446 _PCA0H	=	0x00fa
                    00FB    447 G$PCA0CPL0$0$0 == 0x00fb
                    00FB    448 _PCA0CPL0	=	0x00fb
                    00FC    449 G$PCA0CPH0$0$0 == 0x00fc
                    00FC    450 _PCA0CPH0	=	0x00fc
                    00FF    451 G$VDM0CN$0$0 == 0x00ff
                    00FF    452 _VDM0CN	=	0x00ff
                    8C8A    453 G$TMR0$0$0 == 0x8c8a
                    8C8A    454 _TMR0	=	0x8c8a
                    8D8B    455 G$TMR1$0$0 == 0x8d8b
                    8D8B    456 _TMR1	=	0x8d8b
                    CDCC    457 G$TMR2$0$0 == 0xcdcc
                    CDCC    458 _TMR2	=	0xcdcc
                    CBCA    459 G$RCAP2$0$0 == 0xcbca
                    CBCA    460 _RCAP2	=	0xcbca
                    CBCA    461 G$TMR2RL$0$0 == 0xcbca
                    CBCA    462 _TMR2RL	=	0xcbca
                    9594    463 G$TMR3$0$0 == 0x9594
                    9594    464 _TMR3	=	0x9594
                    9392    465 G$TMR3RL$0$0 == 0x9392
                    9392    466 _TMR3RL	=	0x9392
                    9796    467 G$IDA0$0$0 == 0x9796
                    9796    468 _IDA0	=	0x9796
                    BEBD    469 G$ADC0$0$0 == 0xbebd
                    BEBD    470 _ADC0	=	0xbebd
                    C4C3    471 G$ADC0GT$0$0 == 0xc4c3
                    C4C3    472 _ADC0GT	=	0xc4c3
                    C6C5    473 G$ADC0LT$0$0 == 0xc6c5
                    C6C5    474 _ADC0LT	=	0xc6c5
                    FAF9    475 G$PCA0$0$0 == 0xfaf9
                    FAF9    476 _PCA0	=	0xfaf9
                    FCFB    477 G$PCA0CP0$0$0 == 0xfcfb
                    FCFB    478 _PCA0CP0	=	0xfcfb
                    EAE9    479 G$PCA0CP1$0$0 == 0xeae9
                    EAE9    480 _PCA0CP1	=	0xeae9
                    ECEB    481 G$PCA0CP2$0$0 == 0xeceb
                    ECEB    482 _PCA0CP2	=	0xeceb
                            483 ;--------------------------------------------------------
                            484 ; special function bits
                            485 ;--------------------------------------------------------
                            486 	.area RSEG    (DATA)
                    0080    487 G$P0_0$0$0 == 0x0080
                    0080    488 _P0_0	=	0x0080
                    0081    489 G$P0_1$0$0 == 0x0081
                    0081    490 _P0_1	=	0x0081
                    0082    491 G$P0_2$0$0 == 0x0082
                    0082    492 _P0_2	=	0x0082
                    0083    493 G$P0_3$0$0 == 0x0083
                    0083    494 _P0_3	=	0x0083
                    0084    495 G$P0_4$0$0 == 0x0084
                    0084    496 _P0_4	=	0x0084
                    0085    497 G$P0_5$0$0 == 0x0085
                    0085    498 _P0_5	=	0x0085
                    0086    499 G$P0_6$0$0 == 0x0086
                    0086    500 _P0_6	=	0x0086
                    0087    501 G$P0_7$0$0 == 0x0087
                    0087    502 _P0_7	=	0x0087
                    0088    503 G$IT0$0$0 == 0x0088
                    0088    504 _IT0	=	0x0088
                    0089    505 G$IE0$0$0 == 0x0089
                    0089    506 _IE0	=	0x0089
                    008A    507 G$IT1$0$0 == 0x008a
                    008A    508 _IT1	=	0x008a
                    008B    509 G$IE1$0$0 == 0x008b
                    008B    510 _IE1	=	0x008b
                    008C    511 G$TR0$0$0 == 0x008c
                    008C    512 _TR0	=	0x008c
                    008D    513 G$TF0$0$0 == 0x008d
                    008D    514 _TF0	=	0x008d
                    008E    515 G$TR1$0$0 == 0x008e
                    008E    516 _TR1	=	0x008e
                    008F    517 G$TF1$0$0 == 0x008f
                    008F    518 _TF1	=	0x008f
                    0090    519 G$P1_0$0$0 == 0x0090
                    0090    520 _P1_0	=	0x0090
                    0091    521 G$P1_1$0$0 == 0x0091
                    0091    522 _P1_1	=	0x0091
                    0092    523 G$P1_2$0$0 == 0x0092
                    0092    524 _P1_2	=	0x0092
                    0093    525 G$P1_3$0$0 == 0x0093
                    0093    526 _P1_3	=	0x0093
                    0094    527 G$P1_4$0$0 == 0x0094
                    0094    528 _P1_4	=	0x0094
                    0095    529 G$P1_5$0$0 == 0x0095
                    0095    530 _P1_5	=	0x0095
                    0096    531 G$P1_6$0$0 == 0x0096
                    0096    532 _P1_6	=	0x0096
                    0097    533 G$P1_7$0$0 == 0x0097
                    0097    534 _P1_7	=	0x0097
                    0098    535 G$RI$0$0 == 0x0098
                    0098    536 _RI	=	0x0098
                    0098    537 G$RI0$0$0 == 0x0098
                    0098    538 _RI0	=	0x0098
                    0099    539 G$TI$0$0 == 0x0099
                    0099    540 _TI	=	0x0099
                    0099    541 G$TI0$0$0 == 0x0099
                    0099    542 _TI0	=	0x0099
                    009A    543 G$RB8$0$0 == 0x009a
                    009A    544 _RB8	=	0x009a
                    009A    545 G$RB80$0$0 == 0x009a
                    009A    546 _RB80	=	0x009a
                    009B    547 G$TB8$0$0 == 0x009b
                    009B    548 _TB8	=	0x009b
                    009B    549 G$TB80$0$0 == 0x009b
                    009B    550 _TB80	=	0x009b
                    009C    551 G$REN$0$0 == 0x009c
                    009C    552 _REN	=	0x009c
                    009C    553 G$REN0$0$0 == 0x009c
                    009C    554 _REN0	=	0x009c
                    009D    555 G$SM2$0$0 == 0x009d
                    009D    556 _SM2	=	0x009d
                    009D    557 G$MCE0$0$0 == 0x009d
                    009D    558 _MCE0	=	0x009d
                    009F    559 G$SM0$0$0 == 0x009f
                    009F    560 _SM0	=	0x009f
                    009F    561 G$S0MODE$0$0 == 0x009f
                    009F    562 _S0MODE	=	0x009f
                    00A0    563 G$P2_0$0$0 == 0x00a0
                    00A0    564 _P2_0	=	0x00a0
                    00A1    565 G$P2_1$0$0 == 0x00a1
                    00A1    566 _P2_1	=	0x00a1
                    00A2    567 G$P2_2$0$0 == 0x00a2
                    00A2    568 _P2_2	=	0x00a2
                    00A3    569 G$P2_3$0$0 == 0x00a3
                    00A3    570 _P2_3	=	0x00a3
                    00A4    571 G$P2_4$0$0 == 0x00a4
                    00A4    572 _P2_4	=	0x00a4
                    00A5    573 G$P2_5$0$0 == 0x00a5
                    00A5    574 _P2_5	=	0x00a5
                    00A6    575 G$P2_6$0$0 == 0x00a6
                    00A6    576 _P2_6	=	0x00a6
                    00A7    577 G$P2_7$0$0 == 0x00a7
                    00A7    578 _P2_7	=	0x00a7
                    00A8    579 G$EX0$0$0 == 0x00a8
                    00A8    580 _EX0	=	0x00a8
                    00A9    581 G$ET0$0$0 == 0x00a9
                    00A9    582 _ET0	=	0x00a9
                    00AA    583 G$EX1$0$0 == 0x00aa
                    00AA    584 _EX1	=	0x00aa
                    00AB    585 G$ET1$0$0 == 0x00ab
                    00AB    586 _ET1	=	0x00ab
                    00AC    587 G$ES$0$0 == 0x00ac
                    00AC    588 _ES	=	0x00ac
                    00AC    589 G$ES0$0$0 == 0x00ac
                    00AC    590 _ES0	=	0x00ac
                    00AD    591 G$ET2$0$0 == 0x00ad
                    00AD    592 _ET2	=	0x00ad
                    00AE    593 G$ESPI0$0$0 == 0x00ae
                    00AE    594 _ESPI0	=	0x00ae
                    00AF    595 G$EA$0$0 == 0x00af
                    00AF    596 _EA	=	0x00af
                    00B8    597 G$PX0$0$0 == 0x00b8
                    00B8    598 _PX0	=	0x00b8
                    00B9    599 G$PT0$0$0 == 0x00b9
                    00B9    600 _PT0	=	0x00b9
                    00BA    601 G$PX1$0$0 == 0x00ba
                    00BA    602 _PX1	=	0x00ba
                    00BB    603 G$PT1$0$0 == 0x00bb
                    00BB    604 _PT1	=	0x00bb
                    00BC    605 G$PS$0$0 == 0x00bc
                    00BC    606 _PS	=	0x00bc
                    00BC    607 G$PS0$0$0 == 0x00bc
                    00BC    608 _PS0	=	0x00bc
                    00BD    609 G$PT2$0$0 == 0x00bd
                    00BD    610 _PT2	=	0x00bd
                    00BE    611 G$PSPI0$0$0 == 0x00be
                    00BE    612 _PSPI0	=	0x00be
                    00C0    613 G$SI$0$0 == 0x00c0
                    00C0    614 _SI	=	0x00c0
                    00C1    615 G$ACK$0$0 == 0x00c1
                    00C1    616 _ACK	=	0x00c1
                    00C2    617 G$ARBLOST$0$0 == 0x00c2
                    00C2    618 _ARBLOST	=	0x00c2
                    00C3    619 G$ACKRQ$0$0 == 0x00c3
                    00C3    620 _ACKRQ	=	0x00c3
                    00C4    621 G$STO$0$0 == 0x00c4
                    00C4    622 _STO	=	0x00c4
                    00C5    623 G$STA$0$0 == 0x00c5
                    00C5    624 _STA	=	0x00c5
                    00C6    625 G$TXMODE$0$0 == 0x00c6
                    00C6    626 _TXMODE	=	0x00c6
                    00C7    627 G$MASTER$0$0 == 0x00c7
                    00C7    628 _MASTER	=	0x00c7
                    00C8    629 G$T2XCLK$0$0 == 0x00c8
                    00C8    630 _T2XCLK	=	0x00c8
                    00CA    631 G$TR2$0$0 == 0x00ca
                    00CA    632 _TR2	=	0x00ca
                    00CB    633 G$T2SPLIT$0$0 == 0x00cb
                    00CB    634 _T2SPLIT	=	0x00cb
                    00CD    635 G$TF2CEN$0$0 == 0x00cd
                    00CD    636 _TF2CEN	=	0x00cd
                    00CD    637 G$TF2LEN$0$0 == 0x00cd
                    00CD    638 _TF2LEN	=	0x00cd
                    00CE    639 G$TF2L$0$0 == 0x00ce
                    00CE    640 _TF2L	=	0x00ce
                    00CF    641 G$TF2$0$0 == 0x00cf
                    00CF    642 _TF2	=	0x00cf
                    00CF    643 G$TF2H$0$0 == 0x00cf
                    00CF    644 _TF2H	=	0x00cf
                    00D0    645 G$PARITY$0$0 == 0x00d0
                    00D0    646 _PARITY	=	0x00d0
                    00D1    647 G$F1$0$0 == 0x00d1
                    00D1    648 _F1	=	0x00d1
                    00D2    649 G$OV$0$0 == 0x00d2
                    00D2    650 _OV	=	0x00d2
                    00D3    651 G$RS0$0$0 == 0x00d3
                    00D3    652 _RS0	=	0x00d3
                    00D4    653 G$RS1$0$0 == 0x00d4
                    00D4    654 _RS1	=	0x00d4
                    00D5    655 G$F0$0$0 == 0x00d5
                    00D5    656 _F0	=	0x00d5
                    00D6    657 G$AC$0$0 == 0x00d6
                    00D6    658 _AC	=	0x00d6
                    00D7    659 G$CY$0$0 == 0x00d7
                    00D7    660 _CY	=	0x00d7
                    00D8    661 G$CCF0$0$0 == 0x00d8
                    00D8    662 _CCF0	=	0x00d8
                    00D9    663 G$CCF1$0$0 == 0x00d9
                    00D9    664 _CCF1	=	0x00d9
                    00DA    665 G$CCF2$0$0 == 0x00da
                    00DA    666 _CCF2	=	0x00da
                    00DE    667 G$CR$0$0 == 0x00de
                    00DE    668 _CR	=	0x00de
                    00DF    669 G$CF$0$0 == 0x00df
                    00DF    670 _CF	=	0x00df
                    00E8    671 G$AD0CM0$0$0 == 0x00e8
                    00E8    672 _AD0CM0	=	0x00e8
                    00E9    673 G$AD0CM1$0$0 == 0x00e9
                    00E9    674 _AD0CM1	=	0x00e9
                    00EA    675 G$AD0CM2$0$0 == 0x00ea
                    00EA    676 _AD0CM2	=	0x00ea
                    00EB    677 G$AD0WINT$0$0 == 0x00eb
                    00EB    678 _AD0WINT	=	0x00eb
                    00EC    679 G$AD0BUSY$0$0 == 0x00ec
                    00EC    680 _AD0BUSY	=	0x00ec
                    00ED    681 G$AD0INT$0$0 == 0x00ed
                    00ED    682 _AD0INT	=	0x00ed
                    00EE    683 G$AD0TM$0$0 == 0x00ee
                    00EE    684 _AD0TM	=	0x00ee
                    00EF    685 G$AD0EN$0$0 == 0x00ef
                    00EF    686 _AD0EN	=	0x00ef
                    00F8    687 G$SPIEN$0$0 == 0x00f8
                    00F8    688 _SPIEN	=	0x00f8
                    00F9    689 G$TXBMT$0$0 == 0x00f9
                    00F9    690 _TXBMT	=	0x00f9
                    00FA    691 G$NSSMD0$0$0 == 0x00fa
                    00FA    692 _NSSMD0	=	0x00fa
                    00FB    693 G$NSSMD1$0$0 == 0x00fb
                    00FB    694 _NSSMD1	=	0x00fb
                    00FC    695 G$RXOVRN$0$0 == 0x00fc
                    00FC    696 _RXOVRN	=	0x00fc
                    00FD    697 G$MODF$0$0 == 0x00fd
                    00FD    698 _MODF	=	0x00fd
                    00FE    699 G$WCOL$0$0 == 0x00fe
                    00FE    700 _WCOL	=	0x00fe
                    00FF    701 G$SPIF$0$0 == 0x00ff
                    00FF    702 _SPIF	=	0x00ff
                            703 ;--------------------------------------------------------
                            704 ; overlayable register banks
                            705 ;--------------------------------------------------------
                            706 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     707 	.ds 8
                            708 ;--------------------------------------------------------
                            709 ; internal ram data
                            710 ;--------------------------------------------------------
                            711 	.area DSEG    (DATA)
                    0000    712 LAsciiToUnsigned$p_int$1$1==.
   0018                     713 _AsciiToUnsigned_PARM_2:
   0018                     714 	.ds 3
                    0003    715 LUnsignedToAscii$pbuf$1$1==.
   001B                     716 _UnsignedToAscii_PARM_2:
   001B                     717 	.ds 2
                    0005    718 LUnsignedToAscii$nbdigits$1$1==.
   001D                     719 _UnsignedToAscii_PARM_3:
   001D                     720 	.ds 1
                            721 ;--------------------------------------------------------
                            722 ; overlayable items in internal ram 
                            723 ;--------------------------------------------------------
                            724 	.area	OSEG    (OVR,DATA)
                    0000    725 LCharToAscii$pbuf$1$1==.
   0046                     726 _CharToAscii_PARM_2::
   0046                     727 	.ds 2
                    0002    728 LCharToAscii$nbdigits$1$1==.
   0048                     729 _CharToAscii_PARM_3::
   0048                     730 	.ds 1
                            731 ;--------------------------------------------------------
                            732 ; indirectly addressable internal ram data
                            733 ;--------------------------------------------------------
                            734 	.area ISEG    (DATA)
                            735 ;--------------------------------------------------------
                            736 ; bit data
                            737 ;--------------------------------------------------------
                            738 	.area BSEG    (BIT)
                            739 ;--------------------------------------------------------
                            740 ; paged external ram data
                            741 ;--------------------------------------------------------
                            742 	.area PSEG    (PAG,XDATA)
                            743 ;--------------------------------------------------------
                            744 ; external ram data
                            745 ;--------------------------------------------------------
                            746 	.area XSEG    (XDATA)
                            747 ;--------------------------------------------------------
                            748 ; external initialized ram data
                            749 ;--------------------------------------------------------
                            750 	.area XISEG   (XDATA)
                            751 	.area HOME    (CODE)
                            752 	.area GSINIT0 (CODE)
                            753 	.area GSINIT1 (CODE)
                            754 	.area GSINIT2 (CODE)
                            755 	.area GSINIT3 (CODE)
                            756 	.area GSINIT4 (CODE)
                            757 	.area GSINIT5 (CODE)
                            758 	.area GSINIT  (CODE)
                            759 	.area GSFINAL (CODE)
                            760 	.area CSEG    (CODE)
                            761 ;--------------------------------------------------------
                            762 ; global & static initialisations
                            763 ;--------------------------------------------------------
                            764 	.area HOME    (CODE)
                            765 	.area GSINIT  (CODE)
                            766 	.area GSFINAL (CODE)
                            767 	.area GSINIT  (CODE)
                            768 ;--------------------------------------------------------
                            769 ; Home
                            770 ;--------------------------------------------------------
                            771 	.area HOME    (CODE)
                            772 	.area CSEG    (CODE)
                            773 ;--------------------------------------------------------
                            774 ; code
                            775 ;--------------------------------------------------------
                            776 	.area CSEG    (CODE)
                            777 ;------------------------------------------------------------
                            778 ;Allocation info for local variables in function 'AsciiToUnsigned'
                            779 ;------------------------------------------------------------
                            780 ;p_int                     Allocated with name '_AsciiToUnsigned_PARM_2'
                            781 ;p_ascii                   Allocated to registers r2 r3 
                            782 ;i                         Allocated to registers r7 
                            783 ;n                         Allocated to registers r4 
                            784 ;value                     Allocated to registers r5 r6 
                            785 ;------------------------------------------------------------
                    0000    786 	G$AsciiToUnsigned$0$0 ==.
                    0000    787 	C$iconv.c$64$0$0 ==.
                            788 ;	C:/SDCC/GPSMon/dev/iconv.c:64: uchar AsciiToUnsigned( uchar TXRX_STORAGE_CLASS *p_ascii, 
                            789 ;	-----------------------------------------
                            790 ;	 function AsciiToUnsigned
                            791 ;	-----------------------------------------
   0E64                     792 _AsciiToUnsigned:
                    0002    793 	ar2 = 0x02
                    0003    794 	ar3 = 0x03
                    0004    795 	ar4 = 0x04
                    0005    796 	ar5 = 0x05
                    0006    797 	ar6 = 0x06
                    0007    798 	ar7 = 0x07
                    0000    799 	ar0 = 0x00
                    0001    800 	ar1 = 0x01
                            801 ;	genReceive
   0E64 AA 82               802 	mov	r2,dpl
   0E66 AB 83               803 	mov	r3,dph
                    0004    804 	C$iconv.c$67$1$0 ==.
                            805 ;	C:/SDCC/GPSMon/dev/iconv.c:67: uchar i = 0, n = 0;
                            806 ;	genAssign
   0E68 7C 00               807 	mov	r4,#0x00
                    0006    808 	C$iconv.c$68$1$0 ==.
                            809 ;	C:/SDCC/GPSMon/dev/iconv.c:68: uint value = 0;
                            810 ;	genAssign
   0E6A 7D 00               811 	mov	r5,#0x00
   0E6C 7E 00               812 	mov	r6,#0x00
                    000A    813 	C$iconv.c$70$1$1 ==.
                            814 ;	C:/SDCC/GPSMon/dev/iconv.c:70: while( (i < (MAX_A2B_DIGITS+1) ) && (n < MAX_A2B_DIGITS) ){
                            815 ;	genAssign
   0E6E 7F 00               816 	mov	r7,#0x00
                            817 ;	genAssign
   0E70                     818 00110$:
                            819 ;	genCmpLt
                            820 ;	genCmp
   0E70 BF 06 00            821 	cjne	r7,#0x06,00128$
   0E73                     822 00128$:
                            823 ;	genIfxJump
                            824 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0E73 50 5F               825 	jnc	00112$
                            826 ;	Peephole 300	removed redundant label 00129$
                            827 ;	genCmpLt
                            828 ;	genCmp
   0E75 BC 05 00            829 	cjne	r4,#0x05,00130$
   0E78                     830 00130$:
                            831 ;	genIfxJump
                            832 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0E78 50 5A               833 	jnc	00112$
                            834 ;	Peephole 300	removed redundant label 00131$
                    0016    835 	C$iconv.c$71$2$2 ==.
                            836 ;	C:/SDCC/GPSMon/dev/iconv.c:71: if( *p_ascii == '\0' )
                            837 ;	genPointerGet
                            838 ;	genFarPointerGet
   0E7A 8A 82               839 	mov	dpl,r2
   0E7C 8B 83               840 	mov	dph,r3
   0E7E E0                  841 	movx	a,@dptr
                            842 ;	genIfx
   0E7F F8                  843 	mov	r0,a
                            844 ;	Peephole 105	removed redundant mov
                            845 ;	genIfxJump
                            846 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0E80 60 52               847 	jz	00112$
                            848 ;	Peephole 300	removed redundant label 00132$
                    001E    849 	C$iconv.c$74$2$2 ==.
                            850 ;	C:/SDCC/GPSMon/dev/iconv.c:74: if( (*p_ascii < '0') || (*p_ascii > '9') ){
                            851 ;	genCmpLt
                            852 ;	genCmp
   0E82 B8 30 00            853 	cjne	r0,#0x30,00133$
   0E85                     854 00133$:
                            855 ;	genIfxJump
                            856 ;	Peephole 112.b	changed ljmp to sjmp
                            857 ;	Peephole 160.a	removed sjmp by inverse jump logic
   0E85 40 05               858 	jc	00105$
                            859 ;	Peephole 300	removed redundant label 00134$
                            860 ;	genCmpGt
                            861 ;	genCmp
                            862 ;	genIfxJump
                            863 ;	Peephole 108.a	removed ljmp by inverse jump logic
                            864 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   0E87 E8                  865 	mov	a,r0
   0E88 24 C6               866 	add	a,#0xff - 0x39
   0E8A 50 0F               867 	jnc	00106$
                            868 ;	Peephole 300	removed redundant label 00135$
   0E8C                     869 00105$:
                    0028    870 	C$iconv.c$75$3$3 ==.
                            871 ;	C:/SDCC/GPSMon/dev/iconv.c:75: if( *p_ascii != ' ' )
                            872 ;	genPointerGet
                            873 ;	genFarPointerGet
   0E8C 8A 82               874 	mov	dpl,r2
   0E8E 8B 83               875 	mov	dph,r3
   0E90 E0                  876 	movx	a,@dptr
   0E91 F9                  877 	mov	r1,a
                            878 ;	genCmpEq
                            879 ;	gencjneshort
   0E92 B9 20 02            880 	cjne	r1,#0x20,00136$
                            881 ;	Peephole 112.b	changed ljmp to sjmp
   0E95 80 35               882 	sjmp	00107$
   0E97                     883 00136$:
                    0033    884 	C$iconv.c$76$3$3 ==.
                            885 ;	C:/SDCC/GPSMon/dev/iconv.c:76: n = MAX_A2B_DIGITS;
                            886 ;	genAssign
   0E97 7C 05               887 	mov	r4,#0x05
                            888 ;	Peephole 112.b	changed ljmp to sjmp
   0E99 80 31               889 	sjmp	00107$
   0E9B                     890 00106$:
                    0037    891 	C$iconv.c$78$3$4 ==.
                            892 ;	C:/SDCC/GPSMon/dev/iconv.c:78: n++;
                            893 ;	genPlus
                            894 ;     genPlusIncr
   0E9B 0C                  895 	inc	r4
                    0038    896 	C$iconv.c$79$1$1 ==.
                            897 ;	C:/SDCC/GPSMon/dev/iconv.c:79: value *= 10;
                            898 ;	genAssign
   0E9C 75 46 0A            899 	mov	__mulint_PARM_2,#0x0A
   0E9F E4                  900 	clr	a
   0EA0 F5 47               901 	mov	(__mulint_PARM_2 + 1),a
                            902 ;	genCall
   0EA2 8D 82               903 	mov	dpl,r5
   0EA4 8E 83               904 	mov	dph,r6
   0EA6 C0 02               905 	push	ar2
   0EA8 C0 03               906 	push	ar3
   0EAA C0 04               907 	push	ar4
   0EAC C0 07               908 	push	ar7
   0EAE C0 00               909 	push	ar0
   0EB0 12 12 E9            910 	lcall	__mulint
   0EB3 AD 82               911 	mov	r5,dpl
   0EB5 AE 83               912 	mov	r6,dph
   0EB7 D0 00               913 	pop	ar0
   0EB9 D0 07               914 	pop	ar7
   0EBB D0 04               915 	pop	ar4
   0EBD D0 03               916 	pop	ar3
   0EBF D0 02               917 	pop	ar2
                    005D    918 	C$iconv.c$80$3$4 ==.
                            919 ;	C:/SDCC/GPSMon/dev/iconv.c:80: value += ( *p_ascii & ASCII_MASK );
                            920 ;	genAnd
   0EC1 53 00 0F            921 	anl	ar0,#0x0F
                            922 ;	genCast
   0EC4 79 00               923 	mov	r1,#0x00
                            924 ;	genPlus
                            925 ;	Peephole 236.g	used r0 instead of ar0
   0EC6 E8                  926 	mov	a,r0
                            927 ;	Peephole 236.a	used r5 instead of ar5
   0EC7 2D                  928 	add	a,r5
   0EC8 FD                  929 	mov	r5,a
                            930 ;	Peephole 236.g	used r1 instead of ar1
   0EC9 E9                  931 	mov	a,r1
                            932 ;	Peephole 236.b	used r6 instead of ar6
   0ECA 3E                  933 	addc	a,r6
   0ECB FE                  934 	mov	r6,a
   0ECC                     935 00107$:
                    0068    936 	C$iconv.c$83$2$2 ==.
                            937 ;	C:/SDCC/GPSMon/dev/iconv.c:83: i++;
                            938 ;	genPlus
                            939 ;     genPlusIncr
   0ECC 0F                  940 	inc	r7
                    0069    941 	C$iconv.c$84$2$2 ==.
                            942 ;	C:/SDCC/GPSMon/dev/iconv.c:84: p_ascii++;
                            943 ;	genPlus
                            944 ;     genPlusIncr
   0ECD 0A                  945 	inc	r2
                            946 ;	Peephole 112.b	changed ljmp to sjmp
                            947 ;	Peephole 243	avoided branch to sjmp
   0ECE BA 00 9F            948 	cjne	r2,#0x00,00110$
   0ED1 0B                  949 	inc	r3
                            950 ;	Peephole 300	removed redundant label 00137$
   0ED2 80 9C               951 	sjmp	00110$
   0ED4                     952 00112$:
                    0070    953 	C$iconv.c$87$1$1 ==.
                            954 ;	C:/SDCC/GPSMon/dev/iconv.c:87: if( (*p_ascii == '\0') && (n > 0) ){
                            955 ;	genPointerGet
                            956 ;	genFarPointerGet
   0ED4 8A 82               957 	mov	dpl,r2
   0ED6 8B 83               958 	mov	dph,r3
   0ED8 E0                  959 	movx	a,@dptr
                            960 ;	genIfxJump
                            961 ;	Peephole 108.b	removed ljmp by inverse jump logic
   0ED9 70 1C               962 	jnz	00114$
                            963 ;	Peephole 300	removed redundant label 00138$
                            964 ;	genIfx
   0EDB EC                  965 	mov	a,r4
                            966 ;	genIfxJump
                            967 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0EDC 60 19               968 	jz	00114$
                            969 ;	Peephole 300	removed redundant label 00139$
                    007A    970 	C$iconv.c$88$2$5 ==.
                            971 ;	C:/SDCC/GPSMon/dev/iconv.c:88: *p_int = value;
                            972 ;	genAssign
   0EDE AA 18               973 	mov	r2,_AsciiToUnsigned_PARM_2
   0EE0 AB 19               974 	mov	r3,(_AsciiToUnsigned_PARM_2 + 1)
   0EE2 AC 1A               975 	mov	r4,(_AsciiToUnsigned_PARM_2 + 2)
                            976 ;	genPointerSet
                            977 ;	genGenPointerSet
   0EE4 8A 82               978 	mov	dpl,r2
   0EE6 8B 83               979 	mov	dph,r3
   0EE8 8C F0               980 	mov	b,r4
   0EEA ED                  981 	mov	a,r5
   0EEB 12 12 D0            982 	lcall	__gptrput
   0EEE A3                  983 	inc	dptr
   0EEF EE                  984 	mov	a,r6
   0EF0 12 12 D0            985 	lcall	__gptrput
                    008F    986 	C$iconv.c$89$2$5 ==.
                            987 ;	C:/SDCC/GPSMon/dev/iconv.c:89: return( TRUE );
                            988 ;	genRet
   0EF3 75 82 01            989 	mov	dpl,#0x01
                            990 ;	Peephole 112.b	changed ljmp to sjmp
                    0092    991 	C$iconv.c$91$1$1 ==.
                            992 ;	C:/SDCC/GPSMon/dev/iconv.c:91: return( FALSE );
                            993 ;	genRet
                    0092    994 	C$iconv.c$93$1$1 ==.
                    0092    995 	XG$AsciiToUnsigned$0$0 ==.
                            996 ;	Peephole 237.a	removed sjmp to ret
   0EF6 22                  997 	ret
   0EF7                     998 00114$:
   0EF7 75 82 00            999 	mov	dpl,#0x00
                           1000 ;	Peephole 300	removed redundant label 00117$
   0EFA 22                 1001 	ret
                           1002 ;------------------------------------------------------------
                           1003 ;Allocation info for local variables in function 'UnsignedToAscii'
                           1004 ;------------------------------------------------------------
                           1005 ;pbuf                      Allocated with name '_UnsignedToAscii_PARM_2'
                           1006 ;nbdigits                  Allocated with name '_UnsignedToAscii_PARM_3'
                           1007 ;value                     Allocated to registers r2 r3 
                           1008 ;ndx                       Allocated to registers r5 
                           1009 ;remainder                 Allocated to registers r1 r4 
                           1010 ;result                    Allocated to registers r7 r0 
                           1011 ;------------------------------------------------------------
                    0097   1012 	G$UnsignedToAscii$0$0 ==.
                    0097   1013 	C$iconv.c$102$1$1 ==.
                           1014 ;	C:/SDCC/GPSMon/dev/iconv.c:102: void UnsignedToAscii( uint value, 
                           1015 ;	-----------------------------------------
                           1016 ;	 function UnsignedToAscii
                           1017 ;	-----------------------------------------
   0EFB                    1018 _UnsignedToAscii:
                           1019 ;	genReceive
   0EFB AA 82              1020 	mov	r2,dpl
   0EFD AB 83              1021 	mov	r3,dph
                    009B   1022 	C$iconv.c$109$1$1 ==.
                           1023 ;	C:/SDCC/GPSMon/dev/iconv.c:109: ndx = nbdigits;
                           1024 ;	genAssign
                    009B   1025 	C$iconv.c$111$1$1 ==.
                           1026 ;	C:/SDCC/GPSMon/dev/iconv.c:111: *(pbuf+ndx--) = '\0';
                           1027 ;	genMinus
                           1028 ;	genMinusDec
   0EFF E5 1D              1029 	mov	a,_UnsignedToAscii_PARM_3
   0F01 14                 1030 	dec	a
   0F02 FD                 1031 	mov	r5,a
                           1032 ;	genPlus
   0F03 E5 1D              1033 	mov	a,_UnsignedToAscii_PARM_3
   0F05 25 1B              1034 	add	a,_UnsignedToAscii_PARM_2
   0F07 F5 82              1035 	mov	dpl,a
                           1036 ;	Peephole 181	changed mov to clr
   0F09 E4                 1037 	clr	a
   0F0A 35 1C              1038 	addc	a,(_UnsignedToAscii_PARM_2 + 1)
   0F0C F5 83              1039 	mov	dph,a
                           1040 ;	genPointerSet
                           1041 ;     genFarPointerSet
                           1042 ;	Peephole 181	changed mov to clr
   0F0E E4                 1043 	clr	a
   0F0F F0                 1044 	movx	@dptr,a
                           1045 ;	genAssign
   0F10 8D 06              1046 	mov	ar6,r5
   0F12                    1047 00103$:
                    00AE   1048 	C$iconv.c$112$1$1 ==.
                           1049 ;	C:/SDCC/GPSMon/dev/iconv.c:112: for( ; ndx>=0; ndx-- ){
                           1050 ;	genCmpLt
                           1051 ;	genCmp
   0F12 EE                 1052 	mov	a,r6
                           1053 ;	genIfxJump
                           1054 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0F13 20 E7 63           1055 	jb	acc.7,00106$
                           1056 ;	Peephole 300	removed redundant label 00129$
                    00B2   1057 	C$iconv.c$113$1$1 ==.
                           1058 ;	C:/SDCC/GPSMon/dev/iconv.c:113: result = value / 10;
                           1059 ;	genAssign
   0F16 75 46 0A           1060 	mov	__divuint_PARM_2,#0x0A
   0F19 E4                 1061 	clr	a
   0F1A F5 47              1062 	mov	(__divuint_PARM_2 + 1),a
                           1063 ;	genCall
   0F1C 8A 82              1064 	mov	dpl,r2
   0F1E 8B 83              1065 	mov	dph,r3
   0F20 C0 02              1066 	push	ar2
   0F22 C0 03              1067 	push	ar3
   0F24 C0 06              1068 	push	ar6
   0F26 12 11 6D           1069 	lcall	__divuint
   0F29 AF 82              1070 	mov	r7,dpl
   0F2B A8 83              1071 	mov	r0,dph
   0F2D D0 06              1072 	pop	ar6
   0F2F D0 03              1073 	pop	ar3
   0F31 D0 02              1074 	pop	ar2
                    00CF   1075 	C$iconv.c$114$1$1 ==.
                           1076 ;	C:/SDCC/GPSMon/dev/iconv.c:114: remainder = value - ( 10 * result );
                           1077 ;	genAssign
   0F33 75 46 0A           1078 	mov	__mulint_PARM_2,#0x0A
   0F36 E4                 1079 	clr	a
   0F37 F5 47              1080 	mov	(__mulint_PARM_2 + 1),a
                           1081 ;	genCall
   0F39 8F 82              1082 	mov	dpl,r7
   0F3B 88 83              1083 	mov	dph,r0
   0F3D C0 02              1084 	push	ar2
   0F3F C0 03              1085 	push	ar3
   0F41 C0 06              1086 	push	ar6
   0F43 C0 07              1087 	push	ar7
   0F45 C0 00              1088 	push	ar0
   0F47 12 12 E9           1089 	lcall	__mulint
   0F4A A9 82              1090 	mov	r1,dpl
   0F4C AC 83              1091 	mov	r4,dph
   0F4E D0 00              1092 	pop	ar0
   0F50 D0 07              1093 	pop	ar7
   0F52 D0 06              1094 	pop	ar6
   0F54 D0 03              1095 	pop	ar3
   0F56 D0 02              1096 	pop	ar2
                           1097 ;	genMinus
   0F58 EA                 1098 	mov	a,r2
   0F59 C3                 1099 	clr	c
                           1100 ;	Peephole 236.l	used r1 instead of ar1
   0F5A 99                 1101 	subb	a,r1
   0F5B F9                 1102 	mov	r1,a
   0F5C EB                 1103 	mov	a,r3
                           1104 ;	Peephole 236.l	used r4 instead of ar4
   0F5D 9C                 1105 	subb	a,r4
   0F5E FC                 1106 	mov	r4,a
                    00FB   1107 	C$iconv.c$115$2$2 ==.
                           1108 ;	C:/SDCC/GPSMon/dev/iconv.c:115: value = result;
                           1109 ;	genAssign
   0F5F 8F 02              1110 	mov	ar2,r7
   0F61 88 03              1111 	mov	ar3,r0
                    00FF   1112 	C$iconv.c$116$2$2 ==.
                           1113 ;	C:/SDCC/GPSMon/dev/iconv.c:116: *(pbuf+ndx) = ( remainder | '0' );
                           1114 ;	genPlus
                           1115 ;	Peephole 236.g	used r6 instead of ar6
   0F63 EE                 1116 	mov	a,r6
   0F64 25 1B              1117 	add	a,_UnsignedToAscii_PARM_2
   0F66 F5 82              1118 	mov	dpl,a
                           1119 ;	Peephole 181	changed mov to clr
   0F68 E4                 1120 	clr	a
   0F69 35 1C              1121 	addc	a,(_UnsignedToAscii_PARM_2 + 1)
   0F6B F5 83              1122 	mov	dph,a
                           1123 ;	genOr
   0F6D 43 01 30           1124 	orl	ar1,#0x30
                           1125 ;	genCast
                           1126 ;	genPointerSet
                           1127 ;     genFarPointerSet
   0F70 E9                 1128 	mov	a,r1
   0F71 F0                 1129 	movx	@dptr,a
                    010E   1130 	C$iconv.c$117$2$2 ==.
                           1131 ;	C:/SDCC/GPSMon/dev/iconv.c:117: if( value == 0 )
                           1132 ;	genIfx
   0F72 EA                 1133 	mov	a,r2
   0F73 4B                 1134 	orl	a,r3
                           1135 ;	genIfxJump
                           1136 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0F74 60 03              1137 	jz	00106$
                           1138 ;	Peephole 300	removed redundant label 00130$
                    0112   1139 	C$iconv.c$112$1$1 ==.
                           1140 ;	C:/SDCC/GPSMon/dev/iconv.c:112: for( ; ndx>=0; ndx-- ){
                           1141 ;	genMinus
                           1142 ;	genMinusDec
   0F76 1E                 1143 	dec	r6
                           1144 ;	Peephole 112.b	changed ljmp to sjmp
   0F77 80 99              1145 	sjmp	00103$
   0F79                    1146 00106$:
                    0115   1147 	C$iconv.c$120$1$1 ==.
                           1148 ;	C:/SDCC/GPSMon/dev/iconv.c:120: if( value > 0 ){
                           1149 ;	genIfx
   0F79 EA                 1150 	mov	a,r2
   0F7A 4B                 1151 	orl	a,r3
                           1152 ;	genIfxJump
                           1153 ;	Peephole 108.c	removed ljmp by inverse jump logic
   0F7B 60 1B              1154 	jz	00108$
                           1155 ;	Peephole 300	removed redundant label 00131$
                    0119   1156 	C$iconv.c$122$2$3 ==.
                           1157 ;	C:/SDCC/GPSMon/dev/iconv.c:122: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1158 ;	genMinus
                           1159 ;	genMinusDec
   0F7D E5 1D              1160 	mov	a,_UnsignedToAscii_PARM_3
   0F7F 14                 1161 	dec	a
   0F80 FD                 1162 	mov	r5,a
                           1163 ;	genAssign
   0F81 8D 02              1164 	mov	ar2,r5
   0F83                    1165 00112$:
                           1166 ;	genCmpLt
                           1167 ;	genCmp
   0F83 EA                 1168 	mov	a,r2
                           1169 ;	genIfxJump
                           1170 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0F84 20 E7 10           1171 	jb	acc.7,00115$
                           1172 ;	Peephole 300	removed redundant label 00132$
                    0123   1173 	C$iconv.c$123$2$3 ==.
                           1174 ;	C:/SDCC/GPSMon/dev/iconv.c:123: *(pbuf+ndx) = '?';
                           1175 ;	genPlus
                           1176 ;	Peephole 236.g	used r2 instead of ar2
   0F87 EA                 1177 	mov	a,r2
   0F88 25 1B              1178 	add	a,_UnsignedToAscii_PARM_2
   0F8A F5 82              1179 	mov	dpl,a
                           1180 ;	Peephole 181	changed mov to clr
   0F8C E4                 1181 	clr	a
   0F8D 35 1C              1182 	addc	a,(_UnsignedToAscii_PARM_2 + 1)
   0F8F F5 83              1183 	mov	dph,a
                           1184 ;	genPointerSet
                           1185 ;     genFarPointerSet
   0F91 74 3F              1186 	mov	a,#0x3F
   0F93 F0                 1187 	movx	@dptr,a
                    0130   1188 	C$iconv.c$122$2$3 ==.
                           1189 ;	C:/SDCC/GPSMon/dev/iconv.c:122: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1190 ;	genMinus
                           1191 ;	genMinusDec
   0F94 1A                 1192 	dec	r2
                           1193 ;	Peephole 112.b	changed ljmp to sjmp
   0F95 80 EC              1194 	sjmp	00112$
   0F97                    1195 00115$:
                    0133   1196 	C$iconv.c$124$2$3 ==.
                           1197 ;	C:/SDCC/GPSMon/dev/iconv.c:124: return;
                           1198 ;	genRet
                           1199 ;	Peephole 112.b	changed ljmp to sjmp
                           1200 ;	Peephole 251.b	replaced sjmp to ret with ret
   0F97 22                 1201 	ret
   0F98                    1202 00108$:
                    0134   1203 	C$iconv.c$128$1$1 ==.
                           1204 ;	C:/SDCC/GPSMon/dev/iconv.c:128: ndx--;
                           1205 ;	genMinus
                           1206 ;	genMinusDec
   0F98 EE                 1207 	mov	a,r6
   0F99 14                 1208 	dec	a
   0F9A FD                 1209 	mov	r5,a
                    0137   1210 	C$iconv.c$129$1$1 ==.
                           1211 ;	C:/SDCC/GPSMon/dev/iconv.c:129: while( ndx >= 0 )
                           1212 ;	genAssign
   0F9B 8D 02              1213 	mov	ar2,r5
   0F9D                    1214 00109$:
                           1215 ;	genCmpLt
                           1216 ;	genCmp
   0F9D EA                 1217 	mov	a,r2
                           1218 ;	genIfxJump
                           1219 ;	Peephole 108.e	removed ljmp by inverse jump logic
   0F9E 20 E7 12           1220 	jb	acc.7,00116$
                           1221 ;	Peephole 300	removed redundant label 00133$
                    013D   1222 	C$iconv.c$130$1$1 ==.
                           1223 ;	C:/SDCC/GPSMon/dev/iconv.c:130: *(pbuf+ndx--) = ' ';
                           1224 ;	genAssign
   0FA1 8A 03              1225 	mov	ar3,r2
                           1226 ;	genMinus
                           1227 ;	genMinusDec
   0FA3 1A                 1228 	dec	r2
                           1229 ;	genPlus
                           1230 ;	Peephole 236.g	used r3 instead of ar3
   0FA4 EB                 1231 	mov	a,r3
   0FA5 25 1B              1232 	add	a,_UnsignedToAscii_PARM_2
   0FA7 F5 82              1233 	mov	dpl,a
                           1234 ;	Peephole 181	changed mov to clr
   0FA9 E4                 1235 	clr	a
   0FAA 35 1C              1236 	addc	a,(_UnsignedToAscii_PARM_2 + 1)
   0FAC F5 83              1237 	mov	dph,a
                           1238 ;	genPointerSet
                           1239 ;     genFarPointerSet
   0FAE 74 20              1240 	mov	a,#0x20
   0FB0 F0                 1241 	movx	@dptr,a
                           1242 ;	Peephole 112.b	changed ljmp to sjmp
   0FB1 80 EA              1243 	sjmp	00109$
   0FB3                    1244 00116$:
                    014F   1245 	C$iconv.c$132$1$1 ==.
                    014F   1246 	XG$UnsignedToAscii$0$0 ==.
   0FB3 22                 1247 	ret
                           1248 ;------------------------------------------------------------
                           1249 ;Allocation info for local variables in function 'CharToAscii'
                           1250 ;------------------------------------------------------------
                           1251 ;pbuf                      Allocated with name '_CharToAscii_PARM_2'
                           1252 ;nbdigits                  Allocated with name '_CharToAscii_PARM_3'
                           1253 ;value                     Allocated to registers r2 
                           1254 ;remainder                 Allocated to registers r0 
                           1255 ;result                    Allocated to registers r7 
                           1256 ;ndx                       Allocated to registers r4 
                           1257 ;sign                      Allocated to registers r5 
                           1258 ;------------------------------------------------------------
                    0150   1259 	G$CharToAscii$0$0 ==.
                    0150   1260 	C$iconv.c$183$1$1 ==.
                           1261 ;	C:/SDCC/GPSMon/dev/iconv.c:183: void CharToAscii( char value, 
                           1262 ;	-----------------------------------------
                           1263 ;	 function CharToAscii
                           1264 ;	-----------------------------------------
   0FB4                    1265 _CharToAscii:
                           1266 ;	genReceive
   0FB4 AA 82              1267 	mov	r2,dpl
                    0152   1268 	C$iconv.c$190$1$1 ==.
                           1269 ;	C:/SDCC/GPSMon/dev/iconv.c:190: ndx = nbdigits;
                           1270 ;	genAssign
   0FB6 AB 48              1271 	mov	r3,_CharToAscii_PARM_3
                           1272 ;	genAssign
   0FB8 8B 04              1273 	mov	ar4,r3
                    0156   1274 	C$iconv.c$192$1$1 ==.
                           1275 ;	C:/SDCC/GPSMon/dev/iconv.c:192: if( value < 0 ){
                           1276 ;	genCmpLt
                           1277 ;	genCmp
   0FBA EA                 1278 	mov	a,r2
                           1279 ;	genIfxJump
                           1280 ;	Peephole 108.d	removed ljmp by inverse jump logic
   0FBB 30 E7 08           1281 	jnb	acc.7,00102$
                           1282 ;	Peephole 300	removed redundant label 00147$
                    015A   1283 	C$iconv.c$193$2$2 ==.
                           1284 ;	C:/SDCC/GPSMon/dev/iconv.c:193: value = -value;
                           1285 ;	genUminus
   0FBE C3                 1286 	clr	c
   0FBF E4                 1287 	clr	a
   0FC0 9A                 1288 	subb	a,r2
   0FC1 FA                 1289 	mov	r2,a
                    015E   1290 	C$iconv.c$194$2$2 ==.
                           1291 ;	C:/SDCC/GPSMon/dev/iconv.c:194: sign = -1;
                           1292 ;	genAssign
   0FC2 7D FF              1293 	mov	r5,#0xFF
                           1294 ;	Peephole 112.b	changed ljmp to sjmp
   0FC4 80 02              1295 	sjmp	00103$
   0FC6                    1296 00102$:
                    0162   1297 	C$iconv.c$196$1$1 ==.
                           1298 ;	C:/SDCC/GPSMon/dev/iconv.c:196: sign = 1;
                           1299 ;	genAssign
   0FC6 7D 01              1300 	mov	r5,#0x01
   0FC8                    1301 00103$:
                    0164   1302 	C$iconv.c$198$1$1 ==.
                           1303 ;	C:/SDCC/GPSMon/dev/iconv.c:198: *(pbuf+ndx--) = '\0';
                           1304 ;	genAssign
   0FC8 8C 06              1305 	mov	ar6,r4
                           1306 ;	genMinus
                           1307 ;	genMinusDec
   0FCA 1C                 1308 	dec	r4
                           1309 ;	genPlus
                           1310 ;	Peephole 236.g	used r6 instead of ar6
   0FCB EE                 1311 	mov	a,r6
   0FCC 25 46              1312 	add	a,_CharToAscii_PARM_2
   0FCE F5 82              1313 	mov	dpl,a
                           1314 ;	Peephole 181	changed mov to clr
   0FD0 E4                 1315 	clr	a
   0FD1 35 47              1316 	addc	a,(_CharToAscii_PARM_2 + 1)
   0FD3 F5 83              1317 	mov	dph,a
                           1318 ;	genPointerSet
                           1319 ;     genFarPointerSet
                           1320 ;	Peephole 181	changed mov to clr
   0FD5 E4                 1321 	clr	a
   0FD6 F0                 1322 	movx	@dptr,a
                           1323 ;	genAssign
   0FD7 8C 06              1324 	mov	ar6,r4
   0FD9                    1325 00106$:
                    0175   1326 	C$iconv.c$199$1$1 ==.
                           1327 ;	C:/SDCC/GPSMon/dev/iconv.c:199: for( ; ndx>0; ndx-- ){
                           1328 ;	genCmpGt
                           1329 ;	genCmp
   0FD9 C3                 1330 	clr	c
                           1331 ;	Peephole 159	avoided xrl during execution
   0FDA 74 80              1332 	mov	a,#(0x00 ^ 0x80)
   0FDC 8E F0              1333 	mov	b,r6
   0FDE 63 F0 80           1334 	xrl	b,#0x80
   0FE1 95 F0              1335 	subb	a,b
                           1336 ;	genIfxJump
                           1337 ;	Peephole 108.a	removed ljmp by inverse jump logic
   0FE3 50 33              1338 	jnc	00109$
                           1339 ;	Peephole 300	removed redundant label 00148$
                    0181   1340 	C$iconv.c$200$2$3 ==.
                           1341 ;	C:/SDCC/GPSMon/dev/iconv.c:200: result = value / 10;
                           1342 ;	genDiv
                           1343 ;     genDivOneByte
   0FE5 C2 D5              1344 	clr	F0
   0FE7 75 F0 0A           1345 	mov	b,#0x0a
   0FEA EA                 1346 	mov	a,r2
   0FEB 30 E7 04           1347 	jnb	acc.7,00149$
   0FEE B2 D5              1348 	cpl	F0
   0FF0 F4                 1349 	cpl	a
   0FF1 04                 1350 	inc	a
   0FF2                    1351 00149$:
   0FF2 84                 1352 	div	ab
   0FF3 30 D5 02           1353 	jnb	F0,00150$
   0FF6 F4                 1354 	cpl	a
   0FF7 04                 1355 	inc	a
   0FF8                    1356 00150$:
                    0194   1357 	C$iconv.c$201$2$3 ==.
                           1358 ;	C:/SDCC/GPSMon/dev/iconv.c:201: remainder = value - ( 10 * result );
                           1359 ;	genMult
                           1360 ;	genMultOneByte
   0FF8 FF                 1361 	mov	r7,a
                           1362 ;	Peephole 105	removed redundant mov
   0FF9 75 F0 0A           1363 	mov	b,#0x0A
   0FFC A4                 1364 	mul	ab
                           1365 ;	genMinus
   0FFD D3                 1366 	setb	c
                           1367 ;	Peephole 236.l	used r2 instead of ar2
   0FFE 9A                 1368 	subb	a,r2
   0FFF F4                 1369 	cpl	a
   1000 F8                 1370 	mov	r0,a
                    019D   1371 	C$iconv.c$202$2$3 ==.
                           1372 ;	C:/SDCC/GPSMon/dev/iconv.c:202: value = result;
                           1373 ;	genAssign
   1001 8F 02              1374 	mov	ar2,r7
                    019F   1375 	C$iconv.c$203$2$3 ==.
                           1376 ;	C:/SDCC/GPSMon/dev/iconv.c:203: *(pbuf+ndx) = ( remainder + '0' );
                           1377 ;	genPlus
                           1378 ;	Peephole 236.g	used r6 instead of ar6
   1003 EE                 1379 	mov	a,r6
   1004 25 46              1380 	add	a,_CharToAscii_PARM_2
   1006 F5 82              1381 	mov	dpl,a
                           1382 ;	Peephole 181	changed mov to clr
   1008 E4                 1383 	clr	a
   1009 35 47              1384 	addc	a,(_CharToAscii_PARM_2 + 1)
   100B F5 83              1385 	mov	dph,a
                           1386 ;	genPlus
                           1387 ;     genPlusIncr
   100D 74 30              1388 	mov	a,#0x30
                           1389 ;	Peephole 236.a	used r0 instead of ar0
   100F 28                 1390 	add	a,r0
                           1391 ;	genPointerSet
                           1392 ;     genFarPointerSet
   1010 F8                 1393 	mov	r0,a
                           1394 ;	Peephole 105	removed redundant mov
   1011 F0                 1395 	movx	@dptr,a
                    01AE   1396 	C$iconv.c$204$2$3 ==.
                           1397 ;	C:/SDCC/GPSMon/dev/iconv.c:204: if( value == 0 )
                           1398 ;	genIfx
   1012 EA                 1399 	mov	a,r2
                           1400 ;	genIfxJump
                           1401 ;	Peephole 108.c	removed ljmp by inverse jump logic
   1013 60 03              1402 	jz	00109$
                           1403 ;	Peephole 300	removed redundant label 00151$
                    01B1   1404 	C$iconv.c$199$1$1 ==.
                           1405 ;	C:/SDCC/GPSMon/dev/iconv.c:199: for( ; ndx>0; ndx-- ){
                           1406 ;	genMinus
                           1407 ;	genMinusDec
   1015 1E                 1408 	dec	r6
                           1409 ;	Peephole 112.b	changed ljmp to sjmp
   1016 80 C1              1410 	sjmp	00106$
   1018                    1411 00109$:
                    01B4   1412 	C$iconv.c$209$1$1 ==.
                           1413 ;	C:/SDCC/GPSMon/dev/iconv.c:209: if( value > 0 ){
                           1414 ;	genCmpGt
                           1415 ;	genCmp
   1018 C3                 1416 	clr	c
                           1417 ;	Peephole 159	avoided xrl during execution
   1019 74 80              1418 	mov	a,#(0x00 ^ 0x80)
   101B 8A F0              1419 	mov	b,r2
   101D 63 F0 80           1420 	xrl	b,#0x80
   1020 95 F0              1421 	subb	a,b
                           1422 ;	genIfxJump
                           1423 ;	Peephole 108.a	removed ljmp by inverse jump logic
   1022 50 1A              1424 	jnc	00111$
                           1425 ;	Peephole 300	removed redundant label 00152$
                    01C0   1426 	C$iconv.c$210$2$4 ==.
                           1427 ;	C:/SDCC/GPSMon/dev/iconv.c:210: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1428 ;	genMinus
                           1429 ;	genMinusDec
   1024 EB                 1430 	mov	a,r3
   1025 14                 1431 	dec	a
   1026 FC                 1432 	mov	r4,a
                           1433 ;	genAssign
   1027 8C 02              1434 	mov	ar2,r4
   1029                    1435 00120$:
                           1436 ;	genCmpLt
                           1437 ;	genCmp
   1029 EA                 1438 	mov	a,r2
                           1439 ;	genIfxJump
                           1440 ;	Peephole 108.e	removed ljmp by inverse jump logic
   102A 20 E7 10           1441 	jb	acc.7,00123$
                           1442 ;	Peephole 300	removed redundant label 00153$
                    01C9   1443 	C$iconv.c$211$2$4 ==.
                           1444 ;	C:/SDCC/GPSMon/dev/iconv.c:211: *(pbuf+ndx) = '?';
                           1445 ;	genPlus
                           1446 ;	Peephole 236.g	used r2 instead of ar2
   102D EA                 1447 	mov	a,r2
   102E 25 46              1448 	add	a,_CharToAscii_PARM_2
   1030 F5 82              1449 	mov	dpl,a
                           1450 ;	Peephole 181	changed mov to clr
   1032 E4                 1451 	clr	a
   1033 35 47              1452 	addc	a,(_CharToAscii_PARM_2 + 1)
   1035 F5 83              1453 	mov	dph,a
                           1454 ;	genPointerSet
                           1455 ;     genFarPointerSet
   1037 74 3F              1456 	mov	a,#0x3F
   1039 F0                 1457 	movx	@dptr,a
                    01D6   1458 	C$iconv.c$210$2$4 ==.
                           1459 ;	C:/SDCC/GPSMon/dev/iconv.c:210: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1460 ;	genMinus
                           1461 ;	genMinusDec
   103A 1A                 1462 	dec	r2
                           1463 ;	Peephole 112.b	changed ljmp to sjmp
   103B 80 EC              1464 	sjmp	00120$
   103D                    1465 00123$:
                    01D9   1466 	C$iconv.c$212$2$4 ==.
                           1467 ;	C:/SDCC/GPSMon/dev/iconv.c:212: return;
                           1468 ;	genRet
                           1469 ;	Peephole 112.b	changed ljmp to sjmp
                           1470 ;	Peephole 251.b	replaced sjmp to ret with ret
   103D 22                 1471 	ret
   103E                    1472 00111$:
                    01DA   1473 	C$iconv.c$215$1$1 ==.
                           1474 ;	C:/SDCC/GPSMon/dev/iconv.c:215: ndx--;
                           1475 ;	genMinus
                           1476 ;	genMinusDec
   103E EE                 1477 	mov	a,r6
   103F 14                 1478 	dec	a
   1040 FC                 1479 	mov	r4,a
                    01DD   1480 	C$iconv.c$217$1$1 ==.
                           1481 ;	C:/SDCC/GPSMon/dev/iconv.c:217: if( sign == -1 ){
                           1482 ;	genCmpEq
                           1483 ;	gencjneshort
                           1484 ;	Peephole 112.b	changed ljmp to sjmp
                           1485 ;	Peephole 198.b	optimized misc jump sequence
   1041 BD FF 38           1486 	cjne	r5,#0xFF,00142$
                           1487 ;	Peephole 200.b	removed redundant sjmp
                           1488 ;	Peephole 300	removed redundant label 00154$
                           1489 ;	Peephole 300	removed redundant label 00155$
                    01E0   1490 	C$iconv.c$218$2$5 ==.
                           1491 ;	C:/SDCC/GPSMon/dev/iconv.c:218: if( ndx > 0 )
                           1492 ;	genCmpGt
                           1493 ;	genCmp
   1044 C3                 1494 	clr	c
                           1495 ;	Peephole 159	avoided xrl during execution
   1045 74 80              1496 	mov	a,#(0x00 ^ 0x80)
   1047 8C F0              1497 	mov	b,r4
   1049 63 F0 80           1498 	xrl	b,#0x80
   104C 95 F0              1499 	subb	a,b
                           1500 ;	genIfxJump
                           1501 ;	Peephole 108.a	removed ljmp by inverse jump logic
   104E 50 12              1502 	jnc	00113$
                           1503 ;	Peephole 300	removed redundant label 00156$
                    01EC   1504 	C$iconv.c$219$2$5 ==.
                           1505 ;	C:/SDCC/GPSMon/dev/iconv.c:219: *(pbuf+ndx--) = '-';
                           1506 ;	genAssign
   1050 8C 02              1507 	mov	ar2,r4
                           1508 ;	genMinus
                           1509 ;	genMinusDec
   1052 1C                 1510 	dec	r4
                           1511 ;	genPlus
                           1512 ;	Peephole 236.g	used r2 instead of ar2
   1053 EA                 1513 	mov	a,r2
   1054 25 46              1514 	add	a,_CharToAscii_PARM_2
   1056 F5 82              1515 	mov	dpl,a
                           1516 ;	Peephole 181	changed mov to clr
   1058 E4                 1517 	clr	a
   1059 35 47              1518 	addc	a,(_CharToAscii_PARM_2 + 1)
   105B F5 83              1519 	mov	dph,a
                           1520 ;	genPointerSet
                           1521 ;     genFarPointerSet
   105D 74 2D              1522 	mov	a,#0x2D
   105F F0                 1523 	movx	@dptr,a
                           1524 ;	Peephole 112.b	changed ljmp to sjmp
   1060 80 1A              1525 	sjmp	00142$
   1062                    1526 00113$:
                    01FE   1527 	C$iconv.c$221$3$6 ==.
                           1528 ;	C:/SDCC/GPSMon/dev/iconv.c:221: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1529 ;	genMinus
                           1530 ;	genMinusDec
   1062 EB                 1531 	mov	a,r3
   1063 14                 1532 	dec	a
   1064 FC                 1533 	mov	r4,a
                           1534 ;	genAssign
   1065 8C 02              1535 	mov	ar2,r4
   1067                    1536 00124$:
                           1537 ;	genCmpLt
                           1538 ;	genCmp
   1067 EA                 1539 	mov	a,r2
                           1540 ;	genIfxJump
                           1541 ;	Peephole 108.e	removed ljmp by inverse jump logic
   1068 20 E7 10           1542 	jb	acc.7,00127$
                           1543 ;	Peephole 300	removed redundant label 00157$
                    0207   1544 	C$iconv.c$222$3$6 ==.
                           1545 ;	C:/SDCC/GPSMon/dev/iconv.c:222: *(pbuf+ndx) = '?';
                           1546 ;	genPlus
                           1547 ;	Peephole 236.g	used r2 instead of ar2
   106B EA                 1548 	mov	a,r2
   106C 25 46              1549 	add	a,_CharToAscii_PARM_2
   106E F5 82              1550 	mov	dpl,a
                           1551 ;	Peephole 181	changed mov to clr
   1070 E4                 1552 	clr	a
   1071 35 47              1553 	addc	a,(_CharToAscii_PARM_2 + 1)
   1073 F5 83              1554 	mov	dph,a
                           1555 ;	genPointerSet
                           1556 ;     genFarPointerSet
   1075 74 3F              1557 	mov	a,#0x3F
   1077 F0                 1558 	movx	@dptr,a
                    0214   1559 	C$iconv.c$221$3$6 ==.
                           1560 ;	C:/SDCC/GPSMon/dev/iconv.c:221: for( ndx=nbdigits-1; ndx>=0; --ndx )
                           1561 ;	genMinus
                           1562 ;	genMinusDec
   1078 1A                 1563 	dec	r2
                           1564 ;	Peephole 112.b	changed ljmp to sjmp
   1079 80 EC              1565 	sjmp	00124$
   107B                    1566 00127$:
                    0217   1567 	C$iconv.c$223$3$6 ==.
                           1568 ;	C:/SDCC/GPSMon/dev/iconv.c:223: return;
                           1569 ;	genRet
                    0217   1570 	C$iconv.c$227$1$1 ==.
                           1571 ;	C:/SDCC/GPSMon/dev/iconv.c:227: while( ndx >= 0 )
                           1572 ;	Peephole 112.b	changed ljmp to sjmp
                           1573 ;	Peephole 251.b	replaced sjmp to ret with ret
   107B 22                 1574 	ret
   107C                    1575 00142$:
                           1576 ;	genAssign
   107C 8C 02              1577 	mov	ar2,r4
   107E                    1578 00117$:
                           1579 ;	genCmpLt
                           1580 ;	genCmp
   107E EA                 1581 	mov	a,r2
                           1582 ;	genIfxJump
                           1583 ;	Peephole 108.e	removed ljmp by inverse jump logic
   107F 20 E7 12           1584 	jb	acc.7,00128$
                           1585 ;	Peephole 300	removed redundant label 00158$
                    021E   1586 	C$iconv.c$228$1$1 ==.
                           1587 ;	C:/SDCC/GPSMon/dev/iconv.c:228: *(pbuf+ndx--) = ' ';
                           1588 ;	genAssign
   1082 8A 03              1589 	mov	ar3,r2
                           1590 ;	genMinus
                           1591 ;	genMinusDec
   1084 1A                 1592 	dec	r2
                           1593 ;	genPlus
                           1594 ;	Peephole 236.g	used r3 instead of ar3
   1085 EB                 1595 	mov	a,r3
   1086 25 46              1596 	add	a,_CharToAscii_PARM_2
   1088 F5 82              1597 	mov	dpl,a
                           1598 ;	Peephole 181	changed mov to clr
   108A E4                 1599 	clr	a
   108B 35 47              1600 	addc	a,(_CharToAscii_PARM_2 + 1)
   108D F5 83              1601 	mov	dph,a
                           1602 ;	genPointerSet
                           1603 ;     genFarPointerSet
   108F 74 20              1604 	mov	a,#0x20
   1091 F0                 1605 	movx	@dptr,a
                           1606 ;	Peephole 112.b	changed ljmp to sjmp
   1092 80 EA              1607 	sjmp	00117$
   1094                    1608 00128$:
                    0230   1609 	C$iconv.c$230$1$1 ==.
                    0230   1610 	XG$CharToAscii$0$0 ==.
   1094 22                 1611 	ret
                           1612 	.area CSEG    (CODE)
                           1613 	.area CONST   (CODE)
                           1614 	.area XINIT   (CODE)
