                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.0 #4309 (Jul 28 2006)
                              4 ; This file generated Sun Apr 08 20:34:08 2012
                              5 ;--------------------------------------------------------
                              6 	.module Extdebug
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _Fault_Msg_Query_PARM_3
                             13 	.globl _Fault_Msg_Query_PARM_2
                             14 	.globl _ALARM_MSG
                             15 	.globl _SPIF
                             16 	.globl _WCOL
                             17 	.globl _MODF
                             18 	.globl _RXOVRN
                             19 	.globl _NSSMD1
                             20 	.globl _NSSMD0
                             21 	.globl _TXBMT
                             22 	.globl _SPIEN
                             23 	.globl _AD0EN
                             24 	.globl _AD0TM
                             25 	.globl _AD0INT
                             26 	.globl _AD0BUSY
                             27 	.globl _AD0WINT
                             28 	.globl _AD0CM2
                             29 	.globl _AD0CM1
                             30 	.globl _AD0CM0
                             31 	.globl _CF
                             32 	.globl _CR
                             33 	.globl _CCF2
                             34 	.globl _CCF1
                             35 	.globl _CCF0
                             36 	.globl _CY
                             37 	.globl _AC
                             38 	.globl _F0
                             39 	.globl _RS1
                             40 	.globl _RS0
                             41 	.globl _OV
                             42 	.globl _F1
                             43 	.globl _PARITY
                             44 	.globl _TF2H
                             45 	.globl _TF2
                             46 	.globl _TF2L
                             47 	.globl _TF2LEN
                             48 	.globl _TF2CEN
                             49 	.globl _T2SPLIT
                             50 	.globl _TR2
                             51 	.globl _T2XCLK
                             52 	.globl _MASTER
                             53 	.globl _TXMODE
                             54 	.globl _STA
                             55 	.globl _STO
                             56 	.globl _ACKRQ
                             57 	.globl _ARBLOST
                             58 	.globl _ACK
                             59 	.globl _SI
                             60 	.globl _PSPI0
                             61 	.globl _PT2
                             62 	.globl _PS0
                             63 	.globl _PS
                             64 	.globl _PT1
                             65 	.globl _PX1
                             66 	.globl _PT0
                             67 	.globl _PX0
                             68 	.globl _EA
                             69 	.globl _ESPI0
                             70 	.globl _ET2
                             71 	.globl _ES0
                             72 	.globl _ES
                             73 	.globl _ET1
                             74 	.globl _EX1
                             75 	.globl _ET0
                             76 	.globl _EX0
                             77 	.globl _P2_7
                             78 	.globl _P2_6
                             79 	.globl _P2_5
                             80 	.globl _P2_4
                             81 	.globl _P2_3
                             82 	.globl _P2_2
                             83 	.globl _P2_1
                             84 	.globl _P2_0
                             85 	.globl _S0MODE
                             86 	.globl _SM0
                             87 	.globl _MCE0
                             88 	.globl _SM2
                             89 	.globl _REN0
                             90 	.globl _REN
                             91 	.globl _TB80
                             92 	.globl _TB8
                             93 	.globl _RB80
                             94 	.globl _RB8
                             95 	.globl _TI0
                             96 	.globl _TI
                             97 	.globl _RI0
                             98 	.globl _RI
                             99 	.globl _P1_7
                            100 	.globl _P1_6
                            101 	.globl _P1_5
                            102 	.globl _P1_4
                            103 	.globl _P1_3
                            104 	.globl _P1_2
                            105 	.globl _P1_1
                            106 	.globl _P1_0
                            107 	.globl _TF1
                            108 	.globl _TR1
                            109 	.globl _TF0
                            110 	.globl _TR0
                            111 	.globl _IE1
                            112 	.globl _IT1
                            113 	.globl _IE0
                            114 	.globl _IT0
                            115 	.globl _P0_7
                            116 	.globl _P0_6
                            117 	.globl _P0_5
                            118 	.globl _P0_4
                            119 	.globl _P0_3
                            120 	.globl _P0_2
                            121 	.globl _P0_1
                            122 	.globl _P0_0
                            123 	.globl _PCA0CP2
                            124 	.globl _PCA0CP1
                            125 	.globl _PCA0CP0
                            126 	.globl _PCA0
                            127 	.globl _ADC0LT
                            128 	.globl _ADC0GT
                            129 	.globl _ADC0
                            130 	.globl _IDA0
                            131 	.globl _TMR3RL
                            132 	.globl _TMR3
                            133 	.globl _TMR2RL
                            134 	.globl _RCAP2
                            135 	.globl _TMR2
                            136 	.globl _TMR1
                            137 	.globl _TMR0
                            138 	.globl _VDM0CN
                            139 	.globl _PCA0CPH0
                            140 	.globl _PCA0CPL0
                            141 	.globl _PCA0H
                            142 	.globl _PCA0L
                            143 	.globl _SPI0CN
                            144 	.globl _EIP1
                            145 	.globl _P1MDIN
                            146 	.globl _P1MODE
                            147 	.globl _P0MDIN
                            148 	.globl _P0MODE
                            149 	.globl _B
                            150 	.globl _RSTSRC
                            151 	.globl _PCA0CPH2
                            152 	.globl _PCA0CPL2
                            153 	.globl _PCA0CPH1
                            154 	.globl _PCA0CPL1
                            155 	.globl _ADC0CN
                            156 	.globl _EIE1
                            157 	.globl _INT01CF
                            158 	.globl _IT01CF
                            159 	.globl _OSCLCN
                            160 	.globl _XBR1
                            161 	.globl _XBR0
                            162 	.globl _ACC
                            163 	.globl _PCA0CPM2
                            164 	.globl _PCA0CPM1
                            165 	.globl _PCA0CPM0
                            166 	.globl _PCA0MD
                            167 	.globl _PCA0CN
                            168 	.globl _P1SKIP
                            169 	.globl _P0SKIP
                            170 	.globl _REF0CN
                            171 	.globl _PSW
                            172 	.globl _TMR2H
                            173 	.globl _TH2
                            174 	.globl _TMR2L
                            175 	.globl _TL2
                            176 	.globl _TMR2RLH
                            177 	.globl _RCAP2H
                            178 	.globl _TMR2RLL
                            179 	.globl _RCAP2L
                            180 	.globl _TMR2CN
                            181 	.globl _T2CON
                            182 	.globl _ADC0LTH
                            183 	.globl _ADC0LTL
                            184 	.globl _ADC0GTH
                            185 	.globl _ADC0GTL
                            186 	.globl _SMB0DAT
                            187 	.globl _SMB0CF
                            188 	.globl _SMB0CN
                            189 	.globl _ADC0H
                            190 	.globl _ADC0L
                            191 	.globl _ADC0CF
                            192 	.globl _AMX0P
                            193 	.globl _AMX0N
                            194 	.globl _IDA0CN
                            195 	.globl _IP
                            196 	.globl _FLKEY
                            197 	.globl _FLSCL
                            198 	.globl _OSCICL
                            199 	.globl _OSCICN
                            200 	.globl _OSCXCN
                            201 	.globl __XPAGE
                            202 	.globl _EMI0CN
                            203 	.globl _CLKSEL
                            204 	.globl _IE
                            205 	.globl _P2MDOUT
                            206 	.globl _P1MDOUT
                            207 	.globl _P0MDOUT
                            208 	.globl _SPI0DAT
                            209 	.globl _SPI0CKR
                            210 	.globl _SPI0CFG
                            211 	.globl _P2
                            212 	.globl _CPT0MX
                            213 	.globl _CPT0MD
                            214 	.globl _CPT0CN
                            215 	.globl _SBUF0
                            216 	.globl _SBUF
                            217 	.globl _SCON0
                            218 	.globl _SCON
                            219 	.globl _IDA0H
                            220 	.globl _IDA0L
                            221 	.globl _TMR3H
                            222 	.globl _TMR3L
                            223 	.globl _TMR3RLH
                            224 	.globl _TMR3RLL
                            225 	.globl _TMR3CN
                            226 	.globl _P1
                            227 	.globl _PSCTL
                            228 	.globl _CKCON
                            229 	.globl _TH1
                            230 	.globl _TH0
                            231 	.globl _TL1
                            232 	.globl _TL0
                            233 	.globl _TMOD
                            234 	.globl _TCON
                            235 	.globl _PCON
                            236 	.globl _DPH
                            237 	.globl _DPL
                            238 	.globl _SP
                            239 	.globl _P0
                            240 	.globl _Fault_Msg_Query
                            241 ;--------------------------------------------------------
                            242 ; special function registers
                            243 ;--------------------------------------------------------
                            244 	.area RSEG    (DATA)
                    0080    245 G$P0$0$0 == 0x0080
                    0080    246 _P0	=	0x0080
                    0081    247 G$SP$0$0 == 0x0081
                    0081    248 _SP	=	0x0081
                    0082    249 G$DPL$0$0 == 0x0082
                    0082    250 _DPL	=	0x0082
                    0083    251 G$DPH$0$0 == 0x0083
                    0083    252 _DPH	=	0x0083
                    0087    253 G$PCON$0$0 == 0x0087
                    0087    254 _PCON	=	0x0087
                    0088    255 G$TCON$0$0 == 0x0088
                    0088    256 _TCON	=	0x0088
                    0089    257 G$TMOD$0$0 == 0x0089
                    0089    258 _TMOD	=	0x0089
                    008A    259 G$TL0$0$0 == 0x008a
                    008A    260 _TL0	=	0x008a
                    008B    261 G$TL1$0$0 == 0x008b
                    008B    262 _TL1	=	0x008b
                    008C    263 G$TH0$0$0 == 0x008c
                    008C    264 _TH0	=	0x008c
                    008D    265 G$TH1$0$0 == 0x008d
                    008D    266 _TH1	=	0x008d
                    008E    267 G$CKCON$0$0 == 0x008e
                    008E    268 _CKCON	=	0x008e
                    008F    269 G$PSCTL$0$0 == 0x008f
                    008F    270 _PSCTL	=	0x008f
                    0090    271 G$P1$0$0 == 0x0090
                    0090    272 _P1	=	0x0090
                    0091    273 G$TMR3CN$0$0 == 0x0091
                    0091    274 _TMR3CN	=	0x0091
                    0092    275 G$TMR3RLL$0$0 == 0x0092
                    0092    276 _TMR3RLL	=	0x0092
                    0093    277 G$TMR3RLH$0$0 == 0x0093
                    0093    278 _TMR3RLH	=	0x0093
                    0094    279 G$TMR3L$0$0 == 0x0094
                    0094    280 _TMR3L	=	0x0094
                    0095    281 G$TMR3H$0$0 == 0x0095
                    0095    282 _TMR3H	=	0x0095
                    0096    283 G$IDA0L$0$0 == 0x0096
                    0096    284 _IDA0L	=	0x0096
                    0097    285 G$IDA0H$0$0 == 0x0097
                    0097    286 _IDA0H	=	0x0097
                    0098    287 G$SCON$0$0 == 0x0098
                    0098    288 _SCON	=	0x0098
                    0098    289 G$SCON0$0$0 == 0x0098
                    0098    290 _SCON0	=	0x0098
                    0099    291 G$SBUF$0$0 == 0x0099
                    0099    292 _SBUF	=	0x0099
                    0099    293 G$SBUF0$0$0 == 0x0099
                    0099    294 _SBUF0	=	0x0099
                    009B    295 G$CPT0CN$0$0 == 0x009b
                    009B    296 _CPT0CN	=	0x009b
                    009D    297 G$CPT0MD$0$0 == 0x009d
                    009D    298 _CPT0MD	=	0x009d
                    009F    299 G$CPT0MX$0$0 == 0x009f
                    009F    300 _CPT0MX	=	0x009f
                    00A0    301 G$P2$0$0 == 0x00a0
                    00A0    302 _P2	=	0x00a0
                    00A1    303 G$SPI0CFG$0$0 == 0x00a1
                    00A1    304 _SPI0CFG	=	0x00a1
                    00A2    305 G$SPI0CKR$0$0 == 0x00a2
                    00A2    306 _SPI0CKR	=	0x00a2
                    00A3    307 G$SPI0DAT$0$0 == 0x00a3
                    00A3    308 _SPI0DAT	=	0x00a3
                    00A4    309 G$P0MDOUT$0$0 == 0x00a4
                    00A4    310 _P0MDOUT	=	0x00a4
                    00A5    311 G$P1MDOUT$0$0 == 0x00a5
                    00A5    312 _P1MDOUT	=	0x00a5
                    00A6    313 G$P2MDOUT$0$0 == 0x00a6
                    00A6    314 _P2MDOUT	=	0x00a6
                    00A8    315 G$IE$0$0 == 0x00a8
                    00A8    316 _IE	=	0x00a8
                    00A9    317 G$CLKSEL$0$0 == 0x00a9
                    00A9    318 _CLKSEL	=	0x00a9
                    00AA    319 G$EMI0CN$0$0 == 0x00aa
                    00AA    320 _EMI0CN	=	0x00aa
                    00AA    321 G$_XPAGE$0$0 == 0x00aa
                    00AA    322 __XPAGE	=	0x00aa
                    00B1    323 G$OSCXCN$0$0 == 0x00b1
                    00B1    324 _OSCXCN	=	0x00b1
                    00B2    325 G$OSCICN$0$0 == 0x00b2
                    00B2    326 _OSCICN	=	0x00b2
                    00B3    327 G$OSCICL$0$0 == 0x00b3
                    00B3    328 _OSCICL	=	0x00b3
                    00B6    329 G$FLSCL$0$0 == 0x00b6
                    00B6    330 _FLSCL	=	0x00b6
                    00B7    331 G$FLKEY$0$0 == 0x00b7
                    00B7    332 _FLKEY	=	0x00b7
                    00B8    333 G$IP$0$0 == 0x00b8
                    00B8    334 _IP	=	0x00b8
                    00B9    335 G$IDA0CN$0$0 == 0x00b9
                    00B9    336 _IDA0CN	=	0x00b9
                    00BA    337 G$AMX0N$0$0 == 0x00ba
                    00BA    338 _AMX0N	=	0x00ba
                    00BB    339 G$AMX0P$0$0 == 0x00bb
                    00BB    340 _AMX0P	=	0x00bb
                    00BC    341 G$ADC0CF$0$0 == 0x00bc
                    00BC    342 _ADC0CF	=	0x00bc
                    00BD    343 G$ADC0L$0$0 == 0x00bd
                    00BD    344 _ADC0L	=	0x00bd
                    00BE    345 G$ADC0H$0$0 == 0x00be
                    00BE    346 _ADC0H	=	0x00be
                    00C0    347 G$SMB0CN$0$0 == 0x00c0
                    00C0    348 _SMB0CN	=	0x00c0
                    00C1    349 G$SMB0CF$0$0 == 0x00c1
                    00C1    350 _SMB0CF	=	0x00c1
                    00C2    351 G$SMB0DAT$0$0 == 0x00c2
                    00C2    352 _SMB0DAT	=	0x00c2
                    00C3    353 G$ADC0GTL$0$0 == 0x00c3
                    00C3    354 _ADC0GTL	=	0x00c3
                    00C4    355 G$ADC0GTH$0$0 == 0x00c4
                    00C4    356 _ADC0GTH	=	0x00c4
                    00C5    357 G$ADC0LTL$0$0 == 0x00c5
                    00C5    358 _ADC0LTL	=	0x00c5
                    00C6    359 G$ADC0LTH$0$0 == 0x00c6
                    00C6    360 _ADC0LTH	=	0x00c6
                    00C8    361 G$T2CON$0$0 == 0x00c8
                    00C8    362 _T2CON	=	0x00c8
                    00C8    363 G$TMR2CN$0$0 == 0x00c8
                    00C8    364 _TMR2CN	=	0x00c8
                    00CA    365 G$RCAP2L$0$0 == 0x00ca
                    00CA    366 _RCAP2L	=	0x00ca
                    00CA    367 G$TMR2RLL$0$0 == 0x00ca
                    00CA    368 _TMR2RLL	=	0x00ca
                    00CB    369 G$RCAP2H$0$0 == 0x00cb
                    00CB    370 _RCAP2H	=	0x00cb
                    00CB    371 G$TMR2RLH$0$0 == 0x00cb
                    00CB    372 _TMR2RLH	=	0x00cb
                    00CC    373 G$TL2$0$0 == 0x00cc
                    00CC    374 _TL2	=	0x00cc
                    00CC    375 G$TMR2L$0$0 == 0x00cc
                    00CC    376 _TMR2L	=	0x00cc
                    00CD    377 G$TH2$0$0 == 0x00cd
                    00CD    378 _TH2	=	0x00cd
                    00CD    379 G$TMR2H$0$0 == 0x00cd
                    00CD    380 _TMR2H	=	0x00cd
                    00D0    381 G$PSW$0$0 == 0x00d0
                    00D0    382 _PSW	=	0x00d0
                    00D1    383 G$REF0CN$0$0 == 0x00d1
                    00D1    384 _REF0CN	=	0x00d1
                    00D4    385 G$P0SKIP$0$0 == 0x00d4
                    00D4    386 _P0SKIP	=	0x00d4
                    00D5    387 G$P1SKIP$0$0 == 0x00d5
                    00D5    388 _P1SKIP	=	0x00d5
                    00D8    389 G$PCA0CN$0$0 == 0x00d8
                    00D8    390 _PCA0CN	=	0x00d8
                    00D9    391 G$PCA0MD$0$0 == 0x00d9
                    00D9    392 _PCA0MD	=	0x00d9
                    00DA    393 G$PCA0CPM0$0$0 == 0x00da
                    00DA    394 _PCA0CPM0	=	0x00da
                    00DB    395 G$PCA0CPM1$0$0 == 0x00db
                    00DB    396 _PCA0CPM1	=	0x00db
                    00DC    397 G$PCA0CPM2$0$0 == 0x00dc
                    00DC    398 _PCA0CPM2	=	0x00dc
                    00E0    399 G$ACC$0$0 == 0x00e0
                    00E0    400 _ACC	=	0x00e0
                    00E1    401 G$XBR0$0$0 == 0x00e1
                    00E1    402 _XBR0	=	0x00e1
                    00E2    403 G$XBR1$0$0 == 0x00e2
                    00E2    404 _XBR1	=	0x00e2
                    00E3    405 G$OSCLCN$0$0 == 0x00e3
                    00E3    406 _OSCLCN	=	0x00e3
                    00E4    407 G$IT01CF$0$0 == 0x00e4
                    00E4    408 _IT01CF	=	0x00e4
                    00E4    409 G$INT01CF$0$0 == 0x00e4
                    00E4    410 _INT01CF	=	0x00e4
                    00E6    411 G$EIE1$0$0 == 0x00e6
                    00E6    412 _EIE1	=	0x00e6
                    00E8    413 G$ADC0CN$0$0 == 0x00e8
                    00E8    414 _ADC0CN	=	0x00e8
                    00E9    415 G$PCA0CPL1$0$0 == 0x00e9
                    00E9    416 _PCA0CPL1	=	0x00e9
                    00EA    417 G$PCA0CPH1$0$0 == 0x00ea
                    00EA    418 _PCA0CPH1	=	0x00ea
                    00EB    419 G$PCA0CPL2$0$0 == 0x00eb
                    00EB    420 _PCA0CPL2	=	0x00eb
                    00EC    421 G$PCA0CPH2$0$0 == 0x00ec
                    00EC    422 _PCA0CPH2	=	0x00ec
                    00EF    423 G$RSTSRC$0$0 == 0x00ef
                    00EF    424 _RSTSRC	=	0x00ef
                    00F0    425 G$B$0$0 == 0x00f0
                    00F0    426 _B	=	0x00f0
                    00F1    427 G$P0MODE$0$0 == 0x00f1
                    00F1    428 _P0MODE	=	0x00f1
                    00F1    429 G$P0MDIN$0$0 == 0x00f1
                    00F1    430 _P0MDIN	=	0x00f1
                    00F2    431 G$P1MODE$0$0 == 0x00f2
                    00F2    432 _P1MODE	=	0x00f2
                    00F2    433 G$P1MDIN$0$0 == 0x00f2
                    00F2    434 _P1MDIN	=	0x00f2
                    00F6    435 G$EIP1$0$0 == 0x00f6
                    00F6    436 _EIP1	=	0x00f6
                    00F8    437 G$SPI0CN$0$0 == 0x00f8
                    00F8    438 _SPI0CN	=	0x00f8
                    00F9    439 G$PCA0L$0$0 == 0x00f9
                    00F9    440 _PCA0L	=	0x00f9
                    00FA    441 G$PCA0H$0$0 == 0x00fa
                    00FA    442 _PCA0H	=	0x00fa
                    00FB    443 G$PCA0CPL0$0$0 == 0x00fb
                    00FB    444 _PCA0CPL0	=	0x00fb
                    00FC    445 G$PCA0CPH0$0$0 == 0x00fc
                    00FC    446 _PCA0CPH0	=	0x00fc
                    00FF    447 G$VDM0CN$0$0 == 0x00ff
                    00FF    448 _VDM0CN	=	0x00ff
                    8C8A    449 G$TMR0$0$0 == 0x8c8a
                    8C8A    450 _TMR0	=	0x8c8a
                    8D8B    451 G$TMR1$0$0 == 0x8d8b
                    8D8B    452 _TMR1	=	0x8d8b
                    CDCC    453 G$TMR2$0$0 == 0xcdcc
                    CDCC    454 _TMR2	=	0xcdcc
                    CBCA    455 G$RCAP2$0$0 == 0xcbca
                    CBCA    456 _RCAP2	=	0xcbca
                    CBCA    457 G$TMR2RL$0$0 == 0xcbca
                    CBCA    458 _TMR2RL	=	0xcbca
                    9594    459 G$TMR3$0$0 == 0x9594
                    9594    460 _TMR3	=	0x9594
                    9392    461 G$TMR3RL$0$0 == 0x9392
                    9392    462 _TMR3RL	=	0x9392
                    9796    463 G$IDA0$0$0 == 0x9796
                    9796    464 _IDA0	=	0x9796
                    BEBD    465 G$ADC0$0$0 == 0xbebd
                    BEBD    466 _ADC0	=	0xbebd
                    C4C3    467 G$ADC0GT$0$0 == 0xc4c3
                    C4C3    468 _ADC0GT	=	0xc4c3
                    C6C5    469 G$ADC0LT$0$0 == 0xc6c5
                    C6C5    470 _ADC0LT	=	0xc6c5
                    FAF9    471 G$PCA0$0$0 == 0xfaf9
                    FAF9    472 _PCA0	=	0xfaf9
                    FCFB    473 G$PCA0CP0$0$0 == 0xfcfb
                    FCFB    474 _PCA0CP0	=	0xfcfb
                    EAE9    475 G$PCA0CP1$0$0 == 0xeae9
                    EAE9    476 _PCA0CP1	=	0xeae9
                    ECEB    477 G$PCA0CP2$0$0 == 0xeceb
                    ECEB    478 _PCA0CP2	=	0xeceb
                            479 ;--------------------------------------------------------
                            480 ; special function bits
                            481 ;--------------------------------------------------------
                            482 	.area RSEG    (DATA)
                    0080    483 G$P0_0$0$0 == 0x0080
                    0080    484 _P0_0	=	0x0080
                    0081    485 G$P0_1$0$0 == 0x0081
                    0081    486 _P0_1	=	0x0081
                    0082    487 G$P0_2$0$0 == 0x0082
                    0082    488 _P0_2	=	0x0082
                    0083    489 G$P0_3$0$0 == 0x0083
                    0083    490 _P0_3	=	0x0083
                    0084    491 G$P0_4$0$0 == 0x0084
                    0084    492 _P0_4	=	0x0084
                    0085    493 G$P0_5$0$0 == 0x0085
                    0085    494 _P0_5	=	0x0085
                    0086    495 G$P0_6$0$0 == 0x0086
                    0086    496 _P0_6	=	0x0086
                    0087    497 G$P0_7$0$0 == 0x0087
                    0087    498 _P0_7	=	0x0087
                    0088    499 G$IT0$0$0 == 0x0088
                    0088    500 _IT0	=	0x0088
                    0089    501 G$IE0$0$0 == 0x0089
                    0089    502 _IE0	=	0x0089
                    008A    503 G$IT1$0$0 == 0x008a
                    008A    504 _IT1	=	0x008a
                    008B    505 G$IE1$0$0 == 0x008b
                    008B    506 _IE1	=	0x008b
                    008C    507 G$TR0$0$0 == 0x008c
                    008C    508 _TR0	=	0x008c
                    008D    509 G$TF0$0$0 == 0x008d
                    008D    510 _TF0	=	0x008d
                    008E    511 G$TR1$0$0 == 0x008e
                    008E    512 _TR1	=	0x008e
                    008F    513 G$TF1$0$0 == 0x008f
                    008F    514 _TF1	=	0x008f
                    0090    515 G$P1_0$0$0 == 0x0090
                    0090    516 _P1_0	=	0x0090
                    0091    517 G$P1_1$0$0 == 0x0091
                    0091    518 _P1_1	=	0x0091
                    0092    519 G$P1_2$0$0 == 0x0092
                    0092    520 _P1_2	=	0x0092
                    0093    521 G$P1_3$0$0 == 0x0093
                    0093    522 _P1_3	=	0x0093
                    0094    523 G$P1_4$0$0 == 0x0094
                    0094    524 _P1_4	=	0x0094
                    0095    525 G$P1_5$0$0 == 0x0095
                    0095    526 _P1_5	=	0x0095
                    0096    527 G$P1_6$0$0 == 0x0096
                    0096    528 _P1_6	=	0x0096
                    0097    529 G$P1_7$0$0 == 0x0097
                    0097    530 _P1_7	=	0x0097
                    0098    531 G$RI$0$0 == 0x0098
                    0098    532 _RI	=	0x0098
                    0098    533 G$RI0$0$0 == 0x0098
                    0098    534 _RI0	=	0x0098
                    0099    535 G$TI$0$0 == 0x0099
                    0099    536 _TI	=	0x0099
                    0099    537 G$TI0$0$0 == 0x0099
                    0099    538 _TI0	=	0x0099
                    009A    539 G$RB8$0$0 == 0x009a
                    009A    540 _RB8	=	0x009a
                    009A    541 G$RB80$0$0 == 0x009a
                    009A    542 _RB80	=	0x009a
                    009B    543 G$TB8$0$0 == 0x009b
                    009B    544 _TB8	=	0x009b
                    009B    545 G$TB80$0$0 == 0x009b
                    009B    546 _TB80	=	0x009b
                    009C    547 G$REN$0$0 == 0x009c
                    009C    548 _REN	=	0x009c
                    009C    549 G$REN0$0$0 == 0x009c
                    009C    550 _REN0	=	0x009c
                    009D    551 G$SM2$0$0 == 0x009d
                    009D    552 _SM2	=	0x009d
                    009D    553 G$MCE0$0$0 == 0x009d
                    009D    554 _MCE0	=	0x009d
                    009F    555 G$SM0$0$0 == 0x009f
                    009F    556 _SM0	=	0x009f
                    009F    557 G$S0MODE$0$0 == 0x009f
                    009F    558 _S0MODE	=	0x009f
                    00A0    559 G$P2_0$0$0 == 0x00a0
                    00A0    560 _P2_0	=	0x00a0
                    00A1    561 G$P2_1$0$0 == 0x00a1
                    00A1    562 _P2_1	=	0x00a1
                    00A2    563 G$P2_2$0$0 == 0x00a2
                    00A2    564 _P2_2	=	0x00a2
                    00A3    565 G$P2_3$0$0 == 0x00a3
                    00A3    566 _P2_3	=	0x00a3
                    00A4    567 G$P2_4$0$0 == 0x00a4
                    00A4    568 _P2_4	=	0x00a4
                    00A5    569 G$P2_5$0$0 == 0x00a5
                    00A5    570 _P2_5	=	0x00a5
                    00A6    571 G$P2_6$0$0 == 0x00a6
                    00A6    572 _P2_6	=	0x00a6
                    00A7    573 G$P2_7$0$0 == 0x00a7
                    00A7    574 _P2_7	=	0x00a7
                    00A8    575 G$EX0$0$0 == 0x00a8
                    00A8    576 _EX0	=	0x00a8
                    00A9    577 G$ET0$0$0 == 0x00a9
                    00A9    578 _ET0	=	0x00a9
                    00AA    579 G$EX1$0$0 == 0x00aa
                    00AA    580 _EX1	=	0x00aa
                    00AB    581 G$ET1$0$0 == 0x00ab
                    00AB    582 _ET1	=	0x00ab
                    00AC    583 G$ES$0$0 == 0x00ac
                    00AC    584 _ES	=	0x00ac
                    00AC    585 G$ES0$0$0 == 0x00ac
                    00AC    586 _ES0	=	0x00ac
                    00AD    587 G$ET2$0$0 == 0x00ad
                    00AD    588 _ET2	=	0x00ad
                    00AE    589 G$ESPI0$0$0 == 0x00ae
                    00AE    590 _ESPI0	=	0x00ae
                    00AF    591 G$EA$0$0 == 0x00af
                    00AF    592 _EA	=	0x00af
                    00B8    593 G$PX0$0$0 == 0x00b8
                    00B8    594 _PX0	=	0x00b8
                    00B9    595 G$PT0$0$0 == 0x00b9
                    00B9    596 _PT0	=	0x00b9
                    00BA    597 G$PX1$0$0 == 0x00ba
                    00BA    598 _PX1	=	0x00ba
                    00BB    599 G$PT1$0$0 == 0x00bb
                    00BB    600 _PT1	=	0x00bb
                    00BC    601 G$PS$0$0 == 0x00bc
                    00BC    602 _PS	=	0x00bc
                    00BC    603 G$PS0$0$0 == 0x00bc
                    00BC    604 _PS0	=	0x00bc
                    00BD    605 G$PT2$0$0 == 0x00bd
                    00BD    606 _PT2	=	0x00bd
                    00BE    607 G$PSPI0$0$0 == 0x00be
                    00BE    608 _PSPI0	=	0x00be
                    00C0    609 G$SI$0$0 == 0x00c0
                    00C0    610 _SI	=	0x00c0
                    00C1    611 G$ACK$0$0 == 0x00c1
                    00C1    612 _ACK	=	0x00c1
                    00C2    613 G$ARBLOST$0$0 == 0x00c2
                    00C2    614 _ARBLOST	=	0x00c2
                    00C3    615 G$ACKRQ$0$0 == 0x00c3
                    00C3    616 _ACKRQ	=	0x00c3
                    00C4    617 G$STO$0$0 == 0x00c4
                    00C4    618 _STO	=	0x00c4
                    00C5    619 G$STA$0$0 == 0x00c5
                    00C5    620 _STA	=	0x00c5
                    00C6    621 G$TXMODE$0$0 == 0x00c6
                    00C6    622 _TXMODE	=	0x00c6
                    00C7    623 G$MASTER$0$0 == 0x00c7
                    00C7    624 _MASTER	=	0x00c7
                    00C8    625 G$T2XCLK$0$0 == 0x00c8
                    00C8    626 _T2XCLK	=	0x00c8
                    00CA    627 G$TR2$0$0 == 0x00ca
                    00CA    628 _TR2	=	0x00ca
                    00CB    629 G$T2SPLIT$0$0 == 0x00cb
                    00CB    630 _T2SPLIT	=	0x00cb
                    00CD    631 G$TF2CEN$0$0 == 0x00cd
                    00CD    632 _TF2CEN	=	0x00cd
                    00CD    633 G$TF2LEN$0$0 == 0x00cd
                    00CD    634 _TF2LEN	=	0x00cd
                    00CE    635 G$TF2L$0$0 == 0x00ce
                    00CE    636 _TF2L	=	0x00ce
                    00CF    637 G$TF2$0$0 == 0x00cf
                    00CF    638 _TF2	=	0x00cf
                    00CF    639 G$TF2H$0$0 == 0x00cf
                    00CF    640 _TF2H	=	0x00cf
                    00D0    641 G$PARITY$0$0 == 0x00d0
                    00D0    642 _PARITY	=	0x00d0
                    00D1    643 G$F1$0$0 == 0x00d1
                    00D1    644 _F1	=	0x00d1
                    00D2    645 G$OV$0$0 == 0x00d2
                    00D2    646 _OV	=	0x00d2
                    00D3    647 G$RS0$0$0 == 0x00d3
                    00D3    648 _RS0	=	0x00d3
                    00D4    649 G$RS1$0$0 == 0x00d4
                    00D4    650 _RS1	=	0x00d4
                    00D5    651 G$F0$0$0 == 0x00d5
                    00D5    652 _F0	=	0x00d5
                    00D6    653 G$AC$0$0 == 0x00d6
                    00D6    654 _AC	=	0x00d6
                    00D7    655 G$CY$0$0 == 0x00d7
                    00D7    656 _CY	=	0x00d7
                    00D8    657 G$CCF0$0$0 == 0x00d8
                    00D8    658 _CCF0	=	0x00d8
                    00D9    659 G$CCF1$0$0 == 0x00d9
                    00D9    660 _CCF1	=	0x00d9
                    00DA    661 G$CCF2$0$0 == 0x00da
                    00DA    662 _CCF2	=	0x00da
                    00DE    663 G$CR$0$0 == 0x00de
                    00DE    664 _CR	=	0x00de
                    00DF    665 G$CF$0$0 == 0x00df
                    00DF    666 _CF	=	0x00df
                    00E8    667 G$AD0CM0$0$0 == 0x00e8
                    00E8    668 _AD0CM0	=	0x00e8
                    00E9    669 G$AD0CM1$0$0 == 0x00e9
                    00E9    670 _AD0CM1	=	0x00e9
                    00EA    671 G$AD0CM2$0$0 == 0x00ea
                    00EA    672 _AD0CM2	=	0x00ea
                    00EB    673 G$AD0WINT$0$0 == 0x00eb
                    00EB    674 _AD0WINT	=	0x00eb
                    00EC    675 G$AD0BUSY$0$0 == 0x00ec
                    00EC    676 _AD0BUSY	=	0x00ec
                    00ED    677 G$AD0INT$0$0 == 0x00ed
                    00ED    678 _AD0INT	=	0x00ed
                    00EE    679 G$AD0TM$0$0 == 0x00ee
                    00EE    680 _AD0TM	=	0x00ee
                    00EF    681 G$AD0EN$0$0 == 0x00ef
                    00EF    682 _AD0EN	=	0x00ef
                    00F8    683 G$SPIEN$0$0 == 0x00f8
                    00F8    684 _SPIEN	=	0x00f8
                    00F9    685 G$TXBMT$0$0 == 0x00f9
                    00F9    686 _TXBMT	=	0x00f9
                    00FA    687 G$NSSMD0$0$0 == 0x00fa
                    00FA    688 _NSSMD0	=	0x00fa
                    00FB    689 G$NSSMD1$0$0 == 0x00fb
                    00FB    690 _NSSMD1	=	0x00fb
                    00FC    691 G$RXOVRN$0$0 == 0x00fc
                    00FC    692 _RXOVRN	=	0x00fc
                    00FD    693 G$MODF$0$0 == 0x00fd
                    00FD    694 _MODF	=	0x00fd
                    00FE    695 G$WCOL$0$0 == 0x00fe
                    00FE    696 _WCOL	=	0x00fe
                    00FF    697 G$SPIF$0$0 == 0x00ff
                    00FF    698 _SPIF	=	0x00ff
                            699 ;--------------------------------------------------------
                            700 ; overlayable register banks
                            701 ;--------------------------------------------------------
                            702 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                     703 	.ds 8
                            704 ;--------------------------------------------------------
                            705 ; internal ram data
                            706 ;--------------------------------------------------------
                            707 	.area DSEG    (DATA)
                            708 ;--------------------------------------------------------
                            709 ; overlayable items in internal ram 
                            710 ;--------------------------------------------------------
                            711 	.area	OSEG    (OVR,DATA)
                    0000    712 LFault_Msg_Query$buf$1$1==.
   0046                     713 _Fault_Msg_Query_PARM_2::
   0046                     714 	.ds 2
                    0002    715 LFault_Msg_Query$msg$1$1==.
   0048                     716 _Fault_Msg_Query_PARM_3::
   0048                     717 	.ds 2
                            718 ;--------------------------------------------------------
                            719 ; indirectly addressable internal ram data
                            720 ;--------------------------------------------------------
                            721 	.area ISEG    (DATA)
                            722 ;--------------------------------------------------------
                            723 ; bit data
                            724 ;--------------------------------------------------------
                            725 	.area BSEG    (BIT)
                            726 ;--------------------------------------------------------
                            727 ; paged external ram data
                            728 ;--------------------------------------------------------
                            729 	.area PSEG    (PAG,XDATA)
                            730 ;--------------------------------------------------------
                            731 ; external ram data
                            732 ;--------------------------------------------------------
                            733 	.area XSEG    (XDATA)
                            734 ;--------------------------------------------------------
                            735 ; external initialized ram data
                            736 ;--------------------------------------------------------
                            737 	.area XISEG   (XDATA)
                    0000    738 FExtdebug$fault_query_ndx$0$0==.
   00C1                     739 _fault_query_ndx:
   00C1                     740 	.ds 1
                            741 	.area HOME    (CODE)
                            742 	.area GSINIT0 (CODE)
                            743 	.area GSINIT1 (CODE)
                            744 	.area GSINIT2 (CODE)
                            745 	.area GSINIT3 (CODE)
                            746 	.area GSINIT4 (CODE)
                            747 	.area GSINIT5 (CODE)
                            748 	.area GSINIT  (CODE)
                            749 	.area GSFINAL (CODE)
                            750 	.area CSEG    (CODE)
                            751 ;--------------------------------------------------------
                            752 ; global & static initialisations
                            753 ;--------------------------------------------------------
                            754 	.area HOME    (CODE)
                            755 	.area GSINIT  (CODE)
                            756 	.area GSFINAL (CODE)
                            757 	.area GSINIT  (CODE)
                            758 ;--------------------------------------------------------
                            759 ; Home
                            760 ;--------------------------------------------------------
                            761 	.area HOME    (CODE)
                            762 	.area CSEG    (CODE)
                            763 ;--------------------------------------------------------
                            764 ; code
                            765 ;--------------------------------------------------------
                            766 	.area CSEG    (CODE)
                            767 ;------------------------------------------------------------
                            768 ;Allocation info for local variables in function 'Fault_Msg_Query'
                            769 ;------------------------------------------------------------
                            770 ;buf                       Allocated with name '_Fault_Msg_Query_PARM_2'
                            771 ;msg                       Allocated with name '_Fault_Msg_Query_PARM_3'
                            772 ;Test_Result               Allocated to registers r2 r3 
                            773 ;i                         Allocated to registers r4 
                            774 ;j                         Allocated to registers 
                            775 ;------------------------------------------------------------
                    0000    776 	G$Fault_Msg_Query$0$0 ==.
                    0000    777 	C$Extdebug.c$100$0$0 ==.
                            778 ;	C:/SDCC/GPSMon/dev/Extdebug.c:100: bit Fault_Msg_Query( uint Test_Result, uchar TXRX_STORAGE_CLASS *buf,
                            779 ;	-----------------------------------------
                            780 ;	 function Fault_Msg_Query
                            781 ;	-----------------------------------------
   1095                     782 _Fault_Msg_Query:
                    0002    783 	ar2 = 0x02
                    0003    784 	ar3 = 0x03
                    0004    785 	ar4 = 0x04
                    0005    786 	ar5 = 0x05
                    0006    787 	ar6 = 0x06
                    0007    788 	ar7 = 0x07
                    0000    789 	ar0 = 0x00
                    0001    790 	ar1 = 0x01
                            791 ;	genReceive
   1095 AA 82               792 	mov	r2,dpl
   1097 AB 83               793 	mov	r3,dph
                    0004    794 	C$Extdebug.c$106$1$1 ==.
                            795 ;	C:/SDCC/GPSMon/dev/Extdebug.c:106: if( Test_Result == 0 )
                            796 ;	genIfx
   1099 EA                  797 	mov	a,r2
   109A 4B                  798 	orl	a,r3
                            799 ;	genIfxJump
                            800 ;	Peephole 108.b	removed ljmp by inverse jump logic
                    0006    801 	C$Extdebug.c$107$1$1 ==.
                            802 ;	C:/SDCC/GPSMon/dev/Extdebug.c:107: return( FALSE );
                            803 ;	genRet
                            804 ;	Peephole 181	changed mov to clr
   109B 70 03               805 	jnz	00102$
                            806 ;	Peephole 300	removed redundant label 00131$
                            807 ;	Peephole 256.b	removed redundant clr a
   109D 24 FF               808 	add	a,#0xff
                            809 ;	Peephole 251.a	replaced ljmp to ret with ret
   109F 22                  810 	ret
   10A0                     811 00102$:
                    000B    812 	C$Extdebug.c$109$1$1 ==.
                            813 ;	C:/SDCC/GPSMon/dev/Extdebug.c:109: if( fault_query_ndx > 15 )
                            814 ;	genAssign
   10A0 90 00 C1            815 	mov	dptr,#_fault_query_ndx
   10A3 E0                  816 	movx	a,@dptr
                            817 ;	genCmpGt
                            818 ;	genCmp
                            819 ;	genIfxJump
                            820 ;	Peephole 108.a	removed ljmp by inverse jump logic
                            821 ;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
   10A4 FC                  822 	mov  r4,a
                            823 ;	Peephole 177.a	removed redundant mov
   10A5 24 F0               824 	add	a,#0xff - 0x0F
   10A7 50 05               825 	jnc	00125$
                            826 ;	Peephole 300	removed redundant label 00132$
                    0014    827 	C$Extdebug.c$110$1$1 ==.
                            828 ;	C:/SDCC/GPSMon/dev/Extdebug.c:110: fault_query_ndx = 0;
                            829 ;	genAssign
   10A9 90 00 C1            830 	mov	dptr,#_fault_query_ndx
                            831 ;	Peephole 181	changed mov to clr
   10AC E4                  832 	clr	a
   10AD F0                  833 	movx	@dptr,a
                    0019    834 	C$Extdebug.c$111$1$1 ==.
                            835 ;	C:/SDCC/GPSMon/dev/Extdebug.c:111: while( !(Test_Result & j<<fault_query_ndx) ){
   10AE                     836 00125$:
                            837 ;	genAssign
   10AE 7C 00               838 	mov	r4,#0x00
   10B0                     839 00108$:
                            840 ;	genAssign
   10B0 90 00 C1            841 	mov	dptr,#_fault_query_ndx
   10B3 E0                  842 	movx	a,@dptr
   10B4 FD                  843 	mov	r5,a
                            844 ;	genLeftShift
   10B5 8D F0               845 	mov	b,r5
   10B7 05 F0               846 	inc	b
   10B9 7E 01               847 	mov	r6,#0x01
   10BB 7F 00               848 	mov	r7,#0x00
   10BD 80 06               849 	sjmp	00134$
   10BF                     850 00133$:
   10BF EE                  851 	mov	a,r6
                            852 ;	Peephole 254	optimized left shift
   10C0 2E                  853 	add	a,r6
   10C1 FE                  854 	mov	r6,a
   10C2 EF                  855 	mov	a,r7
   10C3 33                  856 	rlc	a
   10C4 FF                  857 	mov	r7,a
   10C5                     858 00134$:
   10C5 D5 F0 F7            859 	djnz	b,00133$
                            860 ;	genAnd
   10C8 EA                  861 	mov	a,r2
   10C9 52 06               862 	anl	ar6,a
   10CB EB                  863 	mov	a,r3
   10CC 52 07               864 	anl	ar7,a
                            865 ;	genIfx
   10CE EE                  866 	mov	a,r6
   10CF 4F                  867 	orl	a,r7
                            868 ;	genIfxJump
                            869 ;	Peephole 108.b	removed ljmp by inverse jump logic
   10D0 70 22               870 	jnz	00110$
                            871 ;	Peephole 300	removed redundant label 00135$
                    003D    872 	C$Extdebug.c$112$2$2 ==.
                            873 ;	C:/SDCC/GPSMon/dev/Extdebug.c:112: fault_query_ndx++;
                            874 ;	genPlus
   10D2 90 00 C1            875 	mov	dptr,#_fault_query_ndx
                            876 ;     genPlusIncr
   10D5 74 01               877 	mov	a,#0x01
                            878 ;	Peephole 236.a	used r5 instead of ar5
   10D7 2D                  879 	add	a,r5
   10D8 F0                  880 	movx	@dptr,a
                    0044    881 	C$Extdebug.c$113$2$2 ==.
                            882 ;	C:/SDCC/GPSMon/dev/Extdebug.c:113: if( fault_query_ndx >= NUM_MSG || i++ >= NUM_MSG ){
                            883 ;	genAssign
   10D9 90 00 C1            884 	mov	dptr,#_fault_query_ndx
   10DC E0                  885 	movx	a,@dptr
   10DD FE                  886 	mov	r6,a
                            887 ;	genCmpLt
                            888 ;	genCmp
   10DE BE 10 00            889 	cjne	r6,#0x10,00136$
   10E1                     890 00136$:
                            891 ;	genIfxJump
                            892 ;	Peephole 108.a	removed ljmp by inverse jump logic
   10E1 50 08               893 	jnc	00105$
                            894 ;	Peephole 300	removed redundant label 00137$
                            895 ;	genAssign
   10E3 8C 06               896 	mov	ar6,r4
                            897 ;	genPlus
                            898 ;     genPlusIncr
   10E5 0C                  899 	inc	r4
                            900 ;	genCmpLt
                            901 ;	genCmp
   10E6 BE 10 00            902 	cjne	r6,#0x10,00138$
   10E9                     903 00138$:
                            904 ;	genIfxJump
                            905 ;	Peephole 112.b	changed ljmp to sjmp
                            906 ;	Peephole 160.a	removed sjmp by inverse jump logic
   10E9 40 C5               907 	jc	00108$
                            908 ;	Peephole 300	removed redundant label 00139$
   10EB                     909 00105$:
                    0056    910 	C$Extdebug.c$114$3$3 ==.
                            911 ;	C:/SDCC/GPSMon/dev/Extdebug.c:114: fault_query_ndx = 0;
                            912 ;	genAssign
   10EB 90 00 C1            913 	mov	dptr,#_fault_query_ndx
                            914 ;	Peephole 181	changed mov to clr
   10EE E4                  915 	clr	a
   10EF F0                  916 	movx	@dptr,a
                    005B    917 	C$Extdebug.c$115$3$3 ==.
                            918 ;	C:/SDCC/GPSMon/dev/Extdebug.c:115: return( FALSE );
                            919 ;	genRet
                            920 ;	Peephole 181	changed mov to clr
   10F0 E4                  921 	clr	a
   10F1 24 FF               922 	add	a,#0xff
                            923 ;	Peephole 112.b	changed ljmp to sjmp
                            924 ;	Peephole 251.b	replaced sjmp to ret with ret
   10F3 22                  925 	ret
   10F4                     926 00110$:
                    005F    927 	C$Extdebug.c$120$1$1 ==.
                            928 ;	C:/SDCC/GPSMon/dev/Extdebug.c:120: if( *(msg+MSG_LEN*fault_query_ndx) == NULL_CHAR ){
                            929 ;	genMult
                            930 ;	genMultOneByte
   10F4 ED                  931 	mov	a,r5
   10F5 75 F0 11            932 	mov	b,#0x11
   10F8 A4                  933 	mul	ab
                            934 ;	genPlus
   10F9 25 48               935 	add	a,_Fault_Msg_Query_PARM_3
   10FB FA                  936 	mov	r2,a
   10FC E5 49               937 	mov	a,(_Fault_Msg_Query_PARM_3 + 1)
   10FE 35 F0               938 	addc	a,b
   1100 FB                  939 	mov	r3,a
                            940 ;	genPointerGet
                            941 ;	genCodePointerGet
   1101 8A 82               942 	mov	dpl,r2
   1103 8B 83               943 	mov	dph,r3
   1105 E4                  944 	clr	a
   1106 93                  945 	movc	a,@a+dptr
                            946 ;	genIfxJump
                            947 ;	Peephole 108.b	removed ljmp by inverse jump logic
   1107 70 13               948 	jnz	00129$
                            949 ;	Peephole 300	removed redundant label 00140$
                    0074    950 	C$Extdebug.c$121$2$4 ==.
                            951 ;	C:/SDCC/GPSMon/dev/Extdebug.c:121: fault_query_ndx++;
                            952 ;	genPlus
   1109 90 00 C1            953 	mov	dptr,#_fault_query_ndx
                            954 ;     genPlusIncr
   110C 74 01               955 	mov	a,#0x01
                            956 ;	Peephole 236.a	used r5 instead of ar5
   110E 2D                  957 	add	a,r5
   110F F0                  958 	movx	@dptr,a
                    007B    959 	C$Extdebug.c$122$2$4 ==.
                            960 ;	C:/SDCC/GPSMon/dev/Extdebug.c:122: buf[0] = NULL_CHAR;
                            961 ;	genAssign
   1110 85 46 82            962 	mov	dpl,_Fault_Msg_Query_PARM_2
   1113 85 47 83            963 	mov	dph,(_Fault_Msg_Query_PARM_2 + 1)
                            964 ;	genPointerSet
                            965 ;     genFarPointerSet
                            966 ;	Peephole 181	changed mov to clr
   1116 E4                  967 	clr	a
   1117 F0                  968 	movx	@dptr,a
                    0083    969 	C$Extdebug.c$123$2$4 ==.
                            970 ;	C:/SDCC/GPSMon/dev/Extdebug.c:123: return( FALSE );
                            971 ;	genRet
                            972 ;	Peephole 181	changed mov to clr
   1118 E4                  973 	clr	a
   1119 24 FF               974 	add	a,#0xff
                    0086    975 	C$Extdebug.c$126$1$1 ==.
                            976 ;	C:/SDCC/GPSMon/dev/Extdebug.c:126: for( i=0; i<MSG_LEN; i++ ){
                            977 ;	Peephole 112.b	changed ljmp to sjmp
                            978 ;	Peephole 251.b	replaced sjmp to ret with ret
   111B 22                  979 	ret
   111C                     980 00129$:
                            981 ;	genAssign
   111C 7A 00               982 	mov	r2,#0x00
   111E                     983 00115$:
                            984 ;	genCmpLt
                            985 ;	genCmp
   111E BA 11 00            986 	cjne	r2,#0x11,00141$
   1121                     987 00141$:
                            988 ;	genIfxJump
                            989 ;	Peephole 108.a	removed ljmp by inverse jump logic
   1121 50 2E               990 	jnc	00118$
                            991 ;	Peephole 300	removed redundant label 00142$
                    008E    992 	C$Extdebug.c$127$2$5 ==.
                            993 ;	C:/SDCC/GPSMon/dev/Extdebug.c:127: buf[i] = *(msg+MSG_LEN*fault_query_ndx+i);
                            994 ;	genPlus
                            995 ;	Peephole 236.g	used r2 instead of ar2
   1123 EA                  996 	mov	a,r2
   1124 25 46               997 	add	a,_Fault_Msg_Query_PARM_2
   1126 FB                  998 	mov	r3,a
                            999 ;	Peephole 181	changed mov to clr
   1127 E4                 1000 	clr	a
   1128 35 47              1001 	addc	a,(_Fault_Msg_Query_PARM_2 + 1)
   112A FC                 1002 	mov	r4,a
                           1003 ;	genAssign
   112B 90 00 C1           1004 	mov	dptr,#_fault_query_ndx
   112E E0                 1005 	movx	a,@dptr
                           1006 ;	genMult
                           1007 ;	genMultOneByte
   112F FD                 1008 	mov	r5,a
                           1009 ;	Peephole 105	removed redundant mov
   1130 75 F0 11           1010 	mov	b,#0x11
   1133 A4                 1011 	mul	ab
                           1012 ;	genPlus
   1134 25 48              1013 	add	a,_Fault_Msg_Query_PARM_3
   1136 FD                 1014 	mov	r5,a
                           1015 ;	Peephole 240	use clr instead of addc a,#0
   1137 E4                 1016 	clr	a
   1138 35 49              1017 	addc	a,(_Fault_Msg_Query_PARM_3 + 1)
   113A FE                 1018 	mov	r6,a
                           1019 ;	genPlus
                           1020 ;	Peephole 236.g	used r2 instead of ar2
   113B EA                 1021 	mov	a,r2
                           1022 ;	Peephole 236.a	used r5 instead of ar5
   113C 2D                 1023 	add	a,r5
   113D F5 82              1024 	mov	dpl,a
                           1025 ;	Peephole 181	changed mov to clr
   113F E4                 1026 	clr	a
                           1027 ;	Peephole 236.b	used r6 instead of ar6
   1140 3E                 1028 	addc	a,r6
   1141 F5 83              1029 	mov	dph,a
                           1030 ;	genPointerGet
                           1031 ;	genCodePointerGet
   1143 E4                 1032 	clr	a
   1144 93                 1033 	movc	a,@a+dptr
                           1034 ;	genPointerSet
                           1035 ;     genFarPointerSet
   1145 FD                 1036 	mov	r5,a
   1146 8B 82              1037 	mov	dpl,r3
   1148 8C 83              1038 	mov	dph,r4
                           1039 ;	Peephole 136	removed redundant move
   114A F0                 1040 	movx	@dptr,a
                    00B6   1041 	C$Extdebug.c$128$2$5 ==.
                           1042 ;	C:/SDCC/GPSMon/dev/Extdebug.c:128: if( buf[i] == NULL_CHAR )
                           1043 ;	genIfx
   114B ED                 1044 	mov	a,r5
                           1045 ;	genIfxJump
                           1046 ;	Peephole 108.c	removed ljmp by inverse jump logic
   114C 60 03              1047 	jz	00118$
                           1048 ;	Peephole 300	removed redundant label 00143$
                    00B9   1049 	C$Extdebug.c$126$1$1 ==.
                           1050 ;	C:/SDCC/GPSMon/dev/Extdebug.c:126: for( i=0; i<MSG_LEN; i++ ){
                           1051 ;	genPlus
                           1052 ;     genPlusIncr
   114E 0A                 1053 	inc	r2
                           1054 ;	Peephole 112.b	changed ljmp to sjmp
   114F 80 CD              1055 	sjmp	00115$
   1151                    1056 00118$:
                    00BC   1057 	C$Extdebug.c$131$1$1 ==.
                           1058 ;	C:/SDCC/GPSMon/dev/Extdebug.c:131: fault_query_ndx++;
                           1059 ;	genAssign
   1151 90 00 C1           1060 	mov	dptr,#_fault_query_ndx
   1154 E0                 1061 	movx	a,@dptr
   1155 FA                 1062 	mov	r2,a
                           1063 ;	genPlus
   1156 90 00 C1           1064 	mov	dptr,#_fault_query_ndx
                           1065 ;     genPlusIncr
   1159 74 01              1066 	mov	a,#0x01
                           1067 ;	Peephole 236.a	used r2 instead of ar2
   115B 2A                 1068 	add	a,r2
   115C F0                 1069 	movx	@dptr,a
                    00C8   1070 	C$Extdebug.c$133$1$1 ==.
                           1071 ;	C:/SDCC/GPSMon/dev/Extdebug.c:133: return( TRUE );
                           1072 ;	genRet
   115D 74 01              1073 	mov	a,#0x01
   115F 24 FF              1074 	add	a,#0xff
                           1075 ;	Peephole 300	removed redundant label 00119$
                    00CC   1076 	C$Extdebug.c$134$1$1 ==.
                    00CC   1077 	XG$Fault_Msg_Query$0$0 ==.
   1161 22                 1078 	ret
                           1079 	.area CSEG    (CODE)
                           1080 	.area CONST   (CODE)
                    0000   1081 G$ALARM_MSG$0$0 == .
   1835                    1082 _ALARM_MSG:
   1835 52 4F 4D 20 43 68  1083 	.ascii "ROM Checksum Err"
        65 63 6B 73 75 6D
        20 45 72 72
   1845 00                 1084 	.db 0x00
   1846 52 41 4D 20 43 68  1085 	.ascii "RAM Check Failed"
        65 63 6B 20 46 61
        69 6C 65 64
   1856 00                 1086 	.db 0x00
   1857 50 6F 77 65 72 53  1087 	.ascii "PowerSupply Fail"
        75 70 70 6C 79 20
        46 61 69 6C
   1867 00                 1088 	.db 0x00
   1868 46 50 47 41 20 43  1089 	.ascii "FPGA Check Fail "
        68 65 63 6B 20 46
        61 69 6C 20
   1878 00                 1090 	.db 0x00
   1879 56 43 4F 20 61 74  1091 	.ascii "VCO at rail"
        20 72 61 69 6C
   1884 00                 1092 	.db 0x00
   1885 00                 1093 	.db 0x00
   1886 00                 1094 	.db 0x00
   1887 00                 1095 	.db 0x00
   1888 00                 1096 	.db 0x00
   1889 0C                 1097 	.db 0x0C
   188A 56 43 4F 20 4E 65  1098 	.ascii "VCO Near Rail"
        61 72 20 52 61 69
        6C
   1897 00                 1099 	.db 0x00
   1898 00                 1100 	.db 0x00
   1899 00                 1101 	.db 0x00
   189A 0C                 1102 	.db 0x0C
   189B 41 6E 74 65 6E 6E  1103 	.ascii "Antenna Open"
        61 20 4F 70 65 6E
   18A7 00                 1104 	.db 0x00
   18A8 00                 1105 	.db 0x00
   18A9 00                 1106 	.db 0x00
   18AA 00                 1107 	.db 0x00
   18AB 0C                 1108 	.db 0x0C
   18AC 41 6E 74 65 6E 6E  1109 	.ascii "Antenna Shorted"
        61 20 53 68 6F 72
        74 65 64
   18BB 00                 1110 	.db 0x00
   18BC 00                 1111 	.db 0x00
   18BD 4E 6F 74 20 54 72  1112 	.ascii "Not Tracking Sat"
        61 63 6B 69 6E 67
        20 53 61 74
   18CD 00                 1113 	.db 0x00
   18CE 4E 6F 74 20 44 69  1114 	.ascii "Not Disciplining"
        73 63 69 70 6C 69
        6E 69 6E 67
   18DE 00                 1115 	.db 0x00
   18DF 53 75 72 76 65 79  1116 	.ascii "Survey In Progrs"
        20 49 6E 20 50 72
        6F 67 72 73
   18EF 00                 1117 	.db 0x00
   18F0 4E 6F 20 53 74 6F  1118 	.ascii "No Stored Pos"
        72 65 64 20 50 6F
        73
   18FD 00                 1119 	.db 0x00
   18FE 00                 1120 	.db 0x00
   18FF 00                 1121 	.db 0x00
   1900 0C                 1122 	.db 0x0C
   1901 4C 65 61 70 20 53  1123 	.ascii "Leap Sec Pending"
        65 63 20 50 65 6E
        64 69 6E 67
   1911 00                 1124 	.db 0x00
   1912 54 65 73 74 20 4D  1125 	.ascii "Test Mode"
        6F 64 65
   191B 00                 1126 	.db 0x00
   191C 00                 1127 	.db 0x00
   191D 00                 1128 	.db 0x00
   191E 00                 1129 	.db 0x00
   191F 00                 1130 	.db 0x00
   1920 00                 1131 	.db 0x00
   1921 00                 1132 	.db 0x00
   1922 0C                 1133 	.db 0x0C
   1923 00                 1134 	.db 0x00
   1924 00                 1135 	.db 0x00
   1925 00                 1136 	.db 0x00
   1926 00                 1137 	.db 0x00
   1927 88                 1138 	.db 0x88
   1928 04                 1139 	.db 0x04
   1929 3E                 1140 	.ascii ">"
   192A 00                 1141 	.db 0x00
   192B 0C                 1142 	.db 0x0C
   192C 00                 1143 	.db 0x00
   192D 02                 1144 	.db 0x02
   192E 00                 1145 	.db 0x00
   192F 6D                 1146 	.ascii "m"
   1930 01                 1147 	.db 0x01
   1931 0C                 1148 	.db 0x0C
   1932 01                 1149 	.db 0x01
   1933 01                 1150 	.db 0x01
   1934 00                 1151 	.db 0x00
   1935 00                 1152 	.db 0x00
   1936 00                 1153 	.db 0x00
   1937 00                 1154 	.db 0x00
   1938 00                 1155 	.db 0x00
   1939 00                 1156 	.db 0x00
   193A 00                 1157 	.db 0x00
   193B 00                 1158 	.db 0x00
   193C 00                 1159 	.db 0x00
   193D 00                 1160 	.db 0x00
   193E 00                 1161 	.db 0x00
   193F 00                 1162 	.db 0x00
   1940 00                 1163 	.db 0x00
   1941 00                 1164 	.db 0x00
   1942 00                 1165 	.db 0x00
   1943 00                 1166 	.db 0x00
   1944 00                 1167 	.db 0x00
                           1168 	.area XINIT   (CODE)
                    0000   1169 FExtdebug$__xinit_fault_query_ndx$0$0 == .
   1945                    1170 __xinit__fault_query_ndx:
   1945 00                 1171 	.db #0x00
